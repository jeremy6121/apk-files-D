package com.example.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.game.GameMode
import com.example.game.ShipDefinition
import com.example.ui.theme.DeepSpace
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.SpaceBorder
import com.example.ui.theme.SpaceCard
import com.example.ui.theme.SpaceSurface
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MainMenuScreen(
    selectedShip: ShipDefinition,
    selectedMode: GameMode,
    totalCrystals: Int,
    highScore: Int,
    soundEnabled: Boolean,
    vibrationEnabled: Boolean,
    onSelectMode: (GameMode) -> Unit,
    onStartGame: () -> Unit,
    onOpenHangar: () -> Unit,
    onOpenLeaderboard: () -> Unit,
    onToggleSound: () -> Unit,
    onToggleVibration: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showHowToPlay by remember { mutableStateOf(false) }

    val infiniteTransition = rememberInfiniteTransition(label = "title_glow")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.03f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF070913),
                        Color(0xFF0F1426),
                        Color(0xFF161330)
                    )
                )
            )
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
                .windowInsetsPadding(WindowInsets.navigationBars),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Banked Crystals
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(SpaceCard)
                        .border(1.dp, SpaceBorder, RoundedCornerShape(16.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Diamond,
                        contentDescription = null,
                        tint = NeonGold,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "$totalCrystals",
                        fontWeight = FontWeight.Black,
                        color = NeonGold,
                        fontSize = 14.sp
                    )
                }

                // Controls: Sound, Vibration, Info
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { showHowToPlay = true },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(SpaceCard)
                            .testTag("help_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.HelpOutline,
                            contentDescription = "How to play",
                            tint = TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = onToggleSound,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(SpaceCard)
                            .testTag("sound_toggle")
                    ) {
                        Icon(
                            imageVector = if (soundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                            contentDescription = "Sound",
                            tint = if (soundEnabled) NeonCyan else TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = onToggleVibration,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(SpaceCard)
                            .testTag("vibration_toggle")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Vibration,
                            contentDescription = "Vibration",
                            tint = if (vibrationEnabled) NeonGold else TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Ship Animation Canvas
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(selectedShip.primaryColor.copy(alpha = 0.25f), Color.Transparent)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(90.dp)) {
                    val cx = size.width / 2f
                    val cy = size.height / 2f
                    val r = 32f

                    // Thruster Flame
                    val flame = Path().apply {
                        moveTo(cx - 10f, cy + r - 3f)
                        lineTo(cx, cy + r + 24f)
                        lineTo(cx + 10f, cy + r - 3f)
                        close()
                    }
                    drawPath(
                        flame,
                        brush = Brush.verticalGradient(
                            colors = listOf(selectedShip.secondaryColor, Color.Transparent),
                            startY = cy + r,
                            endY = cy + r + 24f
                        )
                    )

                    // Ship Body
                    val hull = Path().apply {
                        moveTo(cx, cy - r * 1.25f)
                        lineTo(cx + r * 1.1f, cy + r * 0.95f)
                        lineTo(cx + r * 0.4f, cy + r * 0.6f)
                        lineTo(cx - r * 0.4f, cy + r * 0.6f)
                        lineTo(cx - r * 1.1f, cy + r * 0.95f)
                        close()
                    }
                    drawPath(
                        hull,
                        brush = Brush.linearGradient(
                            colors = listOf(selectedShip.primaryColor, selectedShip.secondaryColor)
                        )
                    )
                    drawPath(hull, color = Color.White, style = Stroke(width = 2.5f))

                    // Cockpit
                    drawCircle(color = Color.White, radius = 5f, center = Offset(cx, cy - 4f))
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Game Title
            Text(
                text = "COSMIC DODGE",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.5.sp,
                    color = Color.White
                )
            )

            Text(
                text = "RETRO NEON SPACE RUNNER",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 3.sp,
                    color = NeonCyan
                )
            )

            Spacer(modifier = Modifier.height(20.dp))

            // High Score Banner
            if (highScore > 0) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(SpaceCard)
                        .border(1.dp, SpaceBorder, RoundedCornerShape(14.dp))
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.EmojiEvents,
                        contentDescription = null,
                        tint = NeonGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "RECORD: $highScore PTS",
                        fontWeight = FontWeight.Black,
                        color = TextPrimary,
                        fontSize = 13.sp
                    )
                }
                Spacer(modifier = Modifier.height(18.dp))
            }

            // Mode Selector Tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(SpaceCard)
                    .padding(4.dp)
            ) {
                ModeTab(
                    title = "Endless Odyssey",
                    subtitle = "Progressive waves & bosses",
                    isSelected = selectedMode == GameMode.SURVIVAL,
                    onClick = { onSelectMode(GameMode.SURVIVAL) },
                    modifier = Modifier.weight(1f)
                )
                ModeTab(
                    title = "60s Star Rush",
                    subtitle = "High-speed crystal blitz",
                    isSelected = selectedMode == GameMode.TIME_RUSH,
                    onClick = { onSelectMode(GameMode.TIME_RUSH) },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Equipped Ship Preview Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(bounded = true),
                        onClick = onOpenHangar
                    )
                    .testTag("equipped_ship_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = SpaceSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, SpaceBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(selectedShip.primaryColor.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.RocketLaunch,
                                contentDescription = null,
                                tint = selectedShip.primaryColor,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = selectedShip.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color.White
                            )
                            Text(
                                text = selectedShip.perkName,
                                fontSize = 12.sp,
                                color = selectedShip.primaryColor,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Text(
                        text = "CHANGE",
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp,
                        color = NeonCyan
                    )
                }
            }

            Spacer(modifier = Modifier.height(22.dp))

            // Big LAUNCH MISSION Button
            Button(
                onClick = onStartGame,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .testTag("start_game_button"),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Play",
                        tint = Color.Black,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "LAUNCH MISSION",
                        fontWeight = FontWeight.Black,
                        color = Color.Black,
                        fontSize = 17.sp,
                        letterSpacing = 1.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Bottom Navigation Buttons (Hangar & Leaderboard)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onOpenHangar,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("menu_hangar_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonGold),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonGold.copy(alpha = 0.6f))
                ) {
                    Icon(
                        imageVector = Icons.Default.RocketLaunch,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("HANGAR", fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onOpenLeaderboard,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("menu_hall_of_fame_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SpaceBorder)
                ) {
                    Icon(
                        imageVector = Icons.Default.EmojiEvents,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("HALL OF FAME", fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // How to play dialog
        if (showHowToPlay) {
            HowToPlayDialog(onDismiss = { showHowToPlay = false })
        }
    }
}

@Composable
private fun ModeTab(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) NeonCyan else Color.Transparent)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = true),
                onClick = onClick
            )
            .padding(vertical = 12.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = if (isSelected) Color.Black else Color.White
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = if (isSelected) Color(0xFF0F172A) else TextSecondary,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun HowToPlayDialog(onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = SpaceSurface),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, SpaceBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp)
            ) {
                Text(
                    text = "PILOT'S MANUAL",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.5.sp,
                        color = NeonCyan
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                InstructionRow("🎯 Touch & Drag", "Slide your finger anywhere on screen to smoothly navigate your spacecraft.")
                InstructionRow("🔫 Twin Plasma Cannons", "Your starfighter automatically fires laser bolts to blast asteroids and drones.")
                InstructionRow("⚡ Phase Dash (Left Button)", "Dash with momentary invulnerability and high burst speed.")
                InstructionRow("💥 Supernova EMP (Right Button)", "Detonate to wipe out every visible threat into collectible crystals.")
                InstructionRow("🛡️ Power-Ups", "Grab shields, rapid blasters, chrono freeze, and star magnets as they float down.")
                InstructionRow("💎 Close Call Bonus", "Near-miss dodges boost your score and combo multiplier up to 10x!")

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                ) {
                    Text("GOT IT, COMMANDER", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun InstructionRow(title: String, desc: String) {
    Column(modifier = Modifier.padding(vertical = 6.dp)) {
        Text(text = title, fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
        Text(text = desc, color = TextSecondary, fontSize = 12.sp, lineHeight = 16.sp)
    }
}
