package com.example.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.game.AVAILABLE_SHIPS

@Composable
fun CosmicDodgeApp(
    viewModel: GameViewModel = viewModel(),
    modifier: Modifier = Modifier
) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val gameEngine by viewModel.gameEngine.collectAsStateWithLifecycle()
    val isPaused by viewModel.isPaused.collectAsStateWithLifecycle()
    val isGameOver by viewModel.isGameOver.collectAsStateWithLifecycle()
    val isNewHighScore by viewModel.isNewHighScore.collectAsStateWithLifecycle()
    val profile by viewModel.profile.collectAsStateWithLifecycle()
    val highScores by viewModel.highScores.collectAsStateWithLifecycle()
    val selectedMode by viewModel.selectedMode.collectAsStateWithLifecycle()
    val selectedShip = viewModel.getSelectedShip()

    val totalCrystals = profile?.totalCrystals ?: 0
    val totalGames = profile?.totalGamesPlayed ?: 0
    val bestScore = highScores.maxOfOrNull { it.score } ?: 0
    val unlockedSet = profile?.unlockedShips?.split(",")?.toSet() ?: setOf("dart")

    Box(modifier = modifier.fillMaxSize()) {
        when (currentScreen) {
            AppScreen.MAIN_MENU -> {
                MainMenuScreen(
                    selectedShip = selectedShip,
                    selectedMode = selectedMode,
                    totalCrystals = totalCrystals,
                    highScore = bestScore,
                    soundEnabled = viewModel.audioEngine.soundEnabled,
                    vibrationEnabled = viewModel.audioEngine.vibrationEnabled,
                    onSelectMode = { viewModel.setGameMode(it) },
                    onStartGame = { viewModel.startGame() },
                    onOpenHangar = { viewModel.navigateTo(AppScreen.HANGAR) },
                    onOpenLeaderboard = { viewModel.navigateTo(AppScreen.LEADERBOARD) },
                    onToggleSound = { viewModel.toggleSound() },
                    onToggleVibration = { viewModel.toggleVibration() }
                )
            }

            AppScreen.PLAYING -> {
                gameEngine?.let { engine ->
                    Box(modifier = Modifier.fillMaxSize()) {
                        GameCanvas(engine = engine)
                        GameHud(
                            engine = engine,
                            onPauseClick = { viewModel.pauseGame() }
                        )

                        if (isPaused && !isGameOver) {
                            PauseDialog(
                                soundEnabled = viewModel.audioEngine.soundEnabled,
                                vibrationEnabled = viewModel.audioEngine.vibrationEnabled,
                                onResume = { viewModel.resumeGame() },
                                onRestart = { viewModel.restartGame() },
                                onToggleSound = { viewModel.toggleSound() },
                                onToggleVibration = { viewModel.toggleVibration() },
                                onQuitToMenu = { viewModel.navigateTo(AppScreen.MAIN_MENU) }
                            )
                        }

                        if (isGameOver) {
                            GameOverDialog(
                                engine = engine,
                                isHighScore = isNewHighScore,
                                onPlayAgain = { viewModel.restartGame() },
                                onOpenHangar = { viewModel.navigateTo(AppScreen.HANGAR) },
                                onMainMenu = { viewModel.navigateTo(AppScreen.MAIN_MENU) }
                            )
                        }
                    }
                }
            }

            AppScreen.HANGAR -> {
                HangarScreen(
                    totalCrystals = totalCrystals,
                    unlockedShipIds = unlockedSet,
                    selectedShipId = selectedShip.id,
                    onSelectShip = { viewModel.selectShip(it) },
                    onUnlockShip = { id, cost -> viewModel.unlockShip(id, cost) },
                    onBack = { viewModel.navigateTo(AppScreen.MAIN_MENU) }
                )
            }

            AppScreen.LEADERBOARD -> {
                LeaderboardScreen(
                    highScores = highScores,
                    totalGames = totalGames,
                    totalCrystals = totalCrystals,
                    onBack = { viewModel.navigateTo(AppScreen.MAIN_MENU) }
                )
            }
        }
    }
}
