package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.GameAudioEngine
import com.example.data.GameDatabase
import com.example.data.GameRepository
import com.example.data.GameScoreRecord
import com.example.data.PlayerProfile
import com.example.game.AVAILABLE_SHIPS
import com.example.game.GameEngine
import com.example.game.GameMode
import com.example.game.ShipDefinition
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class AppScreen {
    MAIN_MENU,
    PLAYING,
    HANGAR,
    LEADERBOARD
}

class GameViewModel(application: Application) : AndroidViewModel(application) {
    private val database = GameDatabase.getDatabase(application)
    private val repository = GameRepository(database.gameDao())
    val audioEngine = GameAudioEngine(application)

    val highScores: StateFlow<List<GameScoreRecord>> = repository.highScores
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val profile: StateFlow<PlayerProfile?> = repository.profile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _currentScreen = MutableStateFlow(AppScreen.MAIN_MENU)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _selectedMode = MutableStateFlow(GameMode.SURVIVAL)
    val selectedMode: StateFlow<GameMode> = _selectedMode.asStateFlow()

    private val _selectedShipId = MutableStateFlow("dart")
    val selectedShipId: StateFlow<String> = _selectedShipId.asStateFlow()

    private val _gameEngine = MutableStateFlow<GameEngine?>(null)
    val gameEngine: StateFlow<GameEngine?> = _gameEngine.asStateFlow()

    private val _isPaused = MutableStateFlow(false)
    val isPaused: StateFlow<Boolean> = _isPaused.asStateFlow()

    private val _isGameOver = MutableStateFlow(false)
    val isGameOver: StateFlow<Boolean> = _isGameOver.asStateFlow()

    private val _isNewHighScore = MutableStateFlow(false)
    val isNewHighScore: StateFlow<Boolean> = _isNewHighScore.asStateFlow()

    private var gameLoopJob: Job? = null

    init {
        viewModelScope.launch {
            repository.ensureProfileInitialized()
            repository.profile.collect { p ->
                p?.let {
                    _selectedShipId.value = it.selectedShipId
                    audioEngine.soundEnabled = it.soundEnabled
                    audioEngine.vibrationEnabled = it.vibrationEnabled
                }
            }
        }
    }

    fun getSelectedShip(): ShipDefinition {
        val id = _selectedShipId.value
        return AVAILABLE_SHIPS.find { it.id == id } ?: AVAILABLE_SHIPS.first()
    }

    fun setGameMode(mode: GameMode) {
        _selectedMode.value = mode
    }

    fun navigateTo(screen: AppScreen) {
        if (screen != AppScreen.PLAYING) {
            stopGameLoop()
        }
        _currentScreen.value = screen
    }

    fun startGame() {
        val ship = getSelectedShip()
        val mode = _selectedMode.value

        val engine = GameEngine(
            ship = ship,
            mode = mode,
            onPlayLaser = { audioEngine.playLaser() },
            onPlayCollect = { audioEngine.playCollect() },
            onPlayShield = { audioEngine.playShieldHit() },
            onPlayExplosion = { audioEngine.playExplosion() },
            onPlayPowerup = { audioEngine.playPowerup() },
            onPlayBomb = { audioEngine.playBomb() },
            onPlayWarning = { audioEngine.playWarning() }
        )

        _gameEngine.value = engine
        _isPaused.value = false
        _isGameOver.value = false
        _isNewHighScore.value = false
        _currentScreen.value = AppScreen.PLAYING

        startGameLoop(engine)
    }

    private fun startGameLoop(engine: GameEngine) {
        gameLoopJob?.cancel()
        gameLoopJob = viewModelScope.launch {
            var lastTime = System.nanoTime()

            while (isActive && !engine.isGameOver) {
                val now = System.nanoTime()
                val deltaSec = ((now - lastTime) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
                lastTime = now

                if (!_isPaused.value) {
                    engine.update(deltaSec)

                    if (engine.isGameOver) {
                        onGameOver(engine)
                        break
                    }
                }

                delay(16) // Target ~60 FPS
            }
        }
    }

    private fun stopGameLoop() {
        gameLoopJob?.cancel()
        gameLoopJob = null
    }

    fun pauseGame() {
        _isPaused.value = true
        _gameEngine.value?.isPaused = true
    }

    fun resumeGame() {
        _isPaused.value = false
        _gameEngine.value?.isPaused = false
    }

    fun restartGame() {
        stopGameLoop()
        startGame()
    }

    private fun onGameOver(engine: GameEngine) {
        _isGameOver.value = true

        viewModelScope.launch {
            val bestScore = highScores.value.maxOfOrNull { it.score } ?: 0
            val isRecord = engine.score > bestScore && engine.score > 0
            _isNewHighScore.value = isRecord

            repository.saveGameResult(
                score = engine.score,
                crystals = engine.crystalsInRun,
                maxCombo = engine.maxCombo,
                shipName = engine.ship.name,
                gameMode = engine.mode.displayName
            )
        }
    }

    fun selectShip(shipId: String) {
        _selectedShipId.value = shipId
        viewModelScope.launch {
            repository.selectShip(shipId)
        }
    }

    fun unlockShip(shipId: String, cost: Int) {
        viewModelScope.launch {
            val success = repository.unlockShip(shipId, cost)
            if (success) {
                audioEngine.playPowerup()
                selectShip(shipId)
            }
        }
    }

    fun toggleSound() {
        val newSound = !audioEngine.soundEnabled
        audioEngine.soundEnabled = newSound
        viewModelScope.launch {
            repository.updateSettings(
                soundEnabled = newSound,
                vibrationEnabled = audioEngine.vibrationEnabled
            )
        }
    }

    fun toggleVibration() {
        val newVibration = !audioEngine.vibrationEnabled
        audioEngine.vibrationEnabled = newVibration
        if (newVibration) {
            audioEngine.vibrate(30)
        }
        viewModelScope.launch {
            repository.updateSettings(
                soundEnabled = audioEngine.soundEnabled,
                vibrationEnabled = newVibration
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopGameLoop()
        audioEngine.release()
    }
}
