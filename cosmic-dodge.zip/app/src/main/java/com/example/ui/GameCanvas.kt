package com.example.ui

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import com.example.game.Boss
import com.example.game.Collectible
import com.example.game.CollectibleType
import com.example.game.GameEngine
import com.example.game.Obstacle
import com.example.game.ObstacleType
import com.example.game.Projectile
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun GameCanvas(
    engine: GameEngine,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current

    // Text paint cached for 60fps native text drawing
    val textPaint = remember(density) {
        Paint().apply {
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
    }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(engine) {
                detectTapGestures(
                    onTap = { offset ->
                        engine.onTouchMove(offset.x, offset.y)
                    }
                )
            }
            .pointerInput(engine) {
                detectDragGestures(
                    onDragStart = { offset ->
                        engine.onTouchMove(offset.x, offset.y)
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        engine.onTouchMove(change.position.x, change.position.y)
                    }
                )
            }
    ) {
        // Initialize dimensions on first draw
        engine.initDimensions(size.width, size.height)

        // Screen Shake translation
        val shakeOffset = if (engine.screenShake > 0f) {
            Offset(
                (Random.nextFloat() - 0.5f) * engine.screenShake,
                (Random.nextFloat() - 0.5f) * engine.screenShake
            )
        } else {
            Offset.Zero
        }

        translate(shakeOffset.x, shakeOffset.y) {
            // 1. Deep Space Gradient Background
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF060810),
                        Color(0xFF0C1022),
                        Color(0xFF140F2D)
                    )
                )
            )

            // Chrono Freeze Ambient Cyan Aura
            if (engine.chronoFreezeTimer > 0f) {
                drawRect(
                    color = Color(0x3300F0FF),
                    size = size
                )
            }

            // 2. Starfield
            engine.stars.forEach { star ->
                drawCircle(
                    color = star.color.copy(alpha = star.baseAlpha),
                    radius = star.size,
                    center = Offset(star.x, star.y)
                )
            }

            // 3. Collectibles
            engine.collectibles.forEach { col ->
                drawCollectible(col)
            }

            // 4. Projectiles
            engine.projectiles.forEach { proj ->
                drawProjectile(proj)
            }

            // 5. Obstacles
            engine.obstacles.forEach { obs ->
                drawObstacle(obs)
            }

            // 6. Boss
            engine.boss?.let { b ->
                drawBoss(b)
            }

            // 7. Particles
            engine.particles.forEach { part ->
                drawCircle(
                    color = part.color.copy(alpha = part.alpha.coerceIn(0f, 1f)),
                    radius = part.size,
                    center = Offset(part.x, part.y)
                )
            }

            // 8. Player Ship
            drawPlayerShip(engine)

            // 9. Floating Combat Texts
            engine.floatingTexts.forEach { ft ->
                textPaint.textSize = ft.sizeSp * density.density
                textPaint.color = ft.color.toArgb()
                textPaint.alpha = (ft.alpha.coerceIn(0f, 1f) * 255).toInt()
                drawContext.canvas.nativeCanvas.drawText(
                    ft.text,
                    ft.x,
                    ft.y,
                    textPaint
                )
            }
        }
    }
}

private fun DrawScope.drawPlayerShip(engine: GameEngine) {
    val ship = engine.ship
    val px = engine.playerX
    val py = engine.playerY
    val r = engine.playerRadius

    // Blink effect if invulnerable (and not dashing)
    if (engine.isInvulnerable && !engine.isDashing) {
        val blink = (engine.invulnerableTimer * 12f).toInt() % 2 == 0
        if (blink) return
    }

    // Shield Aura
    if (engine.shields > 0) {
        val shieldRadius = r * 1.7f
        drawCircle(
            color = Color(0x3300F0FF),
            radius = shieldRadius,
            center = Offset(px, py)
        )
        drawCircle(
            color = Color(0xFF00F0FF),
            radius = shieldRadius,
            center = Offset(px, py),
            style = Stroke(width = 3f)
        )

        // Multiple shield rings
        if (engine.shields > 1) {
            drawCircle(
                color = Color(0xFF38BDF8),
                radius = shieldRadius + 6f,
                center = Offset(px, py),
                style = Stroke(width = 1.8f)
            )
        }
    }

    // Magnet Range Ring
    if (engine.magnetTimer > 0f) {
        drawCircle(
            color = Color(0x2210B981),
            radius = r * 3.5f,
            center = Offset(px, py),
            style = Stroke(width = 2f)
        )
    }

    // Engine Thruster Glow
    val flameLength = if (engine.isDashing) 42f else 24f
    val flamePath = Path().apply {
        moveTo(px - 10f, py + r - 4f)
        lineTo(px, py + r + flameLength)
        lineTo(px + 10f, py + r - 4f)
        close()
    }
    drawPath(
        path = flamePath,
        brush = Brush.verticalGradient(
            colors = listOf(ship.secondaryColor, Color.Transparent),
            startY = py + r - 4f,
            endY = py + r + flameLength
        )
    )

    // Ship Hull
    val shipPath = Path().apply {
        moveTo(px, py - r * 1.25f) // Nose
        lineTo(px + r * 1.1f, py + r * 0.95f) // Right wing tip
        lineTo(px + r * 0.4f, py + r * 0.6f) // Right wing inner
        lineTo(px - r * 0.4f, py + r * 0.6f) // Left wing inner
        lineTo(px - r * 1.1f, py + r * 0.95f) // Left wing tip
        close()
    }

    drawPath(
        path = shipPath,
        brush = Brush.linearGradient(
            colors = listOf(ship.primaryColor, ship.secondaryColor),
            start = Offset(px, py - r),
            end = Offset(px, py + r)
        )
    )

    // Ship Cockpit
    val cockpitPath = Path().apply {
        moveTo(px, py - r * 0.6f)
        lineTo(px + 5f, py + 2f)
        lineTo(px - 5f, py + 2f)
        close()
    }
    drawPath(
        path = cockpitPath,
        color = Color(0xFFF8FAFC)
    )

    // Neon Ship Outline
    drawPath(
        path = shipPath,
        color = Color(0xFFFFFFFF),
        style = Stroke(width = 2.2f)
    )
}

private fun DrawScope.drawObstacle(obs: Obstacle) {
    rotate(obs.rotation, pivot = Offset(obs.x, obs.y)) {
        when (obs.type) {
            ObstacleType.ASTEROID_SMALL, ObstacleType.ASTEROID_MEDIUM, ObstacleType.ASTEROID_LARGE -> {
                // Faceted polygon asteroid
                val path = Path()
                val numVertices = if (obs.type == ObstacleType.ASTEROID_LARGE) 8 else 6
                for (i in 0 until numVertices) {
                    val angle = (i.toFloat() / numVertices) * 2f * Math.PI.toFloat()
                    val r = obs.radius * (if (i % 2 == 0) 1.0f else 0.8f)
                    val vx = obs.x + cos(angle) * r
                    val vy = obs.y + sin(angle) * r
                    if (i == 0) path.moveTo(vx, vy) else path.lineTo(vx, vy)
                }
                path.close()

                drawPath(path = path, color = obs.color)
                drawPath(path = path, color = Color(0xFFE2E8F0), style = Stroke(width = 2f))

                // Crater details
                drawCircle(
                    color = Color(0x33000000),
                    radius = obs.radius * 0.25f,
                    center = Offset(obs.x - obs.radius * 0.2f, obs.y - obs.radius * 0.2f)
                )
            }

            ObstacleType.COMET -> {
                // Fiery comet head & tail
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFFFFB800), Color(0xFFF43F5E), Color.Transparent),
                        center = Offset(obs.x, obs.y),
                        radius = obs.radius * 1.5f
                    ),
                    radius = obs.radius * 1.5f,
                    center = Offset(obs.x, obs.y)
                )
                drawCircle(
                    color = Color.White,
                    radius = obs.radius * 0.6f,
                    center = Offset(obs.x, obs.y)
                )
            }

            ObstacleType.DRONE -> {
                // Triangular stealth drone
                val dronePath = Path().apply {
                    moveTo(obs.x, obs.y + obs.radius)
                    lineTo(obs.x + obs.radius, obs.y - obs.radius)
                    lineTo(obs.x, obs.y - obs.radius * 0.3f)
                    lineTo(obs.x - obs.radius, obs.y - obs.radius)
                    close()
                }
                drawPath(path = dronePath, color = Color(0xFF1E293B))
                drawPath(path = dronePath, color = obs.color, style = Stroke(width = 2.5f))
                // Glowing drone eye
                drawCircle(
                    color = Color(0xFFF43F5E),
                    radius = 5f,
                    center = Offset(obs.x, obs.y)
                )
            }

            ObstacleType.BLACK_HOLE -> {
                // Distortion gravitational rings
                drawCircle(
                    color = Color(0x44A855F7),
                    radius = obs.radius * 1.6f,
                    center = Offset(obs.x, obs.y),
                    style = Stroke(width = 3f)
                )
                drawCircle(
                    color = Color(0xFF090B16),
                    radius = obs.radius,
                    center = Offset(obs.x, obs.y)
                )
                drawCircle(
                    color = Color(0xFFE879F9),
                    radius = obs.radius,
                    center = Offset(obs.x, obs.y),
                    style = Stroke(width = 2f)
                )
            }
        }
    }
}

private fun DrawScope.drawProjectile(p: Projectile) {
    if (p.isEnemy) {
        // Red plasma orb
        drawCircle(
            color = Color(0x66F43F5E),
            radius = p.radius * 1.8f,
            center = Offset(p.x, p.y)
        )
        drawCircle(
            color = p.color,
            radius = p.radius,
            center = Offset(p.x, p.y)
        )
        drawCircle(
            color = Color.White,
            radius = p.radius * 0.45f,
            center = Offset(p.x, p.y)
        )
    } else {
        // Neon Laser Bolt
        val boltHeight = 22f
        drawRoundRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color.White, p.color),
                startY = p.y - boltHeight / 2f,
                endY = p.y + boltHeight / 2f
            ),
            topLeft = Offset(p.x - p.radius * 0.7f, p.y - boltHeight / 2f),
            size = Size(p.radius * 1.4f, boltHeight),
            cornerRadius = CornerRadius(4f, 4f)
        )
    }
}

private fun DrawScope.drawCollectible(c: Collectible) {
    val pulseFactor = 1.0f + 0.15f * sin(c.pulse)
    val r = c.radius * pulseFactor

    when (c.type) {
        CollectibleType.CRYSTAL -> {
            // Glowing diamond
            val diamond = Path().apply {
                moveTo(c.x, c.y - r)
                lineTo(c.x + r * 0.85f, c.y)
                lineTo(c.x, c.y + r)
                lineTo(c.x - r * 0.85f, c.y)
                close()
            }
            drawCircle(
                color = Color(0x44FBBF24),
                radius = r * 1.4f,
                center = Offset(c.x, c.y)
            )
            drawPath(path = diamond, color = Color(0xFFFBBF24))
            drawPath(path = diamond, color = Color.White, style = Stroke(width = 2f))
        }

        CollectibleType.SHIELD -> {
            // Cyan Shield Orb
            drawCircle(color = Color(0x4400F0FF), radius = r * 1.3f, center = Offset(c.x, c.y))
            drawCircle(color = Color(0xFF00F0FF), radius = r, center = Offset(c.x, c.y), style = Stroke(width = 3f))
            drawCircle(color = Color.White, radius = r * 0.4f, center = Offset(c.x, c.y))
        }

        CollectibleType.RAPID_BLASTER -> {
            // Dual laser icon orb
            drawCircle(color = Color(0x4438BDF8), radius = r * 1.3f, center = Offset(c.x, c.y))
            drawCircle(color = Color(0xFF38BDF8), radius = r, center = Offset(c.x, c.y))
            // Twin vertical white stripes
            drawRect(color = Color.White, topLeft = Offset(c.x - 6f, c.y - 10f), size = Size(3.5f, 20f))
            drawRect(color = Color.White, topLeft = Offset(c.x + 2.5f, c.y - 10f), size = Size(3.5f, 20f))
        }

        CollectibleType.CHRONO_FREEZE -> {
            // Clock/Hourglass orb
            drawCircle(color = Color(0x44E879F9), radius = r * 1.3f, center = Offset(c.x, c.y))
            drawCircle(color = Color(0xFFA855F7), radius = r, center = Offset(c.x, c.y))
            drawCircle(color = Color.White, radius = r * 0.6f, center = Offset(c.x, c.y), style = Stroke(width = 2f))
        }

        CollectibleType.MAGNET -> {
            // Green Magnet Orb
            drawCircle(color = Color(0x4410B981), radius = r * 1.3f, center = Offset(c.x, c.y))
            drawCircle(color = Color(0xFF10B981), radius = r, center = Offset(c.x, c.y))
            drawCircle(color = Color.White, radius = r * 0.5f, center = Offset(c.x, c.y), style = Stroke(width = 2.5f))
        }

        CollectibleType.NOVA_BOMB -> {
            // Fiery Bomb
            drawCircle(color = Color(0x55FB923C), radius = r * 1.4f, center = Offset(c.x, c.y))
            drawCircle(color = Color(0xFFF97316), radius = r, center = Offset(c.x, c.y))
            drawCircle(color = Color(0xFFFBBF24), radius = r * 0.5f, center = Offset(c.x, c.y))
        }
    }
}

private fun DrawScope.drawBoss(b: Boss) {
    val bx = b.x
    val by = b.y
    val hw = b.width / 2f
    val hh = b.height / 2f

    // Mothership Body
    val bossPath = Path().apply {
        moveTo(bx - hw, by - hh * 0.5f)
        lineTo(bx - hw * 0.6f, by + hh)
        lineTo(bx, by + hh * 0.7f)
        lineTo(bx + hw * 0.6f, by + hh)
        lineTo(bx + hw, by - hh * 0.5f)
        lineTo(bx + hw * 0.3f, by - hh)
        lineTo(bx - hw * 0.3f, by - hh)
        close()
    }

    drawPath(
        path = bossPath,
        brush = Brush.verticalGradient(
            colors = listOf(Color(0xFF1E1B4B), Color(0xFF4C0519)),
            startY = by - hh,
            endY = by + hh
        )
    )
    drawPath(path = bossPath, color = Color(0xFFF43F5E), style = Stroke(width = 3.5f))

    // Boss Core Reactor
    drawCircle(
        color = Color(0xFFF43F5E),
        radius = 16f,
        center = Offset(bx, by)
    )
    drawCircle(
        color = Color.White,
        radius = 8f,
        center = Offset(bx, by)
    )

    // Boss Health Bar
    val barWidth = b.width * 1.1f
    val barHeight = 8f
    val barX = bx - barWidth / 2f
    val barY = by - hh - 22f

    // Health Bar Background
    drawRect(
        color = Color(0x99000000),
        topLeft = Offset(barX, barY),
        size = Size(barWidth, barHeight)
    )
    // Health Bar Fill
    val healthPercent = (b.health.toFloat() / b.maxHealth.toFloat()).coerceIn(0f, 1f)
    drawRect(
        brush = Brush.horizontalGradient(
            colors = listOf(Color(0xFFFBBF24), Color(0xFFF43F5E)),
            startX = barX,
            endX = barX + barWidth
        ),
        topLeft = Offset(barX, barY),
        size = Size(barWidth * healthPercent, barHeight)
    )
    drawRect(
        color = Color.White,
        topLeft = Offset(barX, barY),
        size = Size(barWidth, barHeight),
        style = Stroke(width = 1.2f)
    )
}
