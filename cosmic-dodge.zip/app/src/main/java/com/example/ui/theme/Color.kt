package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DeepSpace = Color(0xFF080A12)
val SpaceSurface = Color(0xFF12172A)
val SpaceCard = Color(0xFF1B223B)
val SpaceBorder = Color(0xFF2E3A5F)

val NeonCyan = Color(0xFF00F0FF)
val NeonMagenta = Color(0xFFF43F5E)
val NeonGold = Color(0xFFFBBF24)
val NeonGreen = Color(0xFF10B981)
val NeonPurple = Color(0xFFA855F7)
val NeonOrange = Color(0xFFFB923C)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
