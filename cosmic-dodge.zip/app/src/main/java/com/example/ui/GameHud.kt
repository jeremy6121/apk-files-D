package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.GameEngine
import com.example.game.GameMode
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonPurple
import kotlin.math.ceil

@Composable
fun GameHud(
    engine: GameEngine,
    onPauseClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "hud_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {
        // --- TOP HUD BAR ---
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Score & High Combo Display
                Column {
                    Text(
                        text = "${engine.score}",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.2.sp,
                            color = Color.White
                        )
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Crystals count
                        Icon(
                            imageVector = Icons.Default.Diamond,
                            contentDescription = "Crystals",
                            tint = NeonGold,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${engine.crystalsInRun}",
                            color = NeonGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )

                        // Combo multiplier tag
                        if (engine.combo > 1) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .scale(pulseScale)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(NeonMagenta)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "x${engine.combo} COMBO!",
                                    color = Color.White,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }

                // Middle: Time Rush Timer if applicable
                if (engine.mode == GameMode.TIME_RUSH) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x88000000))
                            .border(1.dp, NeonGold, RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "${ceil(engine.timeRemaining).toInt()}s",
                            color = if (engine.timeRemaining <= 10f) NeonMagenta else NeonGold,
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp
                        )
                    }
                }

                // Right: Health Hearts, Shields & Pause Button
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Health Hearts
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0x8812172A))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (i in 1..engine.maxHealth) {
                            Icon(
                                imageVector = if (i <= engine.health) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription = "Health $i",
                                tint = if (i <= engine.health) NeonMagenta else Color(0xFF64748B),
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        // Plasma Shields
                        if (engine.shields > 0) {
                            Spacer(modifier = Modifier.width(6.dp))
                            for (s in 1..engine.shields) {
                                Icon(
                                    imageVector = Icons.Default.Security,
                                    contentDescription = "Shield $s",
                                    tint = NeonCyan,
                                    modifier = Modifier.size(17.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Pause Button
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color(0x881E2238))
                            .border(1.dp, Color(0xFF334155), CircleShape)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = ripple(bounded = true),
                                onClick = onPauseClick
                            )
                            .testTag("pause_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Pause,
                            contentDescription = "Pause",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }

            // Power-up duration indicator chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (engine.rapidBlasterTimer > 0f) {
                    PowerupChip(
                        name = "RAPID",
                        seconds = engine.rapidBlasterTimer,
                        color = NeonCyan
                    )
                }
                if (engine.chronoFreezeTimer > 0f) {
                    PowerupChip(
                        name = "FREEZE",
                        seconds = engine.chronoFreezeTimer,
                        color = NeonPurple
                    )
                }
                if (engine.magnetTimer > 0f) {
                    PowerupChip(
                        name = "MAGNET",
                        seconds = engine.magnetTimer,
                        color = NeonGreen
                    )
                }
            }
        }

        // --- BOTTOM CONTROLS (DASH & BOMB) ---
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            // DASH ABILITY BUTTON
            val dashProgress = if (engine.dashCooldownTimer > 0f) {
                (engine.dashCooldownTimer / engine.ship.dashCooldownSec).coerceIn(0f, 1f)
            } else 0f
            val isDashReady = engine.dashCooldownTimer <= 0f

            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(
                        if (isDashReady) {
                            Brush.radialGradient(
                                colors = listOf(NeonCyan, Color(0xFF0369A1))
                            )
                        } else {
                            Brush.linearGradient(
                                colors = listOf(Color(0xFF1E293B), Color(0xFF0F172A))
                            )
                        }
                    )
                    .border(
                        width = 2.dp,
                        color = if (isDashReady) Color.White else Color(0xFF475569),
                        shape = CircleShape
                    )
                    .clickable(
                        enabled = isDashReady,
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(bounded = true),
                        onClick = { engine.triggerDash() }
                    )
                    .testTag("dash_button"),
                contentAlignment = Alignment.Center
            ) {
                if (!isDashReady) {
                    CircularProgressIndicator(
                        progress = { dashProgress },
                        modifier = Modifier.fillMaxSize(),
                        color = NeonCyan,
                        strokeWidth = 3.dp,
                        trackColor = Color.Transparent
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = "Phase Dash",
                        tint = if (isDashReady) Color.White else Color(0xFF64748B),
                        modifier = Modifier.size(28.dp)
                    )
                    Text(
                        text = if (isDashReady) "DASH" else "${ceil(engine.dashCooldownTimer).toInt()}s",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDashReady) Color.White else Color(0xFF94A3B8)
                    )
                }
            }

            // SUPERNOVA BOMB BUTTON
            val hasBombs = engine.bombs > 0
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(
                        if (hasBombs) {
                            Brush.radialGradient(
                                colors = listOf(Color(0xFFFB923C), Color(0xFFC2410C))
                            )
                        } else {
                            Brush.linearGradient(
                                colors = listOf(Color(0xFF1E293B), Color(0xFF0F172A))
                            )
                        }
                    )
                    .border(
                        width = 2.dp,
                        color = if (hasBombs) NeonGold else Color(0xFF475569),
                        shape = CircleShape
                    )
                    .clickable(
                        enabled = hasBombs,
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(bounded = true),
                        onClick = { engine.triggerBomb() }
                    )
                    .testTag("bomb_button"),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Supernova Bomb",
                        tint = if (hasBombs) Color.White else Color(0xFF64748B),
                        modifier = Modifier.size(26.dp)
                    )
                    Text(
                        text = "EMP x${engine.bombs}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = if (hasBombs) Color.White else Color(0xFF94A3B8)
                    )
                }
            }
        }
    }
}

@Composable
private fun PowerupChip(
    name: String,
    seconds: Float,
    color: Color
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.2f))
            .border(1.dp, color, RoundedCornerShape(12.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = "$name ${ceil(seconds).toInt()}s",
            color = color,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
    }
}
