package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

class GameAudioEngine(private val context: Context) {
    var soundEnabled: Boolean = true
    var vibrationEnabled: Boolean = true

    private val vibrator: Vibrator? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vm?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    } catch (_: Exception) {
        null
    }

    private val sampleRate = 22050

    // Cached pre-rendered AudioTracks for zero latency
    private var laserTrack: AudioTrack? = null
    private var collectTrack: AudioTrack? = null
    private var shieldTrack: AudioTrack? = null
    private var explosionTrack: AudioTrack? = null
    private var powerupTrack: AudioTrack? = null
    private var bombTrack: AudioTrack? = null
    private var warningTrack: AudioTrack? = null

    init {
        try {
            laserTrack = createTrack(generateLaserSound())
            collectTrack = createTrack(generateCollectSound())
            shieldTrack = createTrack(generateShieldSound())
            explosionTrack = createTrack(generateExplosionSound())
            powerupTrack = createTrack(generatePowerupSound())
            bombTrack = createTrack(generateBombSound())
            warningTrack = createTrack(generateWarningSound())
        } catch (_: Exception) {
            // Audio initialization fallback
        }
    }

    private fun createTrack(pcmData: ShortArray): AudioTrack? {
        return try {
            val bufferSize = pcmData.size * 2
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(pcmData, 0, pcmData.size)
            track
        } catch (_: Exception) {
            null
        }
    }

    private fun playTrack(track: AudioTrack?) {
        if (!soundEnabled || track == null) return
        try {
            if (track.playState == AudioTrack.PLAYSTATE_PLAYING) {
                track.stop()
            }
            track.reloadStaticData()
            track.play()
        } catch (_: Exception) {
            // Ignore transient audio error
        }
    }

    fun playLaser() {
        playTrack(laserTrack)
    }

    fun playCollect() {
        playTrack(collectTrack)
        vibrate(10)
    }

    fun playShieldHit() {
        playTrack(shieldTrack)
        vibrate(30)
    }

    fun playExplosion() {
        playTrack(explosionTrack)
        vibrate(60)
    }

    fun playPowerup() {
        playTrack(powerupTrack)
        vibrate(25)
    }

    fun playBomb() {
        playTrack(bombTrack)
        vibrate(100)
    }

    fun playWarning() {
        playTrack(warningTrack)
        vibrate(40)
    }

    fun vibrate(durationMs: Long) {
        if (!vibrationEnabled || vibrator == null) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(
                    VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(durationMs)
            }
        } catch (_: Exception) {
            // Ignore
        }
    }

    fun release() {
        listOf(
            laserTrack,
            collectTrack,
            shieldTrack,
            explosionTrack,
            powerupTrack,
            bombTrack,
            warningTrack
        ).forEach {
            try {
                it?.stop()
                it?.release()
            } catch (_: Exception) {}
        }
    }

    // --- Sound Synthesis Algorithms ---

    private fun generateLaserSound(): ShortArray {
        val durationSec = 0.11f
        val numSamples = (sampleRate * durationSec).toInt()
        val data = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toFloat() / sampleRate
            val progress = i.toFloat() / numSamples
            // Downward pitch sweep from 1100 Hz down to 200 Hz
            val freq = 1100f - 900f * progress
            val amp = (1f - progress) * 0.7f
            val sample = sin(2.0 * PI * freq * t).toFloat() * amp
            data[i] = (sample * Short.MAX_VALUE).toInt().toShort()
        }
        return data
    }

    private fun generateCollectSound(): ShortArray {
        val durationSec = 0.16f
        val numSamples = (sampleRate * durationSec).toInt()
        val data = ShortArray(numSamples)
        val half = numSamples / 2
        for (i in 0 until numSamples) {
            val t = i.toFloat() / sampleRate
            val freq = if (i < half) 660f else 990f
            val progress = (i % half).toFloat() / half
            val amp = (1f - progress) * 0.75f
            val sample = sin(2.0 * PI * freq * t).toFloat() * amp
            data[i] = (sample * Short.MAX_VALUE).toInt().toShort()
        }
        return data
    }

    private fun generateShieldSound(): ShortArray {
        val durationSec = 0.16f
        val numSamples = (sampleRate * durationSec).toInt()
        val data = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toFloat() / sampleRate
            val progress = i.toFloat() / numSamples
            val amp = (1f - progress) * 0.65f
            val s1 = sin(2.0 * PI * 320.0 * t).toFloat()
            val s2 = sin(2.0 * PI * 480.0 * t).toFloat()
            val sample = ((s1 + s2) * 0.5f) * amp
            data[i] = (sample * Short.MAX_VALUE).toInt().toShort()
        }
        return data
    }

    private fun generateExplosionSound(): ShortArray {
        val durationSec = 0.28f
        val numSamples = (sampleRate * durationSec).toInt()
        val data = ShortArray(numSamples)
        var lastVal = 0f
        for (i in 0 until numSamples) {
            val progress = i.toFloat() / numSamples
            val envelope = (1f - progress) * (1f - progress)
            // Low-pass filtered noise for punchy explosion
            val whiteNoise = Random.nextFloat() * 2f - 1f
            lastVal = lastVal * 0.85f + whiteNoise * 0.15f
            val sample = lastVal * envelope * 0.9f
            data[i] = (sample * Short.MAX_VALUE).toInt().coerceIn(-32768, 32767).toShort()
        }
        return data
    }

    private fun generatePowerupSound(): ShortArray {
        val durationSec = 0.24f
        val numSamples = (sampleRate * durationSec).toInt()
        val data = ShortArray(numSamples)
        val step = numSamples / 4
        val freqs = floatArrayOf(440f, 554.37f, 659.25f, 880f)
        for (i in 0 until numSamples) {
            val t = i.toFloat() / sampleRate
            val freqIndex = (i / step).coerceIn(0, 3)
            val freq = freqs[freqIndex]
            val progressInStep = (i % step).toFloat() / step
            val amp = (1f - progressInStep * 0.5f) * 0.8f
            val sample = sin(2.0 * PI * freq * t).toFloat() * amp
            data[i] = (sample * Short.MAX_VALUE).toInt().toShort()
        }
        return data
    }

    private fun generateBombSound(): ShortArray {
        val durationSec = 0.45f
        val numSamples = (sampleRate * durationSec).toInt()
        val data = ShortArray(numSamples)
        var brownNoise = 0f
        for (i in 0 until numSamples) {
            val t = i.toFloat() / sampleRate
            val progress = i.toFloat() / numSamples
            val envelope = exp(-progress * 5f)
            val sineSub = sin(2.0 * PI * (90f - 60f * progress) * t).toFloat()
            val whiteNoise = Random.nextFloat() * 2f - 1f
            brownNoise = (brownNoise + (0.05f * whiteNoise)) / 1.05f
            val sample = (sineSub * 0.6f + brownNoise * 0.7f) * envelope
            data[i] = (sample * Short.MAX_VALUE).toInt().coerceIn(-32768, 32767).toShort()
        }
        return data
    }

    private fun generateWarningSound(): ShortArray {
        val durationSec = 0.2f
        val numSamples = (sampleRate * durationSec).toInt()
        val data = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toFloat() / sampleRate
            val sample = sin(2.0 * PI * 800.0 * t).toFloat() * 0.7f
            data[i] = (sample * Short.MAX_VALUE).toInt().toShort()
        }
        return data
    }
}
