package com.example.game

import androidx.compose.ui.graphics.Color

data class ShipDefinition(
    val id: String,
    val name: String,
    val description: String,
    val primaryColor: Color,
    val secondaryColor: Color,
    val speedMultiplier: Float = 1.0f,
    val startingShields: Int = 0,
    val dashCooldownSec: Float = 3.5f,
    val unlockCost: Int = 0,
    val perkName: String
)

val AVAILABLE_SHIPS = listOf(
    ShipDefinition(
        id = "dart",
        name = "Astro Dart",
        description = "Nimble prototype fighter with well-balanced thrusters and rapid twin cannons.",
        primaryColor = Color(0xFF00F0FF),
        secondaryColor = Color(0xFF38BDF8),
        speedMultiplier = 1.0f,
        startingShields = 0,
        dashCooldownSec = 3.5f,
        unlockCost = 0,
        perkName = "Standard Pulse Drive"
    ),
    ShipDefinition(
        id = "phantom",
        name = "Neon Phantom",
        description = "Advanced stealth interceptor equipped with Phase Dash and reduced cooldowns.",
        primaryColor = Color(0xFFA855F7),
        secondaryColor = Color(0xFFE879F9),
        speedMultiplier = 1.25f,
        startingShields = 0,
        dashCooldownSec = 2.2f,
        unlockCost = 80,
        perkName = "+25% Speed & Rapid Dash"
    ),
    ShipDefinition(
        id = "dreadnought",
        name = "Vanguard Dreadnought",
        description = "Reinforced battle cruiser that deploys with dual defensive plasma shields.",
        primaryColor = Color(0xFFFBBF24),
        secondaryColor = Color(0xFFF59E0B),
        speedMultiplier = 0.9f,
        startingShields = 2,
        dashCooldownSec = 4.0f,
        unlockCost = 150,
        perkName = "Starts with 2 Shields"
    ),
    ShipDefinition(
        id = "phoenix",
        name = "Solar Phoenix",
        description = "Legendary starcraft that releases a miniature EMP shockwave whenever shields shatter.",
        primaryColor = Color(0xFFF43F5E),
        secondaryColor = Color(0xFFFB923C),
        speedMultiplier = 1.1f,
        startingShields = 1,
        dashCooldownSec = 3.0f,
        unlockCost = 250,
        perkName = "Retaliatory EMP Shockwave"
    )
)

enum class ObstacleType {
    ASTEROID_SMALL,
    ASTEROID_MEDIUM,
    ASTEROID_LARGE,
    COMET,
    DRONE,
    BLACK_HOLE
}

data class Obstacle(
    val id: Long,
    val type: ObstacleType,
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val radius: Float,
    var health: Int,
    val maxHealth: Int,
    var rotation: Float = 0f,
    val rotationSpeed: Float = 0f,
    val color: Color,
    val scoreValue: Int,
    var nearMissTriggered: Boolean = false
)

enum class CollectibleType {
    CRYSTAL,
    SHIELD,
    RAPID_BLASTER,
    CHRONO_FREEZE,
    MAGNET,
    NOVA_BOMB
}

data class Collectible(
    val id: Long,
    val type: CollectibleType,
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val radius: Float = 22f,
    var pulse: Float = 0f
)

data class Projectile(
    val id: Long,
    var x: Float,
    var y: Float,
    val vx: Float,
    val vy: Float,
    val radius: Float = 7f,
    val isEnemy: Boolean = false,
    val damage: Int = 1,
    val color: Color = Color(0xFF00F0FF)
)

data class Particle(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var size: Float,
    var alpha: Float = 1.0f,
    val decay: Float = 0.035f,
    val color: Color
)

data class FloatingText(
    val text: String,
    var x: Float,
    var y: Float,
    var vy: Float = -2.0f,
    var alpha: Float = 1.0f,
    val decay: Float = 0.02f,
    val color: Color,
    val sizeSp: Float = 18f
)

data class Star(
    var x: Float,
    var y: Float,
    val speed: Float,
    val size: Float,
    val baseAlpha: Float,
    val color: Color
)

data class Boss(
    var x: Float,
    var y: Float,
    var vx: Float = 2.5f,
    val width: Float = 180f,
    val height: Float = 90f,
    var health: Int = 40,
    val maxHealth: Int = 40,
    var shootTimer: Float = 0f,
    val name: String = "OMEGA DREADNOUGHT"
)

enum class GameMode(val displayName: String) {
    SURVIVAL("Endless Odyssey"),
    TIME_RUSH("60s Star Rush")
}
