package com.example.game

import androidx.compose.ui.graphics.Color
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

class GameEngine(
    val ship: ShipDefinition,
    val mode: GameMode,
    private val onPlayLaser: () -> Unit,
    private val onPlayCollect: () -> Unit,
    private val onPlayShield: () -> Unit,
    private val onPlayExplosion: () -> Unit,
    private val onPlayPowerup: () -> Unit,
    private val onPlayBomb: () -> Unit,
    private val onPlayWarning: () -> Unit
) {
    var screenWidth = 1080f
    var screenHeight = 1920f
    private var initialized = false

    // Player State
    var playerX = 540f
    var playerY = 1500f
    var targetX = 540f
    var targetY = 1500f
    val playerRadius = 26f

    var health = 3
    val maxHealth = 3
    var shields = ship.startingShields
    val maxShields = 3
    var bombs = 1
    val maxBombs = 3

    var isInvulnerable = false
    var invulnerableTimer = 0f

    var dashCooldownTimer = 0f
    var dashActiveTimer = 0f
    val isDashing: Boolean get() = dashActiveTimer > 0f

    // Power-up Active Timers
    var rapidBlasterTimer = 0f
    var chronoFreezeTimer = 0f
    var magnetTimer = 0f

    // Auto shoot timer
    private var shootCooldown = 0f

    // Scoring & Progression
    var score = 0
    var crystalsInRun = 0
    var combo = 1
    var comboTimer = 0f
    var maxCombo = 1
    var nearMisses = 0
    var asteroidsDestroyed = 0
    var bossesDefeated = 0

    // Time Rush mode
    var timeRemaining = 60f
    var gameTime = 0f

    // Screen Shake
    var screenShake = 0f

    // Boss
    var boss: Boss? = null
    private var nextBossScoreThreshold = 500

    // Game state
    var isGameOver = false
    var isPaused = false

    // Entities
    val obstacles = mutableListOf<Obstacle>()
    val projectiles = mutableListOf<Projectile>()
    val collectibles = mutableListOf<Collectible>()
    val particles = mutableListOf<Particle>()
    val floatingTexts = mutableListOf<FloatingText>()
    val stars = mutableListOf<Star>()

    private var nextEntityId = 1L
    private var obstacleSpawnTimer = 0f

    fun initDimensions(width: Float, height: Float) {
        if (width <= 0f || height <= 0f) return
        screenWidth = width
        screenHeight = height

        if (!initialized) {
            playerX = width / 2f
            playerY = height * 0.8f
            targetX = playerX
            targetY = playerY

            // Initialize parallax starfield
            stars.clear()
            for (i in 0 until 80) {
                val speed = Random.nextFloat() * 3.5f + 0.8f
                val size = Random.nextFloat() * 3.0f + 1.2f
                val baseAlpha = Random.nextFloat() * 0.6f + 0.3f
                val starColor = when (Random.nextInt(4)) {
                    0 -> Color(0xFF00F0FF)
                    1 -> Color(0xFFE879F9)
                    2 -> Color(0xFFFBBF24)
                    else -> Color(0xFFFFFFFF)
                }
                stars.add(
                    Star(
                        x = Random.nextFloat() * width,
                        y = Random.nextFloat() * height,
                        speed = speed,
                        size = size,
                        baseAlpha = baseAlpha,
                        color = starColor
                    )
                )
            }
            initialized = true
        }
    }

    fun onTouchMove(touchX: Float, touchY: Float) {
        if (isGameOver || isPaused) return
        targetX = touchX.coerceIn(playerRadius, screenWidth - playerRadius)
        targetY = touchY.coerceIn(playerRadius + 50f, screenHeight - playerRadius - 30f)
    }

    fun triggerDash() {
        if (dashCooldownTimer <= 0f && !isGameOver && !isPaused) {
            dashCooldownTimer = ship.dashCooldownSec
            dashActiveTimer = 0.28f
            invulnerableTimer = 0.45f
            isInvulnerable = true
            onPlayLaser()

            // Spawn dash particle rings
            for (i in 0 until 16) {
                val angle = (i.toFloat() / 16f) * 2f * Math.PI.toFloat()
                particles.add(
                    Particle(
                        x = playerX,
                        y = playerY,
                        vx = cos(angle) * 7f,
                        vy = sin(angle) * 7f,
                        size = 5f,
                        decay = 0.05f,
                        color = ship.primaryColor
                    )
                )
            }
        }
    }

    fun triggerBomb() {
        if (bombs > 0 && !isGameOver && !isPaused) {
            bombs--
            screenShake = 22f
            onPlayBomb()

            floatingTexts.add(
                FloatingText(
                    text = "SUPERNOVA EMP!",
                    x = playerX,
                    y = playerY - 40f,
                    color = Color(0xFF00F0FF),
                    sizeSp = 24f
                )
            )

            // Convert all screen obstacles into particles and crystals
            obstacles.forEach { obs ->
                spawnExplosion(obs.x, obs.y, obs.color, 24)
                score += obs.scoreValue
                asteroidsDestroyed++
                if (Random.nextFloat() < 0.6f) {
                    collectibles.add(
                        Collectible(
                            id = nextEntityId++,
                            type = CollectibleType.CRYSTAL,
                            x = obs.x,
                            y = obs.y,
                            vx = (Random.nextFloat() - 0.5f) * 4f,
                            vy = Random.nextFloat() * 3f + 1f
                        )
                    )
                }
            }
            obstacles.clear()

            // Damage boss heavily if active
            boss?.let { b ->
                b.health -= 15
                spawnExplosion(b.x, b.y, Color(0xFFF43F5E), 30)
                if (b.health <= 0) {
                    defeatBoss(b)
                }
            }

            // Shockwave particles
            for (i in 0 until 36) {
                val angle = (i.toFloat() / 36f) * 2f * Math.PI.toFloat()
                particles.add(
                    Particle(
                        x = screenWidth / 2f,
                        y = screenHeight / 2f,
                        vx = cos(angle) * 12f,
                        vy = sin(angle) * 12f,
                        size = 7f,
                        decay = 0.025f,
                        color = Color(0xFF00F0FF)
                    )
                )
            }
        }
    }

    fun update(deltaSec: Float) {
        if (isGameOver || isPaused || !initialized) return

        val dt = deltaSec.coerceIn(0.001f, 0.05f)
        gameTime += dt

        // Time Rush mode countdown
        if (mode == GameMode.TIME_RUSH) {
            timeRemaining -= dt
            if (timeRemaining <= 0f) {
                timeRemaining = 0f
                endGame()
                return
            }
        }

        // Screen shake decay
        if (screenShake > 0f) {
            screenShake = max(0f, screenShake - dt * 25f)
        }

        // Timers decay
        if (dashCooldownTimer > 0f) dashCooldownTimer = max(0f, dashCooldownTimer - dt)
        if (dashActiveTimer > 0f) dashActiveTimer = max(0f, dashActiveTimer - dt)
        if (invulnerableTimer > 0f) {
            invulnerableTimer = max(0f, invulnerableTimer - dt)
            isInvulnerable = invulnerableTimer > 0f
        }
        if (rapidBlasterTimer > 0f) rapidBlasterTimer = max(0f, rapidBlasterTimer - dt)
        if (chronoFreezeTimer > 0f) chronoFreezeTimer = max(0f, chronoFreezeTimer - dt)
        if (magnetTimer > 0f) magnetTimer = max(0f, magnetTimer - dt)

        // Combo decay
        if (comboTimer > 0f) {
            comboTimer = max(0f, comboTimer - dt)
            if (comboTimer == 0f) {
                combo = 1
            }
        }

        // Update player position with smooth interpolation
        val lerpFactor = if (isDashing) 0.35f else 0.16f * ship.speedMultiplier
        playerX += (targetX - playerX) * lerpFactor
        playerY += (targetY - playerY) * lerpFactor

        // Thruster particles
        if (Random.nextFloat() < 0.85f) {
            particles.add(
                Particle(
                    x = playerX + (Random.nextFloat() - 0.5f) * 14f,
                    y = playerY + playerRadius - 2f,
                    vx = (Random.nextFloat() - 0.5f) * 1.5f,
                    vy = Random.nextFloat() * 4f + 3f,
                    size = Random.nextFloat() * 4f + 2f,
                    decay = 0.06f,
                    color = if (isDashing) Color(0xFF00F0FF) else ship.secondaryColor
                )
            )
        }

        // Starfield scroll
        val starSpeedMult = if (chronoFreezeTimer > 0f) 0.5f else 1.0f
        stars.forEach { s ->
            s.y += s.speed * starSpeedMult * (if (isDashing) 2.5f else 1.0f)
            if (s.y > screenHeight) {
                s.y = 0f
                s.x = Random.nextFloat() * screenWidth
            }
        }

        // Auto Firing Lasers
        shootCooldown -= dt
        val fireRate = if (rapidBlasterTimer > 0f) 0.11f else 0.22f
        if (shootCooldown <= 0f) {
            shootCooldown = fireRate
            fireLasers()
        }

        // Spawn Boss Check
        if (mode == GameMode.SURVIVAL && score >= nextBossScoreThreshold && boss == null) {
            spawnBoss()
        }

        // Spawn Obstacles & Collectibles
        val timeScale = if (chronoFreezeTimer > 0f) 0.35f else 1.0f
        obstacleSpawnTimer += dt * timeScale
        val spawnInterval = max(0.45f, 1.4f - (score / 1500f) * 0.6f)
        if (obstacleSpawnTimer >= spawnInterval) {
            obstacleSpawnTimer = 0f
            spawnRandomHazard()
        }

        // Update Obstacles
        val obstacleIterator = obstacles.iterator()
        while (obstacleIterator.hasNext()) {
            val obs = obstacleIterator.next()
            obs.x += obs.vx * timeScale
            obs.y += obs.vy * timeScale
            obs.rotation += obs.rotationSpeed * timeScale

            // Homing Drone behaviour
            if (obs.type == ObstacleType.DRONE) {
                val dx = playerX - obs.x
                obs.vx += (dx * 0.003f).coerceIn(-0.15f, 0.15f)
            }

            // Near Miss Check
            if (!obs.nearMissTriggered && !isInvulnerable) {
                val dist = distance(playerX, playerY, obs.x, obs.y)
                val hitDistance = playerRadius + obs.radius
                if (dist > hitDistance && dist < hitDistance + 50f && obs.y > playerY - 30f && obs.y < playerY + 30f) {
                    obs.nearMissTriggered = true
                    triggerNearMiss(obs)
                }
            }

            // Player Collision Check
            val distToPlayer = distance(playerX, playerY, obs.x, obs.y)
            if (distToPlayer < (playerRadius + obs.radius)) {
                if (!isInvulnerable) {
                    handlePlayerHit(obs)
                }
            }

            // Remove out of bounds
            if (obs.y > screenHeight + obs.radius * 2 || obs.x < -obs.radius * 3 || obs.x > screenWidth + obs.radius * 3) {
                obstacleIterator.remove()
            }
        }

        // Update Boss
        boss?.let { b ->
            b.x += b.vx * timeScale
            if (b.x < b.width / 2f + 30f || b.x > screenWidth - b.width / 2f - 30f) {
                b.vx = -b.vx
            }

            b.shootTimer += dt * timeScale
            if (b.shootTimer > 1.2f) {
                b.shootTimer = 0f
                // Boss fires plasma spread
                for (angleOffset in listOf(-0.35f, 0f, 0.35f)) {
                    projectiles.add(
                        Projectile(
                            id = nextEntityId++,
                            x = b.x,
                            y = b.y + b.height / 2f,
                            vx = sin(angleOffset) * 5f,
                            vy = cos(angleOffset) * 6f,
                            radius = 9f,
                            isEnemy = true,
                            damage = 1,
                            color = Color(0xFFF43F5E)
                        )
                    )
                }
            }
        }

        // Update Projectiles
        val projIterator = projectiles.iterator()
        while (projIterator.hasNext()) {
            val p = projIterator.next()
            p.x += p.vx * (if (p.isEnemy) timeScale else 1.0f)
            p.y += p.vy * (if (p.isEnemy) timeScale else 1.0f)

            if (p.isEnemy) {
                // Enemy projectile hitting player
                if (!isInvulnerable && distance(p.x, p.y, playerX, playerY) < (p.radius + playerRadius)) {
                    projIterator.remove()
                    handlePlayerHit(null)
                    continue
                }
            } else {
                // Player projectile hitting boss
                boss?.let { b ->
                    if (p.x >= b.x - b.width / 2f && p.x <= b.x + b.width / 2f &&
                        p.y >= b.y - b.height / 2f && p.y <= b.y + b.height / 2f
                    ) {
                        b.health -= p.damage
                        spawnExplosion(p.x, p.y, Color(0xFF00F0FF), 5)
                        projIterator.remove()
                        if (b.health <= 0) {
                            defeatBoss(b)
                        }
                        return@let
                    }
                }

                // Player projectile hitting obstacles
                for (obs in obstacles) {
                    if (distance(p.x, p.y, obs.x, obs.y) < (p.radius + obs.radius)) {
                        obs.health -= p.damage
                        spawnExplosion(p.x, p.y, p.color, 6)
                        projIterator.remove()

                        if (obs.health <= 0) {
                            destroyObstacle(obs)
                        }
                        break
                    }
                }
            }

            // Remove out of bounds
            if (p.y < -30f || p.y > screenHeight + 30f || p.x < -30f || p.x > screenWidth + 30f) {
                projIterator.remove()
            }
        }

        // Update Collectibles
        val colIterator = collectibles.iterator()
        while (colIterator.hasNext()) {
            val c = colIterator.next()
            c.pulse = (c.pulse + dt * 4f) % (2f * Math.PI.toFloat())

            // Magnet effect or normal float
            val distToPlayer = distance(c.x, c.y, playerX, playerY)
            val magnetRange = if (magnetTimer > 0f) 420f else 110f
            if (distToPlayer < magnetRange) {
                val angle = atan2(playerY - c.y, playerX - c.x)
                val pullSpeed = if (magnetTimer > 0f) 14f else 8f
                c.vx = cos(angle) * pullSpeed
                c.vy = sin(angle) * pullSpeed
            }

            c.x += c.vx
            c.y += c.vy

            // Collect
            if (distToPlayer < (c.radius + playerRadius)) {
                applyCollectible(c)
                colIterator.remove()
                continue
            }

            if (c.y > screenHeight + 40f) {
                colIterator.remove()
            }
        }

        // Update Particles
        val partIterator = particles.iterator()
        while (partIterator.hasNext()) {
            val part = partIterator.next()
            part.x += part.vx
            part.y += part.vy
            part.alpha -= part.decay
            if (part.alpha <= 0f) {
                partIterator.remove()
            }
        }

        // Update Floating Texts
        val textIterator = floatingTexts.iterator()
        while (textIterator.hasNext()) {
            val ft = textIterator.next()
            ft.y += ft.vy
            ft.alpha -= ft.decay
            if (ft.alpha <= 0f) {
                textIterator.remove()
            }
        }
    }

    private fun fireLasers() {
        onPlayLaser()
        val isRapid = rapidBlasterTimer > 0f
        if (isRapid) {
            // Triple spread blasters
            projectiles.add(Projectile(id = nextEntityId++, x = playerX, y = playerY - playerRadius, vx = 0f, vy = -22f, color = Color(0xFF00F0FF)))
            projectiles.add(Projectile(id = nextEntityId++, x = playerX - 16f, y = playerY - playerRadius + 5f, vx = -3f, vy = -20f, color = Color(0xFF38BDF8)))
            projectiles.add(Projectile(id = nextEntityId++, x = playerX + 16f, y = playerY - playerRadius + 5f, vx = 3f, vy = -20f, color = Color(0xFF38BDF8)))
        } else {
            // Twin blasters
            projectiles.add(Projectile(id = nextEntityId++, x = playerX - 12f, y = playerY - playerRadius, vx = 0f, vy = -20f, color = ship.primaryColor))
            projectiles.add(Projectile(id = nextEntityId++, x = playerX + 12f, y = playerY - playerRadius, vx = 0f, vy = -20f, color = ship.primaryColor))
        }
    }

    private fun spawnRandomHazard() {
        val typeRoll = Random.nextFloat()
        val x = Random.nextFloat() * (screenWidth - 100f) + 50f
        val y = -60f

        when {
            typeRoll < 0.38f -> {
                // Small Asteroid
                obstacles.add(
                    Obstacle(
                        id = nextEntityId++,
                        type = ObstacleType.ASTEROID_SMALL,
                        x = x,
                        y = y,
                        vx = (Random.nextFloat() - 0.5f) * 2f,
                        vy = Random.nextFloat() * 4f + 4.5f,
                        radius = 24f,
                        health = 1,
                        maxHealth = 1,
                        rotationSpeed = (Random.nextFloat() - 0.5f) * 3f,
                        color = Color(0xFFCBD5E1),
                        scoreValue = 20
                    )
                )
            }
            typeRoll < 0.65f -> {
                // Medium Asteroid
                obstacles.add(
                    Obstacle(
                        id = nextEntityId++,
                        type = ObstacleType.ASTEROID_MEDIUM,
                        x = x,
                        y = y,
                        vx = (Random.nextFloat() - 0.5f) * 1.5f,
                        vy = Random.nextFloat() * 3f + 3f,
                        radius = 38f,
                        health = 2,
                        maxHealth = 2,
                        rotationSpeed = (Random.nextFloat() - 0.5f) * 2f,
                        color = Color(0xFF94A3B8),
                        scoreValue = 40
                    )
                )
            }
            typeRoll < 0.82f -> {
                // Large Asteroid (Splits on destruction!)
                obstacles.add(
                    Obstacle(
                        id = nextEntityId++,
                        type = ObstacleType.ASTEROID_LARGE,
                        x = x,
                        y = y,
                        vx = (Random.nextFloat() - 0.5f) * 1.0f,
                        vy = Random.nextFloat() * 2f + 2.2f,
                        radius = 56f,
                        health = 4,
                        maxHealth = 4,
                        rotationSpeed = (Random.nextFloat() - 0.5f) * 1.5f,
                        color = Color(0xFF64748B),
                        scoreValue = 80
                    )
                )
            }
            typeRoll < 0.92f -> {
                // Diagonal Comet (Fast!)
                val vx = if (x > screenWidth / 2f) -3.5f else 3.5f
                obstacles.add(
                    Obstacle(
                        id = nextEntityId++,
                        type = ObstacleType.COMET,
                        x = x,
                        y = y,
                        vx = vx,
                        vy = Random.nextFloat() * 4f + 7f,
                        radius = 22f,
                        health = 1,
                        maxHealth = 1,
                        rotationSpeed = 4f,
                        color = Color(0xFFFB923C),
                        scoreValue = 50
                    )
                )
            }
            else -> {
                // Hunter Drone
                obstacles.add(
                    Obstacle(
                        id = nextEntityId++,
                        type = ObstacleType.DRONE,
                        x = x,
                        y = y,
                        vx = 0f,
                        vy = Random.nextFloat() * 2f + 3.2f,
                        radius = 28f,
                        health = 2,
                        maxHealth = 2,
                        color = Color(0xFFF43F5E),
                        scoreValue = 60
                    )
                )
            }
        }

        // Chance to spawn separate powerup or crystal
        if (Random.nextFloat() < 0.28f) {
            spawnRandomCollectible(Random.nextFloat() * (screenWidth - 100f) + 50f, -40f)
        }
    }

    private fun spawnRandomCollectible(x: Float, y: Float) {
        val roll = Random.nextFloat()
        val type = when {
            roll < 0.45f -> CollectibleType.CRYSTAL
            roll < 0.62f -> CollectibleType.SHIELD
            roll < 0.77f -> CollectibleType.RAPID_BLASTER
            roll < 0.88f -> CollectibleType.MAGNET
            roll < 0.96f -> CollectibleType.CHRONO_FREEZE
            else -> CollectibleType.NOVA_BOMB
        }
        collectibles.add(
            Collectible(
                id = nextEntityId++,
                type = type,
                x = x,
                y = y,
                vx = (Random.nextFloat() - 0.5f) * 1.5f,
                vy = Random.nextFloat() * 2f + 2.5f
            )
        )
    }

    private fun destroyObstacle(obs: Obstacle) {
        obstacles.remove(obs)
        asteroidsDestroyed++
        score += obs.scoreValue * combo
        addCombo()
        spawnExplosion(obs.x, obs.y, obs.color, 16)
        onPlayExplosion()

        // Large asteroid split into 2 smaller ones
        if (obs.type == ObstacleType.ASTEROID_LARGE) {
            for (i in -1..1 step 2) {
                obstacles.add(
                    Obstacle(
                        id = nextEntityId++,
                        type = ObstacleType.ASTEROID_SMALL,
                        x = obs.x + i * 20f,
                        y = obs.y,
                        vx = i * (Random.nextFloat() * 2f + 2f),
                        vy = obs.vy + 1.5f,
                        radius = 24f,
                        health = 1,
                        maxHealth = 1,
                        rotationSpeed = (Random.nextFloat() - 0.5f) * 4f,
                        color = Color(0xFFCBD5E1),
                        scoreValue = 30
                    )
                )
            }
        }

        // Spawn drop
        if (Random.nextFloat() < 0.4f) {
            spawnRandomCollectible(obs.x, obs.y)
        }
    }

    private fun spawnBoss() {
        boss = Boss(
            x = screenWidth / 2f,
            y = 180f,
            vx = 3.2f,
            health = 50 + (score / 40),
            maxHealth = 50 + (score / 40)
        )
        onPlayWarning()
        screenShake = 15f
        floatingTexts.add(
            FloatingText(
                text = "WARNING: BOSS ARRIVAL!",
                x = screenWidth / 2f,
                y = 260f,
                color = Color(0xFFF43F5E),
                sizeSp = 24f
            )
        )
    }

    private fun defeatBoss(b: Boss) {
        boss = null
        bossesDefeated++
        nextBossScoreThreshold += 800
        score += 500 * combo
        addCombo()
        screenShake = 25f
        onPlayExplosion()

        // Shower of crystals and powerups
        for (i in 0 until 10) {
            collectibles.add(
                Collectible(
                    id = nextEntityId++,
                    type = CollectibleType.CRYSTAL,
                    x = b.x + (Random.nextFloat() - 0.5f) * b.width,
                    y = b.y + (Random.nextFloat() - 0.5f) * b.height,
                    vx = (Random.nextFloat() - 0.5f) * 6f,
                    vy = Random.nextFloat() * 4f + 2f
                )
            )
        }
        spawnRandomCollectible(b.x, b.y)
        spawnExplosion(b.x, b.y, Color(0xFFF43F5E), 45)

        floatingTexts.add(
            FloatingText(
                text = "TITAN DESTROYED! +500",
                x = screenWidth / 2f,
                y = 300f,
                color = Color(0xFFFBBF24),
                sizeSp = 26f
            )
        )
    }

    private fun triggerNearMiss(obs: Obstacle) {
        nearMisses++
        score += 50 * combo
        addCombo()
        floatingTexts.add(
            FloatingText(
                text = "CLOSE CALL! +${50 * combo}",
                x = playerX,
                y = playerY - 35f,
                color = Color(0xFF38BDF8),
                sizeSp = 18f
            )
        )
    }

    private fun addCombo() {
        combo = min(10, combo + 1)
        comboTimer = 3.5f
        maxCombo = max(maxCombo, combo)
    }

    private fun handlePlayerHit(obs: Obstacle?) {
        if (isInvulnerable) return

        if (shields > 0) {
            shields--
            onPlayShield()
            screenShake = 12f
            isInvulnerable = true
            invulnerableTimer = 1.2f

            // Phoenix ship perk: EMP Shockwave on shield break!
            if (ship.id == "phoenix") {
                triggerBomb()
            }

            floatingTexts.add(
                FloatingText(
                    text = "SHIELD ABSORBED HIT!",
                    x = playerX,
                    y = playerY - 35f,
                    color = Color(0xFF00F0FF),
                    sizeSp = 18f
                )
            )
            spawnExplosion(playerX, playerY, Color(0xFF00F0FF), 18)
        } else {
            health--
            combo = 1
            screenShake = 20f
            onPlayExplosion()
            isInvulnerable = true
            invulnerableTimer = 1.8f
            spawnExplosion(playerX, playerY, Color(0xFFF43F5E), 26)

            if (health <= 0) {
                endGame()
            }
        }

        obs?.let {
            obstacles.remove(it)
        }
    }

    private fun applyCollectible(c: Collectible) {
        onPlayCollect()
        when (c.type) {
            CollectibleType.CRYSTAL -> {
                crystalsInRun++
                score += 30 * combo
                addCombo()
                floatingTexts.add(
                    FloatingText(
                        text = "+30",
                        x = c.x,
                        y = c.y,
                        color = Color(0xFFFBBF24),
                        sizeSp = 16f
                    )
                )
            }
            CollectibleType.SHIELD -> {
                shields = min(maxShields, shields + 1)
                onPlayPowerup()
                floatingTexts.add(
                    FloatingText(
                        text = "PLASMA SHIELD READY!",
                        x = playerX,
                        y = playerY - 40f,
                        color = Color(0xFF00F0FF),
                        sizeSp = 20f
                    )
                )
            }
            CollectibleType.RAPID_BLASTER -> {
                rapidBlasterTimer = 10f
                onPlayPowerup()
                floatingTexts.add(
                    FloatingText(
                        text = "RAPID TRIPLE BLASTER!",
                        x = playerX,
                        y = playerY - 40f,
                        color = Color(0xFF38BDF8),
                        sizeSp = 20f
                    )
                )
            }
            CollectibleType.CHRONO_FREEZE -> {
                chronoFreezeTimer = 6f
                onPlayPowerup()
                floatingTexts.add(
                    FloatingText(
                        text = "CHRONO WARP (SLOW TIME)!",
                        x = screenWidth / 2f,
                        y = screenHeight / 2f,
                        color = Color(0xFFE879F9),
                        sizeSp = 22f
                    )
                )
            }
            CollectibleType.MAGNET -> {
                magnetTimer = 8f
                onPlayPowerup()
                floatingTexts.add(
                    FloatingText(
                        text = "STAR MAGNET ACTIVE!",
                        x = playerX,
                        y = playerY - 40f,
                        color = Color(0xFF10B981),
                        sizeSp = 20f
                    )
                )
            }
            CollectibleType.NOVA_BOMB -> {
                bombs = min(maxBombs, bombs + 1)
                onPlayPowerup()
                floatingTexts.add(
                    FloatingText(
                        text = "+1 NOVA BOMB!",
                        x = playerX,
                        y = playerY - 40f,
                        color = Color(0xFFFB923C),
                        sizeSp = 20f
                    )
                )
            }
        }
    }

    private fun spawnExplosion(x: Float, y: Float, color: Color, count: Int) {
        for (i in 0 until count) {
            val angle = Random.nextFloat() * 2f * Math.PI.toFloat()
            val speed = Random.nextFloat() * 8f + 2f
            particles.add(
                Particle(
                    x = x,
                    y = y,
                    vx = cos(angle) * speed,
                    vy = sin(angle) * speed,
                    size = Random.nextFloat() * 6f + 3f,
                    decay = Random.nextFloat() * 0.04f + 0.025f,
                    color = color
                )
            )
        }
    }

    private fun distance(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x1 - x2
        val dy = y1 - y2
        return sqrt(dx * dx + dy * dy)
    }

    fun endGame() {
        isGameOver = true
        onPlayExplosion()
    }
}
