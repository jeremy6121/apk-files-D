package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "game_scores")
data class GameScoreRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val score: Int,
    val crystals: Int,
    val maxCombo: Int,
    val shipName: String,
    val gameMode: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "player_profile")
data class PlayerProfile(
    @PrimaryKey
    val id: Int = 1,
    val totalCrystals: Int = 0,
    val totalGamesPlayed: Int = 0,
    val unlockedShips: String = "dart", // comma-separated ship IDs
    val selectedShipId: String = "dart",
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true
)
