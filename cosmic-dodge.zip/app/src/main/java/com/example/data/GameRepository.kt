package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class GameRepository(private val dao: GameDao) {
    val highScores: Flow<List<GameScoreRecord>> = dao.getHighScores()
    val profile: Flow<PlayerProfile?> = dao.getProfile()

    suspend fun ensureProfileInitialized() = withContext(Dispatchers.IO) {
        if (dao.getProfileSync() == null) {
            dao.insertProfile(PlayerProfile())
        }
    }

    suspend fun saveGameResult(
        score: Int,
        crystals: Int,
        maxCombo: Int,
        shipName: String,
        gameMode: String
    ) = withContext(Dispatchers.IO) {
        val record = GameScoreRecord(
            score = score,
            crystals = crystals,
            maxCombo = maxCombo,
            shipName = shipName,
            gameMode = gameMode
        )
        dao.insertScore(record)

        val currentProfile = dao.getProfileSync() ?: PlayerProfile()
        val updated = currentProfile.copy(
            totalCrystals = currentProfile.totalCrystals + crystals,
            totalGamesPlayed = currentProfile.totalGamesPlayed + 1
        )
        dao.updateProfile(updated)
    }

    suspend fun unlockShip(shipId: String, cost: Int): Boolean = withContext(Dispatchers.IO) {
        val currentProfile = dao.getProfileSync() ?: return@withContext false
        if (currentProfile.totalCrystals >= cost) {
            val unlockedSet = currentProfile.unlockedShips.split(",").toMutableSet()
            unlockedSet.add(shipId)
            val updated = currentProfile.copy(
                totalCrystals = currentProfile.totalCrystals - cost,
                unlockedShips = unlockedSet.joinToString(",")
            )
            dao.updateProfile(updated)
            true
        } else {
            false
        }
    }

    suspend fun selectShip(shipId: String) = withContext(Dispatchers.IO) {
        val currentProfile = dao.getProfileSync() ?: return@withContext
        dao.updateProfile(currentProfile.copy(selectedShipId = shipId))
    }

    suspend fun updateSettings(soundEnabled: Boolean, vibrationEnabled: Boolean) = withContext(Dispatchers.IO) {
        val currentProfile = dao.getProfileSync() ?: return@withContext
        dao.updateProfile(
            currentProfile.copy(
                soundEnabled = soundEnabled,
                vibrationEnabled = vibrationEnabled
            )
        )
    }
}
