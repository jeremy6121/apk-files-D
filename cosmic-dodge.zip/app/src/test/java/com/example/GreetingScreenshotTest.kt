package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.game.AVAILABLE_SHIPS
import com.example.game.GameMode
import com.example.ui.MainMenuScreen
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun greeting_screenshot() {
    composeTestRule.setContent {
      MyApplicationTheme {
        MainMenuScreen(
          selectedShip = AVAILABLE_SHIPS.first(),
          selectedMode = GameMode.SURVIVAL,
          totalCrystals = 120,
          highScore = 450,
          soundEnabled = true,
          vibrationEnabled = true,
          onSelectMode = {},
          onStartGame = {},
          onOpenHangar = {},
          onOpenLeaderboard = {},
          onToggleSound = {},
          onToggleVibration = {}
        )
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
  }
}

