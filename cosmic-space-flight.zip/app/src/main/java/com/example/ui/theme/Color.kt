package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CosmicCyan = Color(0xFF38BDF8)
val CosmicBlue = Color(0xFF0284C7)
val CosmicDark = Color(0xFF070B19)
val CosmicSurface = Color(0xFF0F172A)
val CosmicCard = Color(0xFF1E293B)
val CosmicAmber = Color(0xFFFBBF24)
val CosmicGreen = Color(0xFF4ADE80)
val CosmicRed = Color(0xFFEF4444)
