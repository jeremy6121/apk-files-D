package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CosmicDarkColorScheme = darkColorScheme(
    primary = CosmicCyan,
    onPrimary = Color.Black,
    primaryContainer = CosmicBlue,
    onPrimaryContainer = Color.White,
    secondary = CosmicAmber,
    onSecondary = Color.Black,
    background = CosmicDark,
    onBackground = Color(0xFFF8FAFC),
    surface = CosmicSurface,
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = CosmicCard,
    onSurfaceVariant = Color(0xFF94A3B8)
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = CosmicDarkColorScheme,
        typography = Typography,
        content = content
    )
}
