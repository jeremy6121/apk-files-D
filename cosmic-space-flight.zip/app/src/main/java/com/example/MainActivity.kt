package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.cosmic.ui.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val gameViewModel: GameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize()
                ) {
                    CosmicApp(viewModel = gameViewModel)
                }
            }
        }
    }
}

@Composable
fun CosmicApp(viewModel: GameViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()

    // Handle back button on Android navigation
    BackHandler(enabled = currentScreen != AppScreen.MAIN_MENU) {
        when (currentScreen) {
            AppScreen.BUILDER -> viewModel.navigateTo(AppScreen.MAIN_MENU)
            AppScreen.FLIGHT -> viewModel.togglePause()
            AppScreen.MISSIONS -> viewModel.navigateTo(AppScreen.MAIN_MENU)
            AppScreen.FLEET -> viewModel.navigateTo(AppScreen.MAIN_MENU)
            AppScreen.CREW -> viewModel.navigateTo(AppScreen.MAIN_MENU)
            AppScreen.TECH_TREE -> viewModel.navigateTo(AppScreen.MAIN_MENU)
            AppScreen.SETTINGS -> viewModel.navigateTo(AppScreen.MAIN_MENU)
            AppScreen.MAIN_MENU -> { /* default exit */ }
        }
    }

    when (currentScreen) {
        AppScreen.MAIN_MENU -> MainMenuScreen(viewModel = viewModel)
        AppScreen.BUILDER -> RocketBuilderScreen(viewModel = viewModel)
        AppScreen.FLIGHT -> FlightScreen(viewModel = viewModel)
        AppScreen.MISSIONS -> MissionsScreen(viewModel = viewModel)
        AppScreen.FLEET -> FleetScreen(viewModel = viewModel, onBack = { viewModel.navigateTo(AppScreen.MAIN_MENU) })
        AppScreen.CREW -> CrewScreen(viewModel = viewModel, onBack = { viewModel.navigateTo(AppScreen.MAIN_MENU) })
        AppScreen.TECH_TREE -> TechTreeScreen(viewModel = viewModel, onBack = { viewModel.navigateTo(AppScreen.MAIN_MENU) })
        AppScreen.SETTINGS -> MainMenuScreen(viewModel = viewModel)
    }
}
