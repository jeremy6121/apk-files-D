package com.example.cosmic.physics

import com.example.cosmic.math.Vector3D
import kotlin.math.*

data class OrbitalElements(
    val semiMajorAxis: Double,
    val eccentricity: Double,
    val apoapsisRadius: Double,
    val periapsisRadius: Double,
    val apoapsisAltitude: Double,
    val periapsisAltitude: Double,
    val orbitalPeriod: Double,
    val trueAnomaly: Double,
    val isEscapeTrajectory: Boolean,
    val isStableOrbit: Boolean
)

data class TransferPlan(
    val targetName: String,
    val departureDeltaV: Double, // in m/s
    val arrivalDeltaV: Double,   // in m/s
    val transferTimeSeconds: Double,
    val phaseAngleDeg: Double
) {
    val totalDeltaV: Double get() = departureDeltaV + arrivalDeltaV
}

data class InterceptInfo(
    val closestDistance: Double,
    val relativeSpeed: Double,
    val timeToClosestApproach: Double,
    val isEncounter: Boolean
)

object OrbitalMath {

    /**
     * Computes Keplerian orbital elements for a body orbiting a primary body.
     */
    fun computeOrbit(
        posRel: Vector3D,
        velRel: Vector3D,
        primary: CelestialBody
    ): OrbitalElements {
        val r = posRel.length().coerceAtLeast(10.0)
        val v = velRel.length()
        val mu = primary.mu

        // Specific orbital energy: epsilon = v^2 / 2 - mu / r
        val energy = (v * v) / 2.0 - (mu / r)

        // Specific angular momentum: h = r x v
        val h = posRel.cross(velRel)
        val hMag = h.length()

        // Semi-major axis: a = -mu / (2 * energy)
        val a = if (abs(energy) > 1e-7) -mu / (2.0 * energy) else Double.POSITIVE_INFINITY

        // Eccentricity vector: e = (v x h) / mu - (r / |r|)
        val vCrossH = velRel.cross(h)
        val eVec = (vCrossH / mu) - (posRel / r)
        val e = eVec.length()

        val isHyperbolic = e >= 1.0 || energy >= 0.0

        val apoapsisRadius = if (isHyperbolic) Double.POSITIVE_INFINITY else a * (1.0 + e)
        val periapsisRadius = if (isHyperbolic) {
            if (hMag > 1e-4) (hMag * hMag) / (mu * (1.0 + e)) else r
        } else {
            a * (1.0 - e)
        }

        val apoapsisAltitude = if (isHyperbolic) Double.POSITIVE_INFINITY else apoapsisRadius - primary.radius
        val periapsisAltitude = periapsisRadius - primary.radius

        val period = if (a > 0 && !isHyperbolic) {
            2.0 * Math.PI * sqrt((a * a * a) / mu)
        } else {
            0.0
        }

        // Angle between r and periapsis vector
        val trueAnomaly = if (e > 1e-5) {
            val cosNu = (eVec.dot(posRel) / (e * r)).coerceIn(-1.0, 1.0)
            val nu = acos(cosNu)
            if (posRel.dot(velRel) < 0) 2.0 * Math.PI - nu else nu
        } else 0.0

        val isStable = !isHyperbolic && periapsisAltitude > primary.atmosphereHeight

        return OrbitalElements(
            semiMajorAxis = a,
            eccentricity = e,
            apoapsisRadius = apoapsisRadius,
            periapsisRadius = periapsisRadius,
            apoapsisAltitude = apoapsisAltitude,
            periapsisAltitude = periapsisAltitude,
            orbitalPeriod = period,
            trueAnomaly = trueAnomaly,
            isEscapeTrajectory = isHyperbolic,
            isStableOrbit = isStable
        )
    }

    /**
     * Computes the theoretical circular orbital speed at a given altitude.
     */
    fun circularOrbitSpeed(primary: CelestialBody, altitude: Double): Double {
        val r = primary.radius + altitude
        return sqrt(primary.mu / r)
    }

    /**
     * Computes simplified Hohmann Transfer planning between orbits or to target body.
     */
    fun planHohmannTransfer(
        currentRadius: Double,
        targetRadius: Double,
        primary: CelestialBody,
        targetName: String
    ): TransferPlan {
        val r1 = currentRadius.coerceAtLeast(primary.radius + 10_000.0)
        val r2 = targetRadius.coerceAtLeast(primary.radius + 20_000.0)
        val mu = primary.mu

        // Standard Hohmann Transfer semi-major axis
        val aTransfer = (r1 + r2) / 2.0

        // Departure burn: Delta-V1
        val v1 = sqrt(mu / r1)
        val vTransfer1 = sqrt(mu * (2.0 / r1 - 1.0 / aTransfer))
        val dv1 = abs(vTransfer1 - v1)

        // Arrival insertion burn: Delta-V2
        val v2 = sqrt(mu / r2)
        val vTransfer2 = sqrt(mu * (2.0 / r2 - 1.0 / aTransfer))
        val dv2 = abs(v2 - vTransfer2)

        val tTransfer = Math.PI * sqrt((aTransfer * aTransfer * aTransfer) / mu)
        val targetAngularSpeed = sqrt(mu / (r2 * r2 * r2))
        val phaseAngleRad = Math.PI - targetAngularSpeed * tTransfer
        val phaseAngleDeg = (Math.toDegrees(phaseAngleRad) % 360.0 + 360.0) % 360.0

        return TransferPlan(
            targetName = targetName,
            departureDeltaV = dv1,
            arrivalDeltaV = dv2,
            transferTimeSeconds = tTransfer,
            phaseAngleDeg = phaseAngleDeg
        )
    }

    fun planHohmannTransfer(fromBody: CelestialBody, toBody: CelestialBody): TransferPlan {
        val parent = fromBody.parentBody ?: SolarSystem.STAR_HELIOS
        val r1 = if (fromBody.orbitRadius > 0.0) fromBody.orbitRadius else (fromBody.radius * 2.0)
        val r2 = if (toBody.orbitRadius > 0.0) toBody.orbitRadius else (toBody.radius * 2.0)
        return planHohmannTransfer(r1, r2, parent, toBody.name)
    }

    /**
     * Computes closest approach to a target celestial body along predicted trajectory.
     */
    fun calculateClosestApproach(
        shipPos: Vector3D,
        shipVel: Vector3D,
        target: CelestialBody,
        primary: CelestialBody,
        lookaheadSeconds: Double = 6000.0,
        samples: Int = 40
    ): InterceptInfo {
        var minDistance = Double.MAX_VALUE
        var minTime = 0.0
        val dt = lookaheadSeconds / samples
        var simPos = shipPos
        var simVel = shipVel

        for (i in 0 until samples) {
            val t = i * dt
            val targetPos = target.currentPosition(t)
            val dist = simPos.distanceTo(targetPos)
            if (dist < minDistance) {
                minDistance = dist
                minTime = t
            }

            // Simple Keplerian step
            val rVec = primary.position - simPos
            val rSq = rVec.lengthSquared().coerceAtLeast(1e3)
            val grav = (rVec / sqrt(rSq)) * (primary.mu / rSq)
            simVel = simVel + grav * dt
            simPos = simPos + simVel * dt
        }

        val relSpeed = (shipVel - target.velocity).length()
        val isEncounter = minDistance < target.sphereOfInfluenceRadius

        return InterceptInfo(
            closestDistance = minDistance,
            relativeSpeed = relSpeed,
            timeToClosestApproach = minTime,
            isEncounter = isEncounter
        )
    }

    /**
     * Generates a sample series of 3D points representing the current orbital trajectory.
     */
    fun sampleTrajectory(
        posRel: Vector3D,
        velRel: Vector3D,
        primary: CelestialBody,
        numPoints: Int = 72
    ): List<Vector3D> {
        val r = posRel.length()
        val mu = primary.mu
        val h = posRel.cross(velRel)
        val hMag = h.length()
        if (hMag < 1e-3) return emptyList()

        val vCrossH = velRel.cross(h)
        val eVec = (vCrossH / mu) - (posRel / r)
        val e = eVec.length()
        val energy = (velRel.lengthSquared() / 2.0) - (mu / r)
        val a = if (abs(energy) > 1e-7) -mu / (2.0 * energy) else return emptyList()

        // Plane coordinate system
        val pUnit = if (e > 1e-5) eVec.normalized() else posRel.normalized()
        val wUnit = h.normalized()
        val qUnit = wUnit.cross(pUnit)

        val points = mutableListOf<Vector3D>()
        val maxAngle = if (e >= 1.0) {
            // Hyperbolic asymptote limit
            (acos(-1.0 / e) * 0.9).coerceAtMost(Math.PI * 0.85)
        } else {
            2.0 * Math.PI
        }

        val step = maxAngle / numPoints
        val startNu = if (e >= 1.0) -maxAngle else 0.0
        val endNu = if (e >= 1.0) maxAngle else 2.0 * Math.PI

        var nu = startNu
        while (nu <= endNu) {
            val denom = 1.0 + e * cos(nu)
            if (denom > 1e-4) {
                val radius = if (e < 1.0) {
                    a * (1.0 - e * e) / denom
                } else {
                    (hMag * hMag / mu) / denom
                }

                if (radius > 0 && radius < primary.radius * 20.0) {
                    val px = radius * (cos(nu) * pUnit.x + sin(nu) * qUnit.x)
                    val py = radius * (cos(nu) * pUnit.y + sin(nu) * qUnit.y)
                    val pz = radius * (cos(nu) * pUnit.z + sin(nu) * qUnit.z)
                    points.add(Vector3D(px, py, pz))
                }
            }
            nu += step
        }
        return points
    }

    /**
     * Generates points along a full circular/elliptical body orbit ring around its parent.
     */
    fun sampleBodyOrbitRing(parentPos: Vector3D, orbitRadius: Double, numPoints: Int = 64): List<Vector3D> {
        val points = mutableListOf<Vector3D>()
        val step = 2.0 * Math.PI / numPoints
        for (i in 0 until numPoints) {
            val theta = i * step
            val x = parentPos.x + orbitRadius * cos(theta)
            val z = parentPos.z + orbitRadius * sin(theta)
            points.add(Vector3D(x, parentPos.y, z))
        }
        return points
    }

    fun sampleBodyOrbitRing(body: CelestialBody, numPoints: Int = 64): List<Vector3D> {
        val parent = body.parentBody ?: return emptyList()
        return sampleBodyOrbitRing(parent.position, body.orbitRadius, numPoints)
    }
}
