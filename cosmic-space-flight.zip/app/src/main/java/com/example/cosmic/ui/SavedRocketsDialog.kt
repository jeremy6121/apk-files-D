package com.example.cosmic.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.cosmic.model.RocketDesign
import com.example.cosmic.model.StockRockets

@Composable
fun SavedRocketsDialog(
    viewModel: GameViewModel,
    onDismiss: () -> Unit
) {
    val savedRockets by viewModel.savedRocketsList.collectAsStateWithLifecycle()
    var selectedTab by remember { mutableStateOf(0) }

    val stockPresets = remember {
        listOf(
            StockRockets.createCosmos1(),
            StockRockets.createLunarExplorer(),
            StockRockets.createTitanHeavy()
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("Rocket Hangar Catalog", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("Select a spacecraft to load into the builder", fontSize = 12.sp, color = Color(0xFF94A3B8))
            }
        },
        text = {
            Column(modifier = Modifier.heightIn(max = 420.dp)) {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.Transparent,
                    contentColor = Color(0xFF38BDF8)
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Stock Presets (${stockPresets.size})", fontSize = 12.sp) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Custom Saved (${savedRockets.size})", fontSize = 12.sp) }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (selectedTab == 0) {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(stockPresets) { rocket ->
                            RocketCatalogItem(
                                name = rocket.name,
                                mass = rocket.totalMass(),
                                stages = rocket.getStagesCount(),
                                deltaV = rocket.totalEstimatedDeltaV(),
                                isCustom = false,
                                onLoad = {
                                    viewModel.loadDesign(rocket)
                                    onDismiss()
                                }
                            )
                        }
                    }
                } else {
                    if (savedRockets.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No custom rockets saved yet.\nBuild a rocket and tap Save!", color = Color(0xFF64748B), fontSize = 13.sp)
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(savedRockets) { name ->
                                val loaded = viewModel.saveSystem.loadRocket(name)
                                if (loaded != null) {
                                    RocketCatalogItem(
                                        name = loaded.name,
                                        mass = loaded.totalMass(),
                                        stages = loaded.getStagesCount(),
                                        deltaV = loaded.totalEstimatedDeltaV(),
                                        isCustom = true,
                                        onLoad = {
                                            viewModel.loadDesign(loaded)
                                            onDismiss()
                                        },
                                        onDelete = {
                                            viewModel.deleteSavedRocket(name)
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = Color(0xFF94A3B8))
            }
        },
        containerColor = Color(0xFF1E293B)
    )
}

@Composable
fun RocketCatalogItem(
    name: String,
    mass: Double,
    stages: Int,
    deltaV: Double,
    isCustom: Boolean,
    onLoad: () -> Unit,
    onDelete: (() -> Unit)? = null
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                Text(
                    text = "${(mass / 1000.0).format(1)} tons • $stages stages • ${deltaV.toInt()} m/s Δv",
                    fontSize = 11.sp,
                    color = Color(0xFF94A3B8)
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = onLoad,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.RocketLaunch, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Load", fontSize = 11.sp)
                }

                if (isCustom && onDelete != null) {
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF4444), modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}
