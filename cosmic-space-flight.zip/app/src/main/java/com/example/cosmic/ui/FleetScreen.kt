package com.example.cosmic.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.cosmic.model.OrbitingVessel
import com.example.cosmic.model.VesselType
import com.example.cosmic.physics.SolarSystem

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FleetScreen(
    viewModel: GameViewModel,
    onBack: () -> Unit
) {
    val vessels = viewModel.fleetManager.vessels
    val credits by viewModel.credits.collectAsState()
    var selectedFilter by remember { mutableStateOf<VesselType?>(null) }
    var selectedVessel by remember { mutableStateOf<OrbitingVessel?>(null) }

    val filteredList = if (selectedFilter == null) {
        vessels
    } else {
        vessels.filter { it.vesselType == selectedFilter }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "ORBITAL FLEET & SPACE STATIONS",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color.White
                        )
                        Text(
                            text = "${vessels.size} Active Celestial Crafts Across System",
                            fontSize = 12.sp,
                            color = Color(0xFF00E676)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("fleet_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    Surface(
                        color = Color(0xFF263238),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.padding(end = 16.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.MonetizationOn,
                                contentDescription = "Credits",
                                tint = Color(0xFFFFD700),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "$credits C",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 14.sp
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF10141C)
                )
            )
        },
        containerColor = Color(0xFF0C0E14)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Filter Pills
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedFilter == null,
                    onClick = {
                        viewModel.playClickSound()
                        selectedFilter = null
                    },
                    label = { Text("All (${vessels.size})") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFF0288D1),
                        selectedLabelColor = Color.White
                    )
                )
                FilterChip(
                    selected = selectedFilter == VesselType.SPACE_STATION,
                    onClick = {
                        viewModel.playClickSound()
                        selectedFilter = VesselType.SPACE_STATION
                    },
                    label = { Text("Stations") },
                    leadingIcon = { Icon(Icons.Default.Apartment, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFF00C853),
                        selectedLabelColor = Color.White
                    )
                )
                FilterChip(
                    selected = selectedFilter == VesselType.SATELLITE,
                    onClick = {
                        viewModel.playClickSound()
                        selectedFilter = VesselType.SATELLITE
                    },
                    label = { Text("Satellites") },
                    leadingIcon = { Icon(Icons.Default.Sensors, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFF0091EA),
                        selectedLabelColor = Color.White
                    )
                )
                FilterChip(
                    selected = selectedFilter == VesselType.INTERPLANETARY_CRUISER,
                    onClick = {
                        viewModel.playClickSound()
                        selectedFilter = VesselType.INTERPLANETARY_CRUISER
                    },
                    label = { Text("Cruisers") },
                    leadingIcon = { Icon(Icons.Default.RocketLaunch, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFFFF6D00),
                        selectedLabelColor = Color.White
                    )
                )
            }

            if (filteredList.isEmpty()) {
                // Empty state
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF161B26)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth(0.8f)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.SatelliteAlt,
                                contentDescription = null,
                                tint = Color(0xFF00E676),
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "No Active Vessels in this Category",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "To deploy a Space Station or Satellite into the fleet: Build a spacecraft with Habitat/Solar modules, launch into orbit, and click 'ESTABLISH STATION' in the flight HUD.",
                                fontSize = 13.sp,
                                color = Color.LightGray,
                                lineHeight = 18.sp
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { viewModel.navigateTo(AppScreen.BUILDER) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0288D1))
                            ) {
                                Text("Go to Rocket Builder")
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredList) { vessel ->
                        VesselCard(
                            vessel = vessel,
                            onSelect = { selectedVessel = vessel },
                            onTarget = {
                                viewModel.selectTargetBody(SolarSystem.allBodies.find { it.name == vessel.primaryBodyName })
                                viewModel.navigateTo(AppScreen.FLIGHT)
                            },
                            onRetire = {
                                viewModel.fleetManager.removeVessel(vessel.id)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun VesselCard(
    vessel: OrbitingVessel,
    onSelect: () -> Unit,
    onTarget: () -> Unit,
    onRetire: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF141924)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF263238), RoundedCornerShape(16.dp))
            .clickable { onSelect() }
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(
                                when (vessel.vesselType) {
                                    VesselType.SPACE_STATION -> Color(0xFF00C853).copy(alpha = 0.2f)
                                    VesselType.SATELLITE -> Color(0xFF0091EA).copy(alpha = 0.2f)
                                    VesselType.INTERPLANETARY_CRUISER -> Color(0xFFFF6D00).copy(alpha = 0.2f)
                                    else -> Color(0xFF607D8B).copy(alpha = 0.2f)
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (vessel.vesselType) {
                                VesselType.SPACE_STATION -> Icons.Default.Apartment
                                VesselType.SATELLITE -> Icons.Default.Sensors
                                VesselType.INTERPLANETARY_CRUISER -> Icons.Default.RocketLaunch
                                else -> Icons.Default.Rocket
                            },
                            contentDescription = null,
                            tint = when (vessel.vesselType) {
                                VesselType.SPACE_STATION -> Color(0xFF00E676)
                                VesselType.SATELLITE -> Color(0xFF29B6F6)
                                VesselType.INTERPLANETARY_CRUISER -> Color(0xFFFF9100)
                                else -> Color.LightGray
                            },
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = vessel.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = Color.White
                        )
                        Text(
                            text = "${vessel.vesselType.label} • Orbiting ${vessel.primaryBodyName}",
                            fontSize = 12.sp,
                            color = Color.LightGray
                        )
                    }
                }

                Surface(
                    color = Color(0xFF1E2638),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "ACTIVE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF00E676),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Metrics Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MetricPill(
                    label = "Apoapsis",
                    value = "${(vessel.orbit.apoapsisAltitude / 1000.0).toInt()} km"
                )
                MetricPill(
                    label = "Periapsis",
                    value = "${(vessel.orbit.periapsisAltitude / 1000.0).toInt()} km"
                )
                MetricPill(
                    label = "Period",
                    value = "${(vessel.orbit.orbitalPeriodSeconds / 60.0).toInt()} min"
                )
                MetricPill(
                    label = "Modules",
                    value = "${vessel.dockedModuleCount}"
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Station Specs
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = Color(0xFFFFD700),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${vessel.solarPowerKw.toInt()} kW Solar",
                            fontSize = 12.sp,
                            color = Color.LightGray
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.People,
                            contentDescription = null,
                            tint = Color(0xFF29B6F6),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${vessel.assignedCrew.size} Crew",
                            fontSize = 12.sp,
                            color = Color.LightGray
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onRetire,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF5252)),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text("Deorbit", fontSize = 11.sp)
                    }
                    Button(
                        onClick = onTarget,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0288D1)),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text("Target in Flight", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun MetricPill(label: String, value: String) {
    Surface(
        color = Color(0xFF10141C),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = label, fontSize = 10.sp, color = Color.Gray)
            Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}
