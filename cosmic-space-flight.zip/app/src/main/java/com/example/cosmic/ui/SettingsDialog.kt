package com.example.cosmic.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.cosmic.model.GraphicsQuality

@Composable
fun SettingsDialog(
    viewModel: GameViewModel,
    onDismiss: () -> Unit
) {
    var soundEnabled by remember { mutableStateOf(viewModel.saveSystem.soundEnabled) }
    var particleEffects by remember { mutableStateOf(viewModel.saveSystem.particlesEnabled) }
    var graphicsQuality by remember { mutableStateOf(viewModel.saveSystem.graphicsQuality) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Simulator Settings", color = Color.White, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier.padding(top = 8.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Graphics Quality Selector
                Column {
                    Text("Graphics Quality Preset", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text("Controls particle counts and mesh subdivisions", color = Color(0xFF94A3B8), fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        GraphicsQuality.entries.forEach { quality ->
                            FilterChip(
                                selected = graphicsQuality == quality,
                                onClick = {
                                    graphicsQuality = quality
                                    viewModel.saveSystem.graphicsQuality = quality
                                },
                                label = { Text(quality.name, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFF00E5FF),
                                    selectedLabelColor = Color(0xFF070B14),
                                    containerColor = Color(0xFF0F172A),
                                    labelColor = Color(0xFF94A3B8)
                                )
                            )
                        }
                    }
                }

                HorizontalDivider(color = Color(0xFF334155))

                // Sound toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Audio & Rocket SFX", color = Color.White, fontSize = 14.sp)
                        Text("Atmospheric rumble & staging sound effects", color = Color(0xFF94A3B8), fontSize = 11.sp)
                    }
                    Switch(
                        checked = soundEnabled,
                        onCheckedChange = {
                            soundEnabled = it
                            viewModel.saveSystem.soundEnabled = it
                        }
                    )
                }

                // Particles toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Exhaust & Plasma Particles", color = Color.White, fontSize = 14.sp)
                        Text("Engine fire plumes, smoke trail, and re-entry sheath", color = Color(0xFF94A3B8), fontSize = 11.sp)
                    }
                    Switch(
                        checked = particleEffects,
                        onCheckedChange = {
                            particleEffects = it
                            viewModel.saveSystem.particlesEnabled = it
                        }
                    )
                }

                Text(
                    text = "Cosmic Space Flight v2.0 • Android Tablet Edition",
                    fontSize = 11.sp,
                    color = Color(0xFF64748B)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
            ) {
                Text("Done")
            }
        },
        containerColor = Color(0xFF1E293B)
    )
}
