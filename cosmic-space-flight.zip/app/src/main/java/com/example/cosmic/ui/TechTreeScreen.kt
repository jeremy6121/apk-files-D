package com.example.cosmic.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Upgrade
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.cosmic.model.PartType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TechTreeScreen(
    viewModel: GameViewModel,
    onBack: () -> Unit
) {
    val credits by viewModel.credits.collectAsState()
    var selectedTier by remember { mutableStateOf(1) }

    val partsForTier = remember(selectedTier) {
        PartType.entries.filter { it.techTier == selectedTier }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Research & Technology Tree", fontWeight = FontWeight.Bold, color = Color.White)
                        Text(
                            "Available Funds: ₵$credits",
                            fontSize = 13.sp,
                            color = Color(0xFFFFD54F),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("tech_back_button")) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0F172A)
                )
            )
        },
        containerColor = Color(0xFF070B14)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            // Tier Selector Tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF1E293B))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TierTabButton(
                    title = "Tier 1: Starter",
                    isSelected = selectedTier == 1,
                    modifier = Modifier.weight(1f)
                ) { selectedTier = 1 }

                TierTabButton(
                    title = "Tier 2: Advanced",
                    isSelected = selectedTier == 2,
                    modifier = Modifier.weight(1f)
                ) { selectedTier = 2 }

                TierTabButton(
                    title = "Tier 3: Deep Space",
                    isSelected = selectedTier == 3,
                    modifier = Modifier.weight(1f)
                ) { selectedTier = 3 }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Parts List
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(partsForTier) { part ->
                    val isUnlocked = viewModel.progressionSystem.isPartUnlocked(part)
                    val upgradeLvl = viewModel.progressionSystem.getPartUpgradeLevel(part.name)

                    TechPartCard(
                        part = part,
                        isUnlocked = isUnlocked,
                        upgradeLevel = upgradeLvl,
                        playerCredits = credits,
                        onUnlock = {
                            viewModel.unlockPart(part)
                        },
                        onUpgrade = {
                            viewModel.upgradePart(part)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun TierTabButton(
    title: String,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = modifier.height(44.dp),
        shape = RoundedCornerShape(8.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) Color(0xFF00E5FF) else Color.Transparent,
            contentColor = if (isSelected) Color(0xFF070B14) else Color(0xFF94A3B8)
        )
    ) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
private fun TechPartCard(
    part: PartType,
    isUnlocked: Boolean,
    upgradeLevel: Int,
    playerCredits: Int,
    onUnlock: () -> Unit,
    onUpgrade: () -> Unit
) {
    val canAffordUnlock = playerCredits >= part.cost
    val upgradeCost = (part.cost * 0.75 * upgradeLevel).toInt()
    val canAffordUpgrade = playerCredits >= upgradeCost && upgradeLevel < 3

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (isUnlocked) Color(0xFF1E3A8A) else Color(0xFF334155),
                RoundedCornerShape(12.dp)
            ),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isUnlocked) Color(0xFF0F172A) else Color(0xFF0B101D)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        part.displayName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    if (isUnlocked) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Color(0xFF00E676).copy(alpha = 0.2f)
                        ) {
                            Text(
                                "UNLOCKED",
                                color = Color(0xFF00E676),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    } else {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Color(0xFFFF5252).copy(alpha = 0.2f)
                        ) {
                            Text(
                                "LOCKED",
                                color = Color(0xFFFF5252),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    part.description,
                    fontSize = 12.sp,
                    color = Color(0xFF94A3B8),
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("Mass: ${part.dryMass.toInt()} kg", fontSize = 11.sp, color = Color(0xFFCBD5E1))
                    if (part.thrust > 0) {
                        Text("Thrust: ${(part.thrust / 1000).toInt()} kN", fontSize = 11.sp, color = Color(0xFFFFB74D))
                        Text("Isp: ${part.isp.toInt()} s", fontSize = 11.sp, color = Color(0xFF64B5F6))
                    }
                    if (part.fuelCapacity > 0) {
                        Text("Fuel: ${part.fuelCapacity.toInt()} kg", fontSize = 11.sp, color = Color(0xFF81C784))
                    }
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Action Button
            if (!isUnlocked) {
                Button(
                    onClick = onUnlock,
                    enabled = canAffordUnlock,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF00E5FF),
                        contentColor = Color(0xFF070B14),
                        disabledContainerColor = Color(0xFF334155),
                        disabledContentColor = Color(0xFF64748B)
                    ),
                    modifier = Modifier.testTag("unlock_part_${part.name}")
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("₵${part.cost}", fontWeight = FontWeight.Bold)
                }
            } else {
                Button(
                    onClick = onUpgrade,
                    enabled = canAffordUpgrade,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF3B82F6),
                        contentColor = Color.White,
                        disabledContainerColor = Color(0xFF1E293B),
                        disabledContentColor = Color(0xFF64748B)
                    ),
                    modifier = Modifier.testTag("upgrade_part_${part.name}")
                ) {
                    Icon(Icons.Default.Upgrade, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        if (upgradeLevel >= 3) "MAX LVL" else "Lvl $upgradeLevel (₵$upgradeCost)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}
