package com.example.cosmic.renderer

import android.opengl.GLES20
import com.example.cosmic.math.Vector3D
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.Random
import kotlin.math.cos
import kotlin.math.sin

class ParticleSystem(val maxParticles: Int = 400) {

    class Particle {
        var x = 0f
        var y = 0f
        var z = 0f
        var vx = 0f
        var vy = 0f
        var vz = 0f
        var r = 1f
        var g = 0.5f
        var b = 0.1f
        var a = 1f
        var size = 10f
        var life = 0f
        var maxLife = 1f
        var isActive = false
    }

    private val pool = Array(maxParticles) { Particle() }
    private val random = Random()

    private val posBuffer: FloatBuffer = ByteBuffer.allocateDirect(maxParticles * 3 * 4)
        .order(ByteOrder.nativeOrder()).asFloatBuffer()
    private val colorBuffer: FloatBuffer = ByteBuffer.allocateDirect(maxParticles * 4 * 4)
        .order(ByteOrder.nativeOrder()).asFloatBuffer()
    private val sizeBuffer: FloatBuffer = ByteBuffer.allocateDirect(maxParticles * 4)
        .order(ByteOrder.nativeOrder()).asFloatBuffer()

    fun emitEngineExhaust(
        nozzlePos: Vector3D,
        exhaustDir: Vector3D,
        throttle: Float,
        count: Int = 4
    ) {
        if (throttle <= 0.01f) return
        val effectiveCount = (count * throttle).toInt().coerceAtLeast(1)

        for (i in 0 until effectiveCount) {
            val p = findAvailableParticle() ?: break
            p.isActive = true
            p.life = 0f
            p.maxLife = 0.35f + random.nextFloat() * 0.3f

            // Origin with slight nozzle jitter
            val spread = 0.15f
            p.x = (nozzlePos.x + (random.nextFloat() - 0.5f) * spread).toFloat()
            p.y = (nozzlePos.y + (random.nextFloat() - 0.5f) * spread).toFloat()
            p.z = (nozzlePos.z + (random.nextFloat() - 0.5f) * spread).toFloat()

            // Exhaust velocity
            val speed = 35f + random.nextFloat() * 25f
            val spreadVel = 4f
            p.vx = (exhaustDir.x * speed + (random.nextFloat() - 0.5f) * spreadVel).toFloat()
            p.vy = (exhaustDir.y * speed + (random.nextFloat() - 0.5f) * spreadVel).toFloat()
            p.vz = (exhaustDir.z * speed + (random.nextFloat() - 0.5f) * spreadVel).toFloat()

            // Intense orange/yellow/white fire
            p.r = 1.0f
            p.g = 0.6f + random.nextFloat() * 0.4f
            p.b = 0.15f + random.nextFloat() * 0.3f
            p.a = 0.9f
            p.size = 28f + random.nextFloat() * 18f
        }
    }

    fun emitReentryPlasma(rocketPos: Vector3D, velDir: Vector3D, intensity: Float) {
        if (intensity <= 0.05f) return
        val count = (intensity * 6).toInt().coerceAtLeast(1)

        for (i in 0 until count) {
            val p = findAvailableParticle() ?: break
            p.isActive = true
            p.life = 0f
            p.maxLife = 0.25f + random.nextFloat() * 0.2f

            // Plasma wraps along shock front
            val offset = 1.2f
            p.x = (rocketPos.x + (random.nextFloat() - 0.5f) * offset).toFloat()
            p.y = (rocketPos.y + (random.nextFloat() - 0.5f) * offset).toFloat()
            p.z = (rocketPos.z + (random.nextFloat() - 0.5f) * offset).toFloat()

            val trailSpeed = -15f
            p.vx = (velDir.x * trailSpeed + (random.nextFloat() - 0.5f) * 5f).toFloat()
            p.vy = (velDir.y * trailSpeed + (random.nextFloat() - 0.5f) * 5f).toFloat()
            p.vz = (velDir.z * trailSpeed + (random.nextFloat() - 0.5f) * 5f).toFloat()

            // Fiery crimson/orange/yellow plasma glow
            p.r = 1.0f
            p.g = 0.3f + random.nextFloat() * 0.5f
            p.b = 0.1f
            p.a = intensity.coerceIn(0.2f, 0.95f)
            p.size = 32f + random.nextFloat() * 20f
        }
    }

    fun emitStagingBurst(pos: Vector3D) {
        for (i in 0 until 18) {
            val p = findAvailableParticle() ?: break
            p.isActive = true
            p.life = 0f
            p.maxLife = 0.4f + random.nextFloat() * 0.3f

            p.x = pos.x.toFloat()
            p.y = pos.y.toFloat()
            p.z = pos.z.toFloat()

            val angle = random.nextFloat() * Math.PI.toFloat() * 2f
            val speed = 8f + random.nextFloat() * 12f
            p.vx = cos(angle) * speed
            p.vy = (random.nextFloat() - 0.5f) * 6f
            p.vz = sin(angle) * speed

            // White cold-gas separation cloud
            p.r = 0.95f
            p.g = 0.95f
            p.b = 1.0f
            p.a = 0.8f
            p.size = 22f + random.nextFloat() * 15f
        }
    }

    fun emitExplosion(pos: Vector3D) {
        for (i in 0 until 60) {
            val p = findAvailableParticle() ?: break
            p.isActive = true
            p.life = 0f
            p.maxLife = 0.8f + random.nextFloat() * 0.6f

            p.x = pos.x.toFloat()
            p.y = pos.y.toFloat()
            p.z = pos.z.toFloat()

            val speed = 15f + random.nextFloat() * 35f
            p.vx = (random.nextFloat() - 0.5f) * speed
            p.vy = (random.nextFloat() - 0.2f) * speed
            p.vz = (random.nextFloat() - 0.5f) * speed

            p.r = 1.0f
            p.g = 0.4f + random.nextFloat() * 0.5f
            p.b = 0.05f
            p.a = 1.0f
            p.size = 35f + random.nextFloat() * 25f
        }
    }

    fun update(dt: Float) {
        for (p in pool) {
            if (!p.isActive) continue
            p.life += dt
            if (p.life >= p.maxLife) {
                p.isActive = false
                continue
            }

            p.x += p.vx * dt
            p.y += p.vy * dt
            p.z += p.vz * dt

            // Alpha fade over lifetime
            val progress = p.life / p.maxLife
            p.a = (1f - progress) * 0.85f
            p.size *= (1f + dt * 0.5f) // Slightly expand
        }
    }

    fun render(posHandle: Int, colorHandle: Int, sizeHandle: Int): Int {
        posBuffer.position(0)
        colorBuffer.position(0)
        sizeBuffer.position(0)

        var activeCount = 0
        for (p in pool) {
            if (!p.isActive) continue
            posBuffer.put(p.x); posBuffer.put(p.y); posBuffer.put(p.z)
            colorBuffer.put(p.r); colorBuffer.put(p.g); colorBuffer.put(p.b); colorBuffer.put(p.a)
            sizeBuffer.put(p.size)
            activeCount++
        }

        if (activeCount == 0) return 0

        posBuffer.position(0)
        colorBuffer.position(0)
        sizeBuffer.position(0)

        GLES20.glVertexAttribPointer(posHandle, 3, GLES20.GL_FLOAT, false, 0, posBuffer)
        GLES20.glEnableVertexAttribArray(posHandle)

        GLES20.glVertexAttribPointer(colorHandle, 4, GLES20.GL_FLOAT, false, 0, colorBuffer)
        GLES20.glEnableVertexAttribArray(colorHandle)

        GLES20.glVertexAttribPointer(sizeHandle, 1, GLES20.GL_FLOAT, false, 0, sizeBuffer)
        GLES20.glEnableVertexAttribArray(sizeHandle)

        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE) // Additive glow
        GLES20.glDepthMask(false)

        GLES20.glDrawArrays(GLES20.GL_POINTS, 0, activeCount)

        GLES20.glDepthMask(true)
        GLES20.glDisable(GLES20.GL_BLEND)

        GLES20.glDisableVertexAttribArray(posHandle)
        GLES20.glDisableVertexAttribArray(colorHandle)
        GLES20.glDisableVertexAttribArray(sizeHandle)

        return activeCount
    }

    private fun findAvailableParticle(): Particle? {
        for (p in pool) {
            if (!p.isActive) return p
        }
        return null
    }
}
