package com.example.cosmic.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.Random
import java.util.concurrent.Executors
import kotlin.math.sin

/**
 * Procedural Real-Time Audio Synthesizer for Cosmic Space Flight.
 * Generates rocket engine roar, staging bangs, docking chimes, countdown beeps,
 * and mission complete fanfares directly via Android AudioTrack.
 */
class CosmicAudioEngine {

    var isSoundEnabled: Boolean = true
    var masterVolume: Float = 0.8f // 0.0 to 1.0

    private val executor = Executors.newSingleThreadExecutor()
    private val random = Random()

    private var engineTrack: AudioTrack? = null
    private var isEnginePlaying = false
    private var currentThrottle = 0f

    init {
        initEngineAudioLoop()
    }

    private fun initEngineAudioLoop() {
        val sampleRate = 22050
        val bufferSize = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ) * 2

        try {
            engineTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            engineTrack?.play()
            isEnginePlaying = true

            // Background synthesis thread for engine sound
            executor.execute {
                val samples = ShortArray(1024)
                var phase1 = 0.0
                var phase2 = 0.0
                var brownNoise = 0.0

                while (isEnginePlaying) {
                    val throttle = currentThrottle
                    val vol = masterVolume
                    val shouldPlay = isSoundEnabled && throttle > 0.02f && vol > 0.01f

                    if (!shouldPlay) {
                        samples.fill(0)
                    } else {
                        val rumbleFreq = 45.0 + throttle * 55.0 // 45 Hz to 100 Hz
                        val roarFreq = 110.0 + throttle * 130.0

                        for (i in samples.indices) {
                            // Synthesize engine roar: filtered pink/brown noise + sub-bass rumble
                            val white = (random.nextDouble() * 2.0 - 1.0)
                            brownNoise = (brownNoise + (0.05 * white)) / 1.05

                            val sub1 = sin(phase1)
                            val sub2 = sin(phase2)

                            phase1 += 2.0 * Math.PI * rumbleFreq / sampleRate
                            phase2 += 2.0 * Math.PI * roarFreq / sampleRate
                            if (phase1 > 2.0 * Math.PI) phase1 -= 2.0 * Math.PI
                            if (phase2 > 2.0 * Math.PI) phase2 -= 2.0 * Math.PI

                            val mixed = (brownNoise * 0.65 + sub1 * 0.25 + sub2 * 0.15) * throttle * vol
                            val clamped = mixed.coerceIn(-0.95, 0.95)
                            samples[i] = (clamped * 32767.0).toInt().toShort()
                        }
                    }

                    engineTrack?.write(samples, 0, samples.size)
                }
            }
        } catch (e: Exception) {
            // AudioTrack might fail in test or restricted environments
            engineTrack = null
        }
    }

    fun updateEngineThrottle(throttle: Float) {
        currentThrottle = throttle.coerceIn(0f, 1f)
    }

    fun playStagingSound() {
        if (!isSoundEnabled || masterVolume <= 0.01f) return
        executor.execute {
            playToneBurst(durationMs = 280, startFreq = 180.0, endFreq = 40.0, volume = masterVolume * 0.9f)
        }
    }

    fun playCountdownBeep(isIgnition: Boolean) {
        if (!isSoundEnabled || masterVolume <= 0.01f) return
        executor.execute {
            val freq = if (isIgnition) 1400.0 else 880.0
            val duration = if (isIgnition) 350 else 140
            playToneBurst(durationMs = duration, startFreq = freq, endFreq = freq, volume = masterVolume * 0.7f)
        }
    }

    fun playDockingChime() {
        if (!isSoundEnabled || masterVolume <= 0.01f) return
        executor.execute {
            // High pleasing chime
            playToneBurst(durationMs = 200, startFreq = 523.25, endFreq = 659.25, volume = masterVolume * 0.8f)
            Thread.sleep(150)
            playToneBurst(durationMs = 300, startFreq = 783.99, endFreq = 1046.50, volume = masterVolume * 0.85f)
        }
    }

    fun playTouchdownSound() {
        if (!isSoundEnabled || masterVolume <= 0.01f) return
        executor.execute {
            playToneBurst(durationMs = 320, startFreq = 120.0, endFreq = 35.0, volume = masterVolume * 0.9f)
        }
    }

    fun playMissionCompleteFanfare() {
        if (!isSoundEnabled || masterVolume <= 0.01f) return
        executor.execute {
            val notes = listOf(523.25, 659.25, 783.99, 1046.50) // C - E - G - High C
            for (note in notes) {
                playToneBurst(durationMs = 120, startFreq = note, endFreq = note, volume = masterVolume * 0.75f)
                Thread.sleep(80)
            }
        }
    }

    fun playUiClick() {
        if (!isSoundEnabled || masterVolume <= 0.01f) return
        executor.execute {
            playToneBurst(durationMs = 40, startFreq = 1200.0, endFreq = 600.0, volume = masterVolume * 0.4f)
        }
    }

    private fun playToneBurst(durationMs: Int, startFreq: Double, endFreq: Double, volume: Float) {
        val sampleRate = 22050
        val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
        if (numSamples <= 0) return

        val samples = ShortArray(numSamples)
        var phase = 0.0

        for (i in 0 until numSamples) {
            val progress = i.toDouble() / numSamples
            val currentFreq = startFreq + (endFreq - startFreq) * progress
            phase += 2.0 * Math.PI * currentFreq / sampleRate
            if (phase > 2.0 * Math.PI) phase -= 2.0 * Math.PI

            // Envelope: linear attack, decay
            val envelope = (1.0 - progress) * (if (progress < 0.1) progress / 0.1 else 1.0)
            val v = sin(phase) * envelope * volume
            samples[i] = (v.coerceIn(-1.0, 1.0) * 32767.0).toInt().toShort()
        }

        try {
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(samples.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(samples, 0, samples.size)
            track.play()
            Thread.sleep(durationMs.toLong() + 20)
            track.release()
        } catch (e: Exception) {
            // Ignore audio track exception in tests or background
        }
    }

    fun release() {
        isEnginePlaying = false
        try {
            engineTrack?.stop()
            engineTrack?.release()
            engineTrack = null
        } catch (e: Exception) {
            // ignore
        }
        executor.shutdown()
    }
}
