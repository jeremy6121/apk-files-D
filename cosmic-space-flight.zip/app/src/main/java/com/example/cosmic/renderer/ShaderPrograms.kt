package com.example.cosmic.renderer

import android.opengl.GLES20
import android.util.Log

object ShaderPrograms {
    private const val TAG = "ShaderPrograms"

    fun loadShader(type: Int, shaderCode: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, shaderCode)
        GLES20.glCompileShader(shader)

        val compileStatus = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compileStatus, 0)
        if (compileStatus[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(shader)
            Log.e(TAG, "Shader compilation error: $log")
            GLES20.glDeleteShader(shader)
            return 0
        }
        return shader
    }

    fun createProgram(vertexSource: String, fragmentSource: String): Int {
        val vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexSource)
        val fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentSource)

        val program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vertexShader)
        GLES20.glAttachShader(program, fragmentShader)
        GLES20.glLinkProgram(program)

        val linkStatus = IntArray(1)
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, linkStatus, 0)
        if (linkStatus[0] == 0) {
            val log = GLES20.glGetProgramInfoLog(program)
            Log.e(TAG, "Program linking error: $log")
            GLES20.glDeleteProgram(program)
            return 0
        }
        return program
    }

    // --- Mesh Shader (Rocket parts, pad, structures) ---
    const val MESH_VERTEX_SHADER = """
        uniform mat4 uMVPMatrix;
        uniform mat4 uModelMatrix;
        uniform vec3 uLightDir;
        
        attribute vec4 aPosition;
        attribute vec3 aNormal;
        
        varying vec3 vNormal;
        varying vec3 vWorldPos;
        varying float vDiffuse;
        
        void main() {
            gl_Position = uMVPMatrix * aPosition;
            vec4 worldPos = uModelMatrix * aPosition;
            vWorldPos = worldPos.xyz;
            
            // Transform normal
            vec3 worldNormal = normalize(mat3(uModelMatrix) * aNormal);
            vNormal = worldNormal;
            
            // Directional sun light diffuse
            float diff = max(dot(worldNormal, normalize(uLightDir)), 0.0);
            vDiffuse = diff;
        }
    """

    const val MESH_FRAGMENT_SHADER = """
        precision mediump float;
        
        uniform vec4 uColor;
        uniform vec3 uAmbientColor;
        uniform vec4 uFogColor;
        uniform float uFogDensity;
        
        varying vec3 vNormal;
        varying vec3 vWorldPos;
        varying float vDiffuse;
        
        void main() {
            vec3 ambient = uAmbientColor;
            vec3 diffuse = vec3(vDiffuse);
            vec3 lighting = ambient + diffuse * 0.75;
            vec3 finalColor = uColor.rgb * lighting;
            
            // Atmospheric distance fog blending
            finalColor = mix(finalColor, uFogColor.rgb, uFogDensity);
            gl_FragColor = vec4(finalColor, uColor.a);
        }
    """

    // --- Planet Shader (Spherical ocean, continents & atmospheric limb glow) ---
    const val PLANET_VERTEX_SHADER = """
        uniform mat4 uMVPMatrix;
        uniform mat4 uModelMatrix;
        uniform vec3 uLightDir;
        uniform vec3 uCameraPos;
        
        attribute vec4 aPosition;
        attribute vec3 aNormal;
        
        varying vec3 vNormal;
        varying vec3 vViewDir;
        varying float vDiffuse;
        varying vec3 vModelPos;
        
        void main() {
            gl_Position = uMVPMatrix * aPosition;
            vec4 worldPos = uModelMatrix * aPosition;
            vModelPos = aPosition.xyz;
            
            vec3 worldNormal = normalize(mat3(uModelMatrix) * aNormal);
            vNormal = worldNormal;
            vViewDir = normalize(uCameraPos - worldPos.xyz);
            
            vDiffuse = max(dot(worldNormal, normalize(uLightDir)), 0.0);
        }
    """

    const val PLANET_FRAGMENT_SHADER = """
        precision mediump float;
        
        uniform vec4 uSurfaceColor;
        uniform vec4 uAtmosphereColor;
        uniform float uHasAtmosphere;
        
        varying vec3 vNormal;
        varying vec3 vViewDir;
        varying float vDiffuse;
        varying vec3 vModelPos;
        
        void main() {
            // Procedural landmass vs ocean modulation
            float lat = abs(vModelPos.y);
            float lon = atan(vModelPos.z, vModelPos.x);
            float noise = sin(lon * 4.0) * cos(vModelPos.y * 3.0) + sin(vModelPos.x * 2.0);
            
            vec3 baseColor = uSurfaceColor.rgb;
            if (uHasAtmosphere > 0.5) {
                // Fictional planet continents vs oceans
                if (noise > 0.2) {
                    // Continental land (greenish brown / savannah)
                    baseColor = mix(vec3(0.22, 0.45, 0.25), vec3(0.55, 0.48, 0.32), lat * 0.8);
                } else {
                    // Deep ocean
                    baseColor = mix(vec3(0.08, 0.22, 0.55), vec3(0.12, 0.38, 0.72), vDiffuse);
                }
                // Polar ice caps
                if (lat > 0.85) {
                    baseColor = vec3(0.92, 0.95, 0.98);
                }
            } else {
                // Lunar cratered surface
                float craterNoise = sin(vModelPos.x * 12.0) * cos(vModelPos.z * 12.0) * 0.15;
                baseColor = vec3(0.68 + craterNoise);
            }
            
            // Day/night lighting
            vec3 ambient = vec3(0.04, 0.05, 0.08);
            vec3 litColor = baseColor * (ambient + vec3(vDiffuse * 0.9));
            
            // Atmospheric rim/limb glow
            if (uHasAtmosphere > 0.5) {
                float rim = 1.0 - max(dot(vViewDir, vNormal), 0.0);
                float rimGlow = pow(rim, 3.5) * 1.4;
                vec3 atmoGlow = uAtmosphereColor.rgb * rimGlow * max(vDiffuse + 0.25, 0.0);
                litColor += atmoGlow;
            }
            
            gl_FragColor = vec4(litColor, 1.0);
        }
    """

    // --- Particle Shader (Fire, Smoke, Sparks, Re-entry sheath) ---
    const val PARTICLE_VERTEX_SHADER = """
        uniform mat4 uMVPMatrix;
        attribute vec4 aPosition;
        attribute vec4 aColor;
        attribute float aSize;
        
        varying vec4 vColor;
        
        void main() {
            gl_Position = uMVPMatrix * aPosition;
            gl_PointSize = aSize;
            vColor = aColor;
        }
    """

    const val PARTICLE_FRAGMENT_SHADER = """
        precision mediump float;
        varying vec4 vColor;
        
        void main() {
            // Soft circular particle shape
            vec2 coord = gl_PointCoord - vec2(0.5);
            float distSq = dot(coord, coord);
            if (distSq > 0.25) {
                discard;
            }
            float alpha = smoothstep(0.25, 0.0, distSq) * vColor.a;
            gl_FragColor = vec4(vColor.rgb, alpha);
        }
    """

    // --- Orbit Trajectory Line Shader ---
    const val LINE_VERTEX_SHADER = """
        uniform mat4 uMVPMatrix;
        attribute vec4 aPosition;
        
        void main() {
            gl_Position = uMVPMatrix * aPosition;
        }
    """

    const val LINE_FRAGMENT_SHADER = """
        precision mediump float;
        uniform vec4 uLineColor;
        
        void main() {
            gl_FragColor = uLineColor;
        }
    """
}
