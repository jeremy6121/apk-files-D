package com.example.cosmic.math

import kotlin.math.*

/**
 * High-performance 3D Vector with double precision for accurate orbital physics,
 * and conversions to single-precision float for OpenGL rendering.
 */
data class Vector3D(
    val x: Double = 0.0,
    val y: Double = 0.0,
    val z: Double = 0.0
) {
    constructor(x: Float, y: Float, z: Float) : this(x.toDouble(), y.toDouble(), z.toDouble())

    operator fun plus(other: Vector3D): Vector3D = Vector3D(x + other.x, y + other.y, z + other.z)
    operator fun minus(other: Vector3D): Vector3D = Vector3D(x - other.x, y - other.y, z - other.z)
    operator fun times(scalar: Double): Vector3D = Vector3D(x * scalar, y * scalar, z * scalar)
    operator fun times(scalar: Float): Vector3D = Vector3D(x * scalar, y * scalar, z * scalar)
    operator fun div(scalar: Double): Vector3D = Vector3D(x / scalar, y / scalar, z / scalar)
    operator fun unaryMinus(): Vector3D = Vector3D(-x, -y, -z)

    fun lengthSquared(): Double = x * x + y * y + z * z
    fun length(): Double = sqrt(lengthSquared())

    fun normalized(): Vector3D {
        val len = length()
        return if (len > 1e-9) this / len else ZERO
    }

    fun dot(other: Vector3D): Double = x * other.x + y * other.y + z * other.z

    fun cross(other: Vector3D): Vector3D = Vector3D(
        y * other.z - z * other.y,
        z * other.x - x * other.z,
        x * other.y - y * other.x
    )

    fun distanceTo(other: Vector3D): Double = (this - other).length()

    fun toFloatArray(): FloatArray = floatArrayOf(x.toFloat(), y.toFloat(), z.toFloat())

    companion object {
        val ZERO = Vector3D(0.0, 0.0, 0.0)
        val UP = Vector3D(0.0, 1.0, 0.0)
        val DOWN = Vector3D(0.0, -1.0, 0.0)
        val FORWARD = Vector3D(0.0, 0.0, 1.0)
        val RIGHT = Vector3D(1.0, 0.0, 0.0)
    }
}
