package com.example.cosmic.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun MainMenuScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val activeRocket by viewModel.activeRocket.collectAsStateWithLifecycle()
    var showSavedDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }

    val bgGradient = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF070B19),
            Color(0xFF0F172A),
            Color(0xFF1E1B4B),
            Color(0xFF0B1020)
        )
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(bgGradient)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header Title
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.RocketLaunch,
                        contentDescription = "Cosmic Rocket Logo",
                        tint = Color(0xFF38BDF8),
                        modifier = Modifier.size(44.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "COSMIC SPACE FLIGHT",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp,
                        color = Color(0xFFF8FAFC)
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "3D Rocket Construction & Orbital Spaceflight Simulator",
                    fontSize = 14.sp,
                    color = Color(0xFF94A3B8),
                    textAlign = TextAlign.Center
                )
            }

            // Center Dashboard Card: Active Rocket Specs
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 680.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(20.dp)),
                colors = CardDefaults.cardColors(containerColor = Color(0x991E293B))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "ACTIVE VEHICLE",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF38BDF8),
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = activeRocket.name,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        AssistChip(
                            onClick = { showSavedDialog = true },
                            label = { Text("Change", color = Color(0xFFE2E8F0)) },
                            leadingIcon = {
                                Icon(
                                    Icons.Default.FolderOpen,
                                    contentDescription = null,
                                    tint = Color(0xFF38BDF8),
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFF334155))
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Vehicle Telemetry specs row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        SpecItem(
                            label = "TOTAL MASS",
                            value = "${(activeRocket.totalMass() / 1000.0).format(1)} t",
                            subValue = "${activeRocket.totalDryMass().toInt()} kg dry"
                        )
                        SpecItem(
                            label = "STAGES",
                            value = "${activeRocket.getStagesCount()} Stg",
                            subValue = "${activeRocket.parts.size} parts"
                        )
                        SpecItem(
                            label = "STAGE 0 TWR",
                            value = activeRocket.twr(0).format(2),
                            subValue = if (activeRocket.twr(0) >= 1.2) "Launch Ready" else "Underpowered",
                            isWarning = activeRocket.twr(0) < 1.0
                        )
                        SpecItem(
                            label = "EST. DELTA-V",
                            value = "${activeRocket.totalEstimatedDeltaV().toInt()} m/s",
                            subValue = "Vac potential"
                        )
                    }
                }
            }

            // Action Buttons Grid (Designed for Tablet touch ergonomics)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 680.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Primary LAUNCH Button
                Button(
                    onClick = { viewModel.navigateTo(AppScreen.FLIGHT) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .testTag("launch_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF0284C7)
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(28.dp),
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "LAUNCH TO LAUNCH PAD",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = Color.White
                    )
                }

                // Secondary Row: Build Rocket & Saved Rockets
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    FilledTonalButton(
                        onClick = { viewModel.navigateTo(AppScreen.BUILDER) },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("builder_button"),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = Color(0xFF334155)
                        ),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Build,
                            contentDescription = null,
                            tint = Color(0xFF38BDF8),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Rocket Builder", fontWeight = FontWeight.SemiBold, color = Color.White)
                    }

                    FilledTonalButton(
                        onClick = { showSavedDialog = true },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("saved_rockets_button"),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = Color(0xFF334155)
                        ),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = null,
                            tint = Color(0xFFFBBF24),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Saved Rockets", fontWeight = FontWeight.SemiBold, color = Color.White)
                    }
                }

                // V3 Full Space Program Row: Fleet/Stations & Astronaut Academy
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    FilledTonalButton(
                        onClick = { viewModel.navigateTo(AppScreen.FLEET) },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("fleet_button"),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = Color(0xFF1E293B)
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E676)),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Apartment,
                            contentDescription = null,
                            tint = Color(0xFF00E676),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Space Stations & Fleet", fontWeight = FontWeight.SemiBold, color = Color.White, fontSize = 13.sp)
                    }

                    FilledTonalButton(
                        onClick = { viewModel.navigateTo(AppScreen.CREW) },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("crew_button"),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = Color(0xFF1E293B)
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF0288D1)),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.People,
                            contentDescription = null,
                            tint = Color(0xFF29B6F6),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Astronaut Academy", fontWeight = FontWeight.SemiBold, color = Color.White, fontSize = 13.sp)
                    }
                }

                // Tertiary Row: Missions, Tech Tree & Settings
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.navigateTo(AppScreen.MISSIONS) },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("missions_button"),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF475569)),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = null,
                            tint = Color(0xFFFBBF24),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Missions", color = Color(0xFFE2E8F0), fontSize = 13.sp)
                    }

                    OutlinedButton(
                        onClick = { viewModel.navigateTo(AppScreen.TECH_TREE) },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("tech_tree_button"),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E5FF)),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Science,
                            contentDescription = null,
                            tint = Color(0xFF00E5FF),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Tech Tree", color = Color(0xFF00E5FF), fontSize = 13.sp)
                    }

                    OutlinedButton(
                        onClick = { showSettingsDialog = true },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("settings_button"),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF475569)),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Settings", color = Color(0xFFE2E8F0), fontSize = 13.sp)
                    }
                }
            }

            // Footer note
            Text(
                text = "Helios Solar System: Novaria, Lunara, Pyros, Aeris & Glacies • V3 Space Program",
                fontSize = 12.sp,
                color = Color(0xFF64748B)
            )
        }
    }

    if (showSavedDialog) {
        SavedRocketsDialog(
            viewModel = viewModel,
            onDismiss = { showSavedDialog = false }
        )
    }

    if (showSettingsDialog) {
        SettingsDialog(
            viewModel = viewModel,
            onDismiss = { showSettingsDialog = false }
        )
    }
}

@Composable
fun SpecItem(
    label: String,
    value: String,
    subValue: String,
    isWarning: Boolean = false
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF94A3B8),
            letterSpacing = 0.5.sp
        )
        Text(
            text = value,
            fontSize = 18.sp,
            fontWeight = FontWeight.ExtraBold,
            color = if (isWarning) Color(0xFFF87171) else Color(0xFFF8FAFC)
        )
        Text(
            text = subValue,
            fontSize = 11.sp,
            color = Color(0xFF64748B)
        )
    }
}

fun Double.format(digits: Int): String = "%.${digits}f".format(this)
