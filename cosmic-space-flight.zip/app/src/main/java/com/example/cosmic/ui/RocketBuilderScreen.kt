package com.example.cosmic.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.cosmic.model.*

@Composable
fun RocketBuilderScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val activeRocket by viewModel.activeRocket.collectAsStateWithLifecycle()
    val selectedPart by viewModel.selectedPart.collectAsStateWithLifecycle()
    val activeCategory by viewModel.activeCategory.collectAsStateWithLifecycle()
    val canUndo by viewModel.canUndo.collectAsStateWithLifecycle()
    val canRedo by viewModel.canRedo.collectAsStateWithLifecycle()
    val credits by viewModel.credits.collectAsStateWithLifecycle()

    var showSaveDialog by remember { mutableStateOf(false) }
    var showSavedListDialog by remember { mutableStateOf(false) }
    var showStagingDrawer by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
    ) {
        // 3D Hangar Viewport
        CosmicGLView(
            renderer = viewModel.glRenderer,
            modifier = Modifier.fillMaxSize()
        )

        // Top Navigation & Actions Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xCC0F172A))
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(16.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { viewModel.navigateTo(AppScreen.MAIN_MENU) },
                        modifier = Modifier.testTag("builder_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Menu",
                            tint = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Column {
                        Text(
                            text = "ASSEMBLY HANGAR",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF38BDF8),
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = activeRocket.name,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Undo & Redo buttons
                    IconButton(
                        onClick = { viewModel.undo() },
                        enabled = canUndo,
                        modifier = Modifier.testTag("builder_undo_button")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.Undo,
                            contentDescription = "Undo",
                            tint = if (canUndo) Color.White else Color(0xFF475569)
                        )
                    }

                    IconButton(
                        onClick = { viewModel.redo() },
                        enabled = canRedo,
                        modifier = Modifier.testTag("builder_redo_button")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.Redo,
                            contentDescription = "Redo",
                            tint = if (canRedo) Color.White else Color(0xFF475569)
                        )
                    }

                    FilledTonalButton(
                        onClick = { showStagingDrawer = !showStagingDrawer },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = if (showStagingDrawer) Color(0xFF0284C7) else Color(0xFF1E293B)
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Layers, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Staging", fontSize = 12.sp, color = Color.White)
                    }

                    FilledTonalButton(
                        onClick = { showSaveDialog = true },
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Save", fontSize = 12.sp, color = Color.White)
                    }

                    FilledTonalButton(
                        onClick = {
                            viewModel.refreshSavedRockets()
                            showSavedListDialog = true
                        },
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null, tint = Color(0xFFFBBF24), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Load", fontSize = 12.sp, color = Color.White)
                    }

                    FilledTonalButton(
                        onClick = { viewModel.clearRocketAssembly() },
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFF3B1E2B)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = Color(0xFFF87171), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Clear", fontSize = 12.sp, color = Color(0xFFFCA5A5))
                    }

                    // Direct Launch Button
                    Button(
                        onClick = { viewModel.navigateTo(AppScreen.FLIGHT) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("test_launch_button")
                    ) {
                        Icon(Icons.Default.RocketLaunch, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("LAUNCH", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }

        // Left Part Catalog Dock
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 16.dp, top = 80.dp, bottom = 100.dp)
                .width(330.dp)
        ) {
            Card(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(18.dp)),
                colors = CardDefaults.cardColors(containerColor = Color(0xEE0F172A))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "MODULAR PARTS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF94A3B8),
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "₵$credits",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFFD54F)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Category Tabs
                    ScrollableTabRow(
                        selectedTabIndex = PartCategory.entries.indexOf(activeCategory),
                        edgePadding = 0.dp,
                        containerColor = Color.Transparent,
                        divider = {}
                    ) {
                        PartCategory.entries.forEach { cat ->
                            Tab(
                                selected = cat == activeCategory,
                                onClick = { viewModel.setActiveCategory(cat) },
                                text = { Text(cat.title, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                                selectedContentColor = Color(0xFF38BDF8),
                                unselectedContentColor = Color(0xFF64748B)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Parts list in active category
                    val categoryParts = PartType.entries.filter { it.category == activeCategory }
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(categoryParts) { partType ->
                            val isUnlocked = viewModel.progressionSystem.isPartUnlocked(partType)
                            PartCatalogCard(
                                partType = partType,
                                isUnlocked = isUnlocked,
                                onAdd = {
                                    if (isUnlocked) {
                                        viewModel.addPart(partType)
                                    } else {
                                        viewModel.unlockPart(partType)
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }

        // Staging Manager Overlay (Shown when "Staging" is toggled)
        if (showStagingDrawer) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(horizontal = 40.dp)
                    .width(420.dp)
                    .height(480.dp)
            ) {
                StagingManagerCard(
                    rocket = activeRocket,
                    onClose = { showStagingDrawer = false },
                    onMovePartStage = { part, delta -> viewModel.movePartStage(part, delta) }
                )
            }
        }

        // Right Part Inspector Dock (Shown when a part is selected)
        AnimatedVisibility(
            visible = selectedPart != null && !showStagingDrawer,
            enter = slideInHorizontally(initialOffsetX = { it }),
            exit = slideOutHorizontally(targetOffsetX = { it }),
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 16.dp, top = 80.dp, bottom = 100.dp)
                .width(310.dp)
        ) {
            selectedPart?.let { part ->
                PartInspectorCard(
                    part = part,
                    onDeselect = { viewModel.selectPart(null) },
                    onSnap = { viewModel.snapSelectedPart() },
                    onMove = { dx, dy, dz -> viewModel.moveSelectedPart(dx, dy, dz) },
                    onRotate = { deg -> viewModel.rotateSelectedPart(deg) },
                    onStageChange = { stage -> viewModel.setSelectedPartStage(stage) },
                    onDuplicate = { viewModel.duplicateSelectedPart() },
                    onDelete = { viewModel.removeSelectedPart() }
                )
            }
        }

        // Touch Control Guidance Hint
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 90.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0x990F172A))
                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(20.dp))
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            Text(
                text = "Drag 3D view to rotate • Pinch to zoom • Tap part to inspect & snap",
                fontSize = 11.sp,
                color = Color(0xFF94A3B8)
            )
        }

        // Bottom Vehicle Stats Bar
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = Color(0xEE0F172A))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatMetric(
                        title = "TOTAL MASS",
                        value = "${(activeRocket.totalMass() / 1000.0).format(2)} t",
                        sub = "${activeRocket.totalDryMass().toInt()} kg dry"
                    )
                    StatMetric(
                        title = "PROPELLANT",
                        value = "${activeRocket.totalFuelRemaining().toInt()} kg",
                        sub = "Capacity: ${activeRocket.totalFuelCapacity().toInt()} kg"
                    )
                    val twr0 = activeRocket.twr(0)
                    StatMetric(
                        title = "LAUNCH TWR",
                        value = twr0.format(2),
                        sub = if (twr0 >= 1.2) "Flight Capable" else "Needs Thrust",
                        color = if (twr0 >= 1.2) Color(0xFF4ADE80) else Color(0xFFF87171)
                    )
                    StatMetric(
                        title = "STAGE 0 THRUST",
                        value = "${(activeRocket.thrustForStage(0) / 1000.0).toInt()} kN",
                        sub = "Sea Level"
                    )
                    StatMetric(
                        title = "EST. DELTA-V",
                        value = "${activeRocket.totalEstimatedDeltaV().toInt()} m/s",
                        sub = "Vacuum potential",
                        color = Color(0xFF38BDF8)
                    )
                    StatMetric(
                        title = "VEHICLE COST",
                        value = "₵${activeRocket.totalCost()}",
                        sub = "${activeRocket.parts.size} Parts",
                        color = Color(0xFFFFD54F)
                    )
                }
            }
        }
    }

    // Save Dialog
    if (showSaveDialog) {
        SaveNameDialog(
            currentName = activeRocket.name,
            onDismiss = { showSaveDialog = false },
            onConfirm = { name ->
                viewModel.saveActiveRocket(name)
                showSaveDialog = false
            }
        )
    }

    // Load Dialog
    if (showSavedListDialog) {
        SavedRocketsDialog(
            viewModel = viewModel,
            onDismiss = { showSavedListDialog = false }
        )
    }
}

@Composable
fun PartCatalogCard(
    partType: PartType,
    isUnlocked: Boolean,
    onAdd: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onAdd() }
            .border(
                1.dp,
                if (isUnlocked) Color(0xFF1E293B) else Color(0xFF334155),
                RoundedCornerShape(12.dp)
            ),
        colors = CardDefaults.cardColors(
            containerColor = if (isUnlocked) Color(0xFF1E293B) else Color(0xFF141B2D)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = partType.displayName,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isUnlocked) Color.White else Color(0xFF94A3B8)
                    )
                    if (!isUnlocked) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            Icons.Default.Lock,
                            contentDescription = "Locked",
                            tint = Color(0xFFFFB74D),
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }
                Text(
                    text = "${partType.dryMass.toInt()} kg dry" +
                            if (partType.fuelCapacity > 0) " • ${partType.fuelCapacity.toInt()} kg fuel" else "" +
                            if (partType.thrust > 0) " • ${(partType.thrust / 1000.0).toInt()} kN" else "",
                    fontSize = 11.sp,
                    color = Color(0xFF94A3B8)
                )
            }

            IconButton(
                onClick = onAdd,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(if (isUnlocked) Color(0xFF0284C7) else Color(0xFF334155))
            ) {
                Icon(
                    imageVector = if (isUnlocked) Icons.Default.Add else Icons.Default.LockOpen,
                    contentDescription = if (isUnlocked) "Add Part" else "Unlock Part",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun PartInspectorCard(
    part: PlacedPart,
    onDeselect: () -> Unit,
    onSnap: () -> Unit,
    onMove: (dx: Float, dy: Float, dz: Float) -> Unit,
    onRotate: (deg: Float) -> Unit,
    onStageChange: (stage: Int) -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxHeight()
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, Color(0xFF38BDF8), RoundedCornerShape(18.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xEE0F172A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "SELECTED PART",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF38BDF8),
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = part.type.displayName,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                    IconButton(onClick = onDeselect) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF94A3B8))
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Auto Snap Button
                Button(
                    onClick = onSnap,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                ) {
                    Icon(Icons.Default.FlashOn, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Auto-Snap to Node", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                HorizontalDivider(color = Color(0xFF334155), modifier = Modifier.padding(vertical = 10.dp))

                // Staging assignment
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Stage Assignment", fontSize = 12.sp, color = Color(0xFFE2E8F0))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        FilledIconButton(
                            onClick = { onStageChange(part.stageIndex - 1) },
                            modifier = Modifier.size(32.dp),
                            colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFF334155))
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = "Decrease Stage", tint = Color.White)
                        }
                        Text(
                            text = "${part.stageIndex}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color(0xFF38BDF8),
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                        FilledIconButton(
                            onClick = { onStageChange(part.stageIndex + 1) },
                            modifier = Modifier.size(32.dp),
                            colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFF334155))
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Increase Stage", tint = Color.White)
                        }
                    }
                }

                HorizontalDivider(color = Color(0xFF334155), modifier = Modifier.padding(vertical = 10.dp))

                // 3D Stacking Offset Adjustments
                Text("Vertical Position (Y)", fontSize = 11.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(
                        onClick = { onMove(0f, 0.4f, 0f) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFF334155))
                    ) {
                        Icon(Icons.Default.KeyboardArrowUp, contentDescription = null)
                        Text("+0.4m", fontSize = 11.sp)
                    }
                    FilledTonalButton(
                        onClick = { onMove(0f, -0.4f, 0f) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFF334155))
                    ) {
                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = null)
                        Text("-0.4m", fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text("Lateral Offset (X / Z)", fontSize = 11.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(
                        onClick = { onMove(-0.3f, 0f, 0f) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFF334155))
                    ) {
                        Text("Left", fontSize = 11.sp)
                    }
                    FilledTonalButton(
                        onClick = { onMove(0.3f, 0f, 0f) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFF334155))
                    ) {
                        Text("Right", fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedButton(
                    onClick = { onRotate(90f) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF38BDF8))
                ) {
                    Icon(Icons.AutoMirrored.Filled.RotateRight, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Rotate 90° (${part.rotationYDeg.toInt()}°)", fontSize = 11.sp)
                }
            }

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onDuplicate,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Clone", fontSize = 12.sp)
                }

                Button(
                    onClick = onDelete,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Delete", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun StagingManagerCard(
    rocket: RocketDesign,
    onClose: () -> Unit,
    onMovePartStage: (PlacedPart, Int) -> Unit
) {
    val stages = rocket.parts.groupBy { it.stageIndex }.toSortedMap()

    Card(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, Color(0xFF0284C7), RoundedCornerShape(18.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xF00F172A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "STAGING SEQUENCE",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.White
                )
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(stages.keys.toList()) { stageIdx ->
                    val partsInStage = stages[stageIdx] ?: emptyList()
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(10.dp)),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                "Stage $stageIdx (${partsInStage.size} parts)",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF38BDF8),
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            partsInStage.forEach { part ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 2.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        "• ${part.type.displayName}",
                                        fontSize = 12.sp,
                                        color = Color.White
                                    )
                                    Row {
                                        IconButton(
                                            onClick = { onMovePartStage(part, -1) },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Default.KeyboardArrowUp, contentDescription = null, tint = Color(0xFF94A3B8))
                                        }
                                        IconButton(
                                            onClick = { onMovePartStage(part, 1) },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Default.KeyboardArrowDown, contentDescription = null, tint = Color(0xFF94A3B8))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatMetric(
    title: String,
    value: String,
    sub: String,
    color: Color = Color.White
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF94A3B8))
        Text(value, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = color)
        Text(sub, fontSize = 9.sp, color = Color(0xFF64748B))
    }
}

@Composable
fun SaveNameDialog(
    currentName: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var text by remember { mutableStateOf(currentName) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Save Rocket Design", color = Color.White) },
        text = {
            Column {
                Text("Enter a name for this spacecraft:", fontSize = 13.sp, color = Color(0xFF94A3B8))
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF38BDF8),
                        unfocusedBorderColor = Color(0xFF475569)
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(text) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color(0xFF94A3B8))
            }
        },
        containerColor = Color(0xFF1E293B)
    )
}
