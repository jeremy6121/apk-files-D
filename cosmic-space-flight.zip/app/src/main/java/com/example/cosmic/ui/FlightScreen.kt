package com.example.cosmic.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.cosmic.physics.*
import kotlin.math.abs

@Composable
fun FlightScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val flightStateNullable by viewModel.flightState.collectAsStateWithLifecycle()
    val isPaused by viewModel.isPaused.collectAsStateWithLifecycle()
    val isOrbitMap by viewModel.isOrbitMapActive.collectAsStateWithLifecycle()
    val statusAlert by viewModel.statusAlert.collectAsStateWithLifecycle()

    val flight = flightStateNullable ?: return

    var stageArmed by remember { mutableStateOf(false) }
    var showTargetDialog by remember { mutableStateOf(false) }
    var showStationDeployDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // 3D OpenGL Surface View (Renders Planet, Rocket, Space, Particles, Debris)
        CosmicGLView(
            renderer = viewModel.glRenderer,
            modifier = Modifier.fillMaxSize()
        )

        // Top Telemetry Header Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xCC0F172A))
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(16.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // MET & Situation
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        val metMins = (flight.metSeconds / 60).toInt()
                        val metSecs = (flight.metSeconds % 60).toInt()
                        Text(
                            text = "MET %02d:%02d".format(metMins, metSecs),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF38BDF8)
                        )
                        Text(
                            text = "${flight.primaryBody.name} • ${flight.status.label}",
                            fontSize = 11.sp,
                            color = when (flight.status) {
                                FlightStatus.LANDED -> Color(0xFF4ADE80)
                                FlightStatus.CRASHED -> Color(0xFFF87171)
                                FlightStatus.ORBIT -> Color(0xFF38BDF8)
                                FlightStatus.REENTRY -> Color(0xFFFB923C)
                                else -> Color(0xFF94A3B8)
                            },
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Time Warp Buttons
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(1, 2, 5, 10, 50).forEach { warp ->
                        FilterChip(
                            selected = flight.timeWarp == warp,
                            onClick = { viewModel.setTimeWarp(warp) },
                            label = { Text("${warp}x", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF0284C7),
                                selectedLabelColor = Color.White,
                                containerColor = Color(0xFF1E293B),
                                labelColor = Color(0xFF94A3B8)
                            )
                        )
                    }
                }

                // Interplanetary Target Selector Chip
                AssistChip(
                    onClick = {
                        viewModel.playClickSound()
                        showTargetDialog = true
                    },
                    label = {
                        Text(
                            text = flight.targetBody?.name ?: "Target: None",
                            fontSize = 11.sp,
                            color = if (flight.targetBody != null) Color(0xFFFFD700) else Color(0xFF94A3B8)
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Adjust,
                            contentDescription = "Target",
                            tint = if (flight.targetBody != null) Color(0xFFFFD700) else Color(0xFF94A3B8),
                            modifier = Modifier.size(14.dp)
                        )
                    },
                    colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFF1E293B)),
                    modifier = Modifier.testTag("target_selector_chip")
                )

                // Map & Pause Controls
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(
                        onClick = { viewModel.toggleOrbitMap() },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = if (isOrbitMap) Color(0xFF0284C7) else Color(0xFF1E293B)
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("orbit_map_toggle")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Public,
                            contentDescription = "Map View",
                            tint = if (isOrbitMap) Color.White else Color(0xFF38BDF8),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isOrbitMap) "3D VIEW" else "ORBIT MAP", fontSize = 11.sp, color = Color.White)
                    }

                    IconButton(
                        onClick = { viewModel.togglePause() },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF334155))
                            .testTag("pause_button")
                    ) {
                        Icon(Icons.Default.Pause, contentDescription = "Pause", tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        // Left HUD: Altitude, Velocity, Propellant, VSI
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 16.dp, top = 80.dp, bottom = 120.dp)
                .width(220.dp)
        ) {
            Card(
                modifier = Modifier
                    .clip(RoundedCornerShape(18.dp))
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(18.dp)),
                colors = CardDefaults.cardColors(containerColor = Color(0xDD0F172A))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Altitude Gauge
                    Column {
                        Text("ALTITUDE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF94A3B8))
                        val altText = if (flight.altitude >= 10_000.0) {
                            "${(flight.altitude / 1000.0).format(2)} km"
                        } else {
                            "${flight.altitude.toInt()} m"
                        }
                        Text(
                            text = altText,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFFF8FAFC)
                        )
                        Text(
                            text = if (flight.altitude > flight.primaryBody.atmosphereHeight) "Vacuum (Space)" else "Atmosphere",
                            fontSize = 10.sp,
                            color = if (flight.altitude > flight.primaryBody.atmosphereHeight) Color(0xFF38BDF8) else Color(0xFF81D4FA)
                        )
                    }

                    HorizontalDivider(color = Color(0xFF334155))

                    // Speed & Vertical Velocity
                    Column {
                        Text("SURFACE VELOCITY", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF94A3B8))
                        Text(
                            text = "${flight.surfaceSpeed.toInt()} m/s",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFFF8FAFC)
                        )
                        val vert = flight.verticalSpeed
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (vert >= 0) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                                contentDescription = null,
                                tint = if (vert >= 0) Color(0xFF4ADE80) else Color(0xFFFB923C),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "VSI: ${vert.toInt()} m/s",
                                fontSize = 11.sp,
                                color = if (vert >= 0) Color(0xFF4ADE80) else Color(0xFFFB923C),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    HorizontalDivider(color = Color(0xFF334155))

                    // Fuel Level
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("PROPELLANT", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF94A3B8))
                            Text("${flight.currentStageFuelPercentage.toInt()}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { flight.currentStageFuelPercentage / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = if (flight.currentStageFuelPercentage > 20f) Color(0xFF38BDF8) else Color(0xFFEF4444),
                            trackColor = Color(0xFF334155)
                        )
                        Text(
                            text = "Stage ${flight.activeStage} Tank",
                            fontSize = 9.sp,
                            color = Color(0xFF64748B),
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }

                    // Battery / Power Level
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("ELECTRICAL", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF94A3B8))
                                if (flight.solarPowerGenerating) {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(
                                        Icons.Default.Bolt,
                                        contentDescription = "Solar Charging",
                                        tint = Color(0xFFFFD54F),
                                        modifier = Modifier.size(12.dp)
                                    )
                                }
                            }
                            Text("${flight.batteryCharge.toInt()}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        LinearProgressIndicator(
                            progress = { flight.batteryCharge / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = if (flight.batteryCharge > 20f) Color(0xFFFFD54F) else Color(0xFFEF4444),
                            trackColor = Color(0xFF334155)
                        )
                    }

                    // Radar Altitude (AGL) for Landing
                    if (flight.altitude < 2500.0) {
                        Column {
                            Text("RADAR ALT (AGL)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF4ADE80))
                            Text(
                                text = "${flight.radarAltitude.toInt()} m",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF4ADE80)
                            )
                        }
                    }

                    // Re-entry heat / dynamic pressure alert
                    if (flight.reentryHeat > 0.05f) {
                        HorizontalDivider(color = Color(0xFF334155))
                        Column {
                            Text("RE-ENTRY SHEATH", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFB923C))
                            LinearProgressIndicator(
                                progress = { flight.reentryHeat },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = Color(0xFFEF4444),
                                trackColor = Color(0xFF334155)
                            )
                        }
                    }

                    // G-Force
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("G-FORCE", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        Text("${flight.gForce.format(1)} G", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }

        // Right HUD: Orbital Parameters (Apoapsis, Periapsis, Orbit Status)
        val orbitInfo = remember(flight.position, flight.velocity) {
            OrbitalMath.computeOrbit(flight.position, flight.velocity, flight.primaryBody)
        }
        Box(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 16.dp, top = 80.dp)
                .width(220.dp)
        ) {
            Card(
                modifier = Modifier
                    .clip(RoundedCornerShape(18.dp))
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(18.dp)),
                colors = CardDefaults.cardColors(containerColor = Color(0xDD0F172A))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "ORBITAL PARAMETERS",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF38BDF8),
                        letterSpacing = 1.sp
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Apoapsis (Ap)", fontSize = 11.sp, color = Color(0xFF94A3B8))
                        val apText = if (orbitInfo.apoapsisAltitude.isInfinite()) "Escape" else "${(orbitInfo.apoapsisAltitude / 1000.0).format(1)} km"
                        Text(apText, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Periapsis (Pe)", fontSize = 11.sp, color = Color(0xFF94A3B8))
                        val peText = "${(orbitInfo.periapsisAltitude / 1000.0).format(1)} km"
                        Text(
                            text = peText,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (orbitInfo.periapsisAltitude > flight.primaryBody.atmosphereHeight) Color(0xFF4ADE80) else Color(0xFFFB923C)
                        )
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Eccentricity (e)", fontSize = 11.sp, color = Color(0xFF94A3B8))
                        Text(orbitInfo.eccentricity.format(3), fontSize = 12.sp, color = Color.White)
                    }

                    if (orbitInfo.isStableOrbit) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0x334ADE80),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "STABLE CLOSED ORBIT",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF4ADE80),
                                modifier = Modifier.padding(vertical = 4.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }

                        // V3 Convert to Space Station / Satellite button
                        Button(
                            onClick = { showStationDeployDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00C853)),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(32.dp)
                        ) {
                            Icon(Icons.Default.Apartment, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("DEPLOY AS STATION", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Power & Systems
                    HorizontalDivider(color = Color(0xFF334155))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Solar Power", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        Text("${flight.solarPowerGeneratedKw.format(1)} kW", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFD700))
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Battery", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        Text("${flight.batteryChargePercent.toInt()}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
                    }

                    // Interplanetary Target Info
                    flight.targetBody?.let { target ->
                        HorizontalDivider(color = Color(0xFF334155))
                        Text("TARGET: ${target.name.uppercase()}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFD700))
                        val reqDv = OrbitalMath.planHohmannTransfer(flight.primaryBody, target).totalDeltaV
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Transfer ΔV", fontSize = 10.sp, color = Color(0xFF94A3B8))
                            Text("${reqDv.toInt()} m/s", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFD700))
                        }
                    }
                }
            }
        }

        // Bottom-Left Controls: Throttle Control Slider & Quick Step Buttons
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .navigationBarsPadding()
                .padding(start = 16.dp, bottom = 16.dp)
        ) {
            Card(
                modifier = Modifier
                    .clip(RoundedCornerShape(18.dp))
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(18.dp)),
                colors = CardDefaults.cardColors(containerColor = Color(0xEE0F172A))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Vertical Throttle Slider
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.height(160.dp)
                    ) {
                        Text(
                            text = "${(flight.throttle * 100).toInt()}%",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF38BDF8)
                        )

                        Slider(
                            value = flight.throttle,
                            onValueChange = { viewModel.setThrottle(it) },
                            valueRange = 0f..1f,
                            modifier = Modifier
                                .weight(1f)
                                .width(120.dp)
                                .testTag("throttle_slider"),
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFF38BDF8),
                                activeTrackColor = Color(0xFF0284C7),
                                inactiveTrackColor = Color(0xFF334155)
                            )
                        )

                        Text("THROTTLE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
                    }

                    // Quick Step Buttons & Countdown Ignition Button
                    Column(
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (flight.status == FlightStatus.PRE_LAUNCH) {
                            Button(
                                onClick = { viewModel.launchCountdown() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .width(90.dp)
                                    .height(50.dp)
                                    .testTag("ignite_button")
                            ) {
                                Text("IGNITE", fontWeight = FontWeight.Black, fontSize = 13.sp)
                            }
                        } else {
                            FilledTonalButton(
                                onClick = { viewModel.setThrottle(1.0f) },
                                modifier = Modifier.width(80.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFF1E293B)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("100%", fontSize = 11.sp, color = Color.White)
                            }

                            FilledTonalButton(
                                onClick = { viewModel.setThrottle(0.5f) },
                                modifier = Modifier.width(80.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFF1E293B)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("50%", fontSize = 11.sp, color = Color.White)
                            }

                            FilledTonalButton(
                                onClick = { viewModel.setThrottle(0.0f) },
                                modifier = Modifier.width(80.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFF3B1E2B)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("CUT", fontSize = 11.sp, color = Color(0xFFF87171), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Bottom-Right Controls: STAGE Button & Virtual Steering Pad & SAS
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(end = 16.dp, bottom = 16.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                // SAS Autopilot modes card
                Card(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, Color(0xFF334155), RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color(0xEE0F172A))
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "AUTOPILOT",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF94A3B8)
                        )
                        SasMode.entries.forEach { mode ->
                            FilterChip(
                                selected = flight.sasMode == mode,
                                onClick = { viewModel.setSasMode(mode) },
                                label = { Text(mode.title, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFF0284C7),
                                    selectedLabelColor = Color.White,
                                    containerColor = Color(0xFF1E293B),
                                    labelColor = Color(0xFF94A3B8)
                                ),
                                modifier = Modifier.height(30.dp)
                            )
                        }

                        HorizontalDivider(color = Color(0xFF334155), modifier = Modifier.padding(vertical = 2.dp))

                        // Utility toggles (Gear, Chute)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            FilledTonalButton(
                                onClick = { viewModel.toggleLandingGear() },
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = if (flight.landingGearDeployed) Color(0xFF0284C7) else Color(0xFF1E293B)
                                ),
                                contentPadding = PaddingValues(horizontal = 8.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("GEAR", fontSize = 10.sp, color = Color.White)
                            }

                            FilledTonalButton(
                                onClick = { viewModel.toggleParachute() },
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = if (flight.parachuteDeployed) Color(0xFF0284C7) else Color(0xFF1E293B)
                                ),
                                contentPadding = PaddingValues(horizontal = 8.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("CHUTE", fontSize = 10.sp, color = Color.White)
                            }
                        }
                    }
                }

                // Attitude Steering Virtual Pad (Pitch / Yaw)
                Card(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, Color(0xFF334155), RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color(0xEE0F172A))
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("STEERING", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
                        Spacer(modifier = Modifier.height(4.dp))

                        // Up (Pitch +)
                        FilledIconButton(
                            onClick = { viewModel.touchPitchInput = -1f },
                            modifier = Modifier.size(40.dp),
                            colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFF334155))
                        ) {
                            Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Pitch Up", tint = Color.White)
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Left (Yaw -)
                            FilledIconButton(
                                onClick = { viewModel.touchYawInput = -1f },
                                modifier = Modifier.size(40.dp),
                                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFF334155))
                            ) {
                                Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Yaw Left", tint = Color.White)
                            }

                            // Center Neutralizer
                            FilledIconButton(
                                onClick = {
                                    viewModel.touchPitchInput = 0f
                                    viewModel.touchYawInput = 0f
                                },
                                modifier = Modifier.size(28.dp),
                                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFF1E293B))
                            ) {
                                Icon(Icons.Default.CenterFocusStrong, contentDescription = "Center", tint = Color(0xFF38BDF8), modifier = Modifier.size(16.dp))
                            }

                            // Right (Yaw +)
                            FilledIconButton(
                                onClick = { viewModel.touchYawInput = 1f },
                                modifier = Modifier.size(40.dp),
                                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFF334155))
                            ) {
                                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Yaw Right", tint = Color.White)
                            }
                        }

                        // Down (Pitch -)
                        FilledIconButton(
                            onClick = { viewModel.touchPitchInput = 1f },
                            modifier = Modifier.size(40.dp),
                            colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFF334155))
                        ) {
                            Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Pitch Down", tint = Color.White)
                        }
                    }
                }

                // Giant STAGE Separation & Ignition Button
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Safety Arm switch
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Switch(
                            checked = stageArmed,
                            onCheckedChange = { stageArmed = it },
                            modifier = Modifier.height(28.dp)
                        )
                        Text(
                            text = if (stageArmed) "ARMED" else "SAFE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (stageArmed) Color(0xFFEF4444) else Color(0xFF94A3B8)
                        )
                    }

                    Button(
                        onClick = {
                            if (stageArmed || flight.status == FlightStatus.PRE_LAUNCH) {
                                viewModel.triggerStage()
                                stageArmed = false
                            }
                        },
                        enabled = stageArmed || flight.status == FlightStatus.PRE_LAUNCH,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (stageArmed) Color(0xFFDC2626) else Color(0xFF475569)
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .size(width = 96.dp, height = 96.dp)
                            .testTag("stage_button")
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Layers, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.height(2.dp))
                            Text("STAGE", fontWeight = FontWeight.Black, fontSize = 14.sp, color = Color.White)
                            Text("Stg ${flight.activeStage}", fontSize = 10.sp, color = Color(0xFFE2E8F0))
                        }
                    }
                }
            }
        }

        // Mission Alert Notification Pill Toast
        AnimatedVisibility(
            visible = statusAlert != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 90.dp)
        ) {
            statusAlert?.let { alert ->
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xEE0284C7),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF38BDF8))
                ) {
                    Text(
                        text = alert,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)
                    )
                }
            }
        }

        // Landed / Crashed Outcome Card
        if (flight.status == FlightStatus.LANDED || flight.status == FlightStatus.CRASHED) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x88000000)),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .width(360.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .border(1.dp, Color(0xFF334155), RoundedCornerShape(20.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        val isSafeLanding = flight.status == FlightStatus.LANDED
                        Icon(
                            imageVector = if (isSafeLanding) Icons.Default.CheckCircle else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (isSafeLanding) Color(0xFF4ADE80) else Color(0xFFEF4444),
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (isSafeLanding) "TOUCHDOWN CONFIRMED!" else "VEHICLE DESTROYED",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Text(
                            text = if (isSafeLanding)
                                "Spacecraft has landed safely intact on ${flight.primaryBody.name}!"
                            else
                                "Impact velocity exceeded vehicle structural limits.",
                            fontSize = 13.sp,
                            color = Color(0xFF94A3B8),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            modifier = Modifier.padding(top = 6.dp)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // V3 Booster Recovery Button
                        if (flight.isRecoverable) {
                            val refund = flight.calculateRecoveryRefund()
                            Button(
                                onClick = { viewModel.recoverFlight() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00C853)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("recover_booster_button")
                            ) {
                                Icon(Icons.Default.CurrencyExchange, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("RECOVER CRAFT (+$refund C)", fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                        }

                        Button(
                            onClick = { viewModel.restartFlight() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Retry Flight")
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedButton(
                            onClick = { viewModel.navigateTo(AppScreen.BUILDER) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Back to Builder", color = Color(0xFFE2E8F0))
                        }
                    }
                }
            }
        }

        // Pause Menu Dialog
        if (isPaused) {
            AlertDialog(
                onDismissRequest = { viewModel.togglePause() },
                title = {
                    Text("Flight Paused", color = Color.White, fontWeight = FontWeight.Bold)
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Mission Elapsed Time: ${(flight.metSeconds / 60).toInt()}m ${(flight.metSeconds % 60).toInt()}s", color = Color(0xFF94A3B8))
                        Text("Altitude: ${(flight.altitude / 1000.0).format(1)} km", color = Color(0xFF94A3B8))
                        Text("Speed: ${flight.speed.toInt()} m/s", color = Color(0xFF94A3B8))
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { viewModel.togglePause() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                    ) {
                        Text("Resume")
                    }
                },
                dismissButton = {
                    Row {
                        TextButton(onClick = { viewModel.restartFlight() }) {
                            Text("Restart", color = Color(0xFFFBBF24))
                        }
                        TextButton(onClick = { viewModel.navigateTo(AppScreen.BUILDER) }) {
                            Text("VAB Builder", color = Color(0xFF38BDF8))
                        }
                        TextButton(onClick = { viewModel.navigateTo(AppScreen.MAIN_MENU) }) {
                            Text("Main Menu", color = Color(0xFF94A3B8))
                        }
                    }
                },
                containerColor = Color(0xFF1E293B)
            )
        }
        // Docking Assistance HUD Overlay
        flight.dockingDistanceMeters?.let { dist ->
            if (dist < 500.0) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 80.dp)
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xEE101624)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.border(1.dp, if (flight.isDockingAligned) Color(0xFF00E676) else Color(0xFF0288D1), RoundedCornerShape(14.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Column {
                                Text("DOCKING RADAR", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00E676))
                                Text("Target: ${flight.dockingTargetName}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Text("Distance: ${dist.toInt()} m", fontSize = 11.sp, color = Color.LightGray)
                            }

                            if (flight.isDockingAligned) {
                                Button(
                                    onClick = { viewModel.attemptDocking() },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00C853)),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.testTag("dock_clamp_button")
                                ) {
                                    Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("LOCK DOCKING CLAMPS", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Interplanetary Target Selector Dialog
        if (showTargetDialog) {
            AlertDialog(
                onDismissRequest = { showTargetDialog = false },
                containerColor = Color(0xFF1E293B),
                title = { Text("Select Navigation Target", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(
                            onClick = {
                                viewModel.selectTargetBody(null)
                                showTargetDialog = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Clear Target", color = Color(0xFFFF5252))
                        }
                        SolarSystem.allBodies.filter { it != flight.primaryBody && it != SolarSystem.STAR_HELIOS }.forEach { body ->
                            FilledTonalButton(
                                onClick = {
                                    viewModel.selectTargetBody(body)
                                    showTargetDialog = false
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFF334155))
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(body.name, fontWeight = FontWeight.Bold, color = Color.White)
                                    val reqDv = OrbitalMath.planHohmannTransfer(flight.primaryBody, body).totalDeltaV
                                    Text("Est. ΔV: ${reqDv.toInt()} m/s", fontSize = 11.sp, color = Color(0xFFFFD700))
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showTargetDialog = false }) {
                        Text("Close", color = Color.Gray)
                    }
                }
            )
        }

        // Station Deployment Dialog
        if (showStationDeployDialog) {
            var stationName by remember { mutableStateOf("${flight.rocket.name} Station") }
            var isStation by remember { mutableStateOf(true) }

            AlertDialog(
                onDismissRequest = { showStationDeployDialog = false },
                containerColor = Color(0xFF1E293B),
                title = { Text("Deploy into Orbital Fleet", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Craft Name:", fontSize = 12.sp, color = Color.LightGray)
                        OutlinedTextField(
                            value = stationName,
                            onValueChange = { stationName = it },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = isStation,
                                onClick = { isStation = true },
                                label = { Text("Space Station") }
                            )
                            FilterChip(
                                selected = !isStation,
                                onClick = { isStation = false },
                                label = { Text("Satellite / Probe") }
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.convertFlightToStation(
                                stationName,
                                if (isStation) com.example.cosmic.model.VesselType.SPACE_STATION else com.example.cosmic.model.VesselType.SATELLITE_COMM
                            )
                            showStationDeployDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00C853))
                    ) {
                        Text("Deploy Craft")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showStationDeployDialog = false }) {
                        Text("Cancel", color = Color.Gray)
                    }
                }
            )
        }
    }
}
