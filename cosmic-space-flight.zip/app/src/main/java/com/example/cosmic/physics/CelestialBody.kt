package com.example.cosmic.physics

import com.example.cosmic.math.Vector3D
import kotlin.math.*

const val GRAVITATIONAL_CONSTANT = 6.67430e-11

enum class TerrainType(val label: String) {
    OCEAN_CONTINENT("Atmospheric Oceans & Continents"),
    CRATERED_VACUUM("Barren Regolith & Craters"),
    VOLCANIC_DESERT("Basalt Dunes & Volcanic Calderas"),
    GAS_GIANT_RINGS("Gaseous Cloud Bands & Cryo Rings"),
    GLACIAL_ICE("Frozen Nitrogen & Glacial Ridges")
}

data class CelestialBody(
    val name: String,
    val radius: Double, // in meters
    val mass: Double, // in kg
    val atmosphereHeight: Double = 0.0, // in meters (0 if vacuum)
    val atmosphereScaleHeight: Double = 7500.0,
    val seaLevelDensity: Double = 1.225, // kg/m^3
    val surfaceColorHex: Long = 0xFF2A52BE,
    val atmosphereColorHex: Long = 0xFF64B5F6,
    val rotationSpeedRadPerSec: Double = 0.0002, // planetary rotation
    var position: Vector3D = Vector3D.ZERO,
    var velocity: Vector3D = Vector3D.ZERO,
    val parentBody: CelestialBody? = null,
    val orbitRadius: Double = 0.0,
    val orbitalSpeed: Double = 0.0,
    val sphereOfInfluenceRadius: Double = 200_000.0,
    val terrainType: TerrainType = TerrainType.CRATERED_VACUUM,
    val hasRings: Boolean = false,
    val ringInnerRadius: Double = 0.0,
    val ringOuterRadius: Double = 0.0,
    val description: String = ""
) {
    val mu: Double = GRAVITATIONAL_CONSTANT * mass // Standard gravitational parameter

    val surfaceGravity: Double
        get() = mu / (radius * radius)

    val colorRgba: FloatArray
        get() {
            val r = (((surfaceColorHex shr 16) and 0xFF).toFloat()) / 255f
            val g = (((surfaceColorHex shr 8) and 0xFF).toFloat()) / 255f
            val b = ((surfaceColorHex and 0xFF).toFloat()) / 255f
            return floatArrayOf(r, g, b, 1.0f)
        }

    val atmosphereColorRgba: FloatArray
        get() {
            val r = (((atmosphereColorHex shr 16) and 0xFF).toFloat()) / 255f
            val g = (((atmosphereColorHex shr 8) and 0xFF).toFloat()) / 255f
            val b = ((atmosphereColorHex and 0xFF).toFloat()) / 255f
            return floatArrayOf(r, g, b, 0.45f)
        }

    /**
     * Calculates gravitational acceleration vector exerted on a body at `targetPos`.
     */
    fun getGravityAt(targetPos: Vector3D): Vector3D {
        val rVec = position - targetPos // vector from target to this body center
        val distSq = rVec.lengthSquared()
        val dist = sqrt(distSq)
        if (dist < 1e-3) return Vector3D.ZERO
        val accMag = mu / distSq
        return (rVec / dist) * accMag
    }

    /**
     * Atmospheric density at an altitude above sea level.
     */
    fun getAtmosphericDensity(altitude: Double): Double {
        if (atmosphereHeight <= 0.0 || altitude < 0.0 || altitude >= atmosphereHeight) return 0.0
        // Exponential barometric formula
        return seaLevelDensity * exp(-altitude / atmosphereScaleHeight)
    }

    /**
     * Calculates orbital position at a given time without mutating current state.
     */
    fun currentPosition(gameTimeSec: Double = 0.0): Vector3D {
        if (parentBody != null && orbitRadius > 0.0) {
            val meanMotion = sqrt(parentBody.mu / (orbitRadius * orbitRadius * orbitRadius))
            val angle = meanMotion * gameTimeSec
            val px = parentBody.position.x + orbitRadius * cos(angle)
            val pz = parentBody.position.z + orbitRadius * sin(angle)
            return Vector3D(px, parentBody.position.y, pz)
        }
        return position
    }

    /**
     * Updates celestial body orbit around parent body if applicable.
     */
    fun updateOrbit(gameTimeSec: Double) {
        if (parentBody != null && orbitRadius > 0.0) {
            val meanMotion = sqrt(parentBody.mu / (orbitRadius * orbitRadius * orbitRadius))
            val angle = meanMotion * gameTimeSec
            val px = parentBody.position.x + orbitRadius * cos(angle)
            val pz = parentBody.position.z + orbitRadius * sin(angle)
            position = Vector3D(px, parentBody.position.y, pz)
            val vx = -orbitalSpeed * sin(angle)
            val vz = orbitalSpeed * cos(angle)
            velocity = Vector3D(vx, 0.0, vz)
        }
    }
}

object SolarSystem {

    // 0. The Central Star: Helios
    val STAR_HELIOS = CelestialBody(
        name = "Helios",
        radius = 1_800_000.0, // 1,800 km scaled stellar core
        mass = 8.5e25,
        atmosphereHeight = 250_000.0,
        atmosphereScaleHeight = 35_000.0,
        seaLevelDensity = 0.05,
        surfaceColorHex = 0xFFFFD54F,
        atmosphereColorHex = 0xFFFF7043,
        rotationSpeedRadPerSec = 0.00002,
        position = Vector3D(-16_000_000.0, 0.0, 0.0), // Star position relative to Novaria system
        velocity = Vector3D.ZERO,
        sphereOfInfluenceRadius = 80_000_000.0,
        description = "A brilliant G-class star radiating heat and solar power across the planetary system."
    )

    // 1. Home Planet: Novaria
    val PLANET_NOVARIA = CelestialBody(
        name = "Novaria",
        radius = 260_000.0, // 260 km radius
        mass = 1.95e22, // Sea level g ~ 9.81 m/s^2
        atmosphereHeight = 72_000.0, // 72 km
        atmosphereScaleHeight = 7200.0,
        seaLevelDensity = 1.225,
        surfaceColorHex = 0xFF1E88E5,
        atmosphereColorHex = 0xFF81D4FA,
        rotationSpeedRadPerSec = 0.00015,
        position = Vector3D.ZERO,
        velocity = Vector3D.ZERO,
        sphereOfInfluenceRadius = 1_850_000.0,
        terrainType = TerrainType.OCEAN_CONTINENT,
        description = "The cradle of aerospace exploration. Featuring vast blue oceans, temperate continents, and a welcoming nitrogen-oxygen atmosphere."
    )

    // 2. Moon of Novaria: Lunara
    val MOON_LUNARA = CelestialBody(
        name = "Lunara",
        radius = 70_000.0, // 70 km radius
        mass = 1.18e20, // Surface gravity ~ 1.62 m/s^2
        atmosphereHeight = 0.0, // Vacuum
        surfaceColorHex = 0xFFB0BEC5,
        atmosphereColorHex = 0x00000000,
        parentBody = PLANET_NOVARIA,
        orbitRadius = 1_350_000.0, // 1350 km orbit
        orbitalSpeed = sqrt((GRAVITATIONAL_CONSTANT * 1.95e22) / 1_350_000.0), // ~ 981 m/s
        position = Vector3D(1_350_000.0, 0.0, 0.0),
        velocity = Vector3D(0.0, 0.0, sqrt((GRAVITATIONAL_CONSTANT * 1.95e22) / 1_350_000.0)),
        sphereOfInfluenceRadius = 165_000.0,
        terrainType = TerrainType.CRATERED_VACUUM,
        description = "Novaria's silvery companion, pocked with ancient impact craters and ancient basaltic maria. Prime destination for lunar landings."
    )

    // 3. Inner Scorched Planet: Pyros
    val PLANET_PYROS = CelestialBody(
        name = "Pyros",
        radius = 190_000.0,
        mass = 1.35e22,
        atmosphereHeight = 36_000.0,
        atmosphereScaleHeight = 4500.0,
        seaLevelDensity = 0.42,
        surfaceColorHex = 0xFFE65100, // Rust orange & volcanic basalt
        atmosphereColorHex = 0xFFFFB74D,
        rotationSpeedRadPerSec = 0.00009,
        parentBody = null,
        orbitRadius = 7_200_000.0,
        orbitalSpeed = 1250.0,
        position = Vector3D(-7_200_000.0, 0.0, 4_500_000.0),
        velocity = Vector3D(-800.0, 0.0, -960.0),
        sphereOfInfluenceRadius = 1_200_000.0,
        terrainType = TerrainType.VOLCANIC_DESERT,
        description = "A scorching inner world of obsidian canyons and iron dust plains heated intensely by the central sun."
    )

    // Moon of Pyros: Astra
    val MOON_ASTRA = CelestialBody(
        name = "Astra",
        radius = 24_000.0,
        mass = 2.2e19,
        atmosphereHeight = 0.0,
        surfaceColorHex = 0xFF8D6E63,
        atmosphereColorHex = 0x00000000,
        parentBody = PLANET_PYROS,
        orbitRadius = 450_000.0,
        orbitalSpeed = 447.0,
        position = Vector3D(-7_200_000.0 + 450_000.0, 0.0, 4_500_000.0),
        velocity = Vector3D(0.0, 0.0, 447.0),
        sphereOfInfluenceRadius = 55_000.0,
        terrainType = TerrainType.CRATERED_VACUUM,
        description = "A captured carbonaceous asteroid orbiting Pyros, jagged and rich in heavy industrial minerals."
    )

    // 4. Outer Ringed Planet: Aeris
    val PLANET_AERIS = CelestialBody(
        name = "Aeris",
        radius = 420_000.0, // Gas giant-like ringed world
        mass = 6.8e22,
        atmosphereHeight = 115_000.0,
        atmosphereScaleHeight = 11_000.0,
        seaLevelDensity = 2.45,
        surfaceColorHex = 0xFF00838F, // Teal / Cyan storm clouds
        atmosphereColorHex = 0xFF4DD0E1,
        rotationSpeedRadPerSec = 0.00028,
        parentBody = null,
        orbitRadius = 14_800_000.0,
        orbitalSpeed = 820.0,
        position = Vector3D(14_800_000.0, 0.0, -6_200_000.0),
        velocity = Vector3D(340.0, 0.0, 745.0),
        sphereOfInfluenceRadius = 3_200_000.0,
        terrainType = TerrainType.GAS_GIANT_RINGS,
        hasRings = true,
        ringInnerRadius = 600_000.0,
        ringOuterRadius = 1_100_000.0,
        description = "A majestic azure world encircled by brilliant icy planetary rings and swirling storm systems."
    )

    // Moon of Aeris: Boreas
    val MOON_BOREAS = CelestialBody(
        name = "Boreas",
        radius = 78_000.0,
        mass = 1.45e20,
        atmosphereHeight = 14_000.0,
        atmosphereScaleHeight = 3200.0,
        seaLevelDensity = 0.12,
        surfaceColorHex = 0xFFECEFF1,
        atmosphereColorHex = 0xFFB2EBF2,
        parentBody = PLANET_AERIS,
        orbitRadius = 1_750_000.0,
        orbitalSpeed = 508.0,
        position = Vector3D(14_800_000.0 + 1_750_000.0, 0.0, -6_200_000.0),
        velocity = Vector3D(0.0, 0.0, 508.0),
        sphereOfInfluenceRadius = 190_000.0,
        terrainType = TerrainType.GLACIAL_ICE,
        description = "The largest moon of Aeris. Features cryogenic geysers and vast frozen methane plains."
    )

    // 5. Deep Outer Frozen Planet: Glacies
    val PLANET_GLACIES = CelestialBody(
        name = "Glacies",
        radius = 210_000.0,
        mass = 1.62e22,
        atmosphereHeight = 42_000.0,
        atmosphereScaleHeight = 5200.0,
        seaLevelDensity = 0.58,
        surfaceColorHex = 0xFF5C6BC0, // Deep indigo ice
        atmosphereColorHex = 0xFF9FA8DA,
        rotationSpeedRadPerSec = 0.00011,
        parentBody = null,
        orbitRadius = 24_500_000.0,
        orbitalSpeed = 620.0,
        position = Vector3D(0.0, 0.0, 24_500_000.0),
        velocity = Vector3D(-620.0, 0.0, 0.0),
        sphereOfInfluenceRadius = 1_900_000.0,
        terrainType = TerrainType.GLACIAL_ICE,
        description = "A mysterious frozen frontier world at the system's edge with crystalline mountain ranges."
    )

    // Moon of Glacies: Nix
    val MOON_NIX = CelestialBody(
        name = "Nix",
        radius = 35_000.0,
        mass = 3.8e19,
        atmosphereHeight = 0.0,
        surfaceColorHex = 0xFFE0E0E0,
        atmosphereColorHex = 0x00000000,
        parentBody = PLANET_GLACIES,
        orbitRadius = 620_000.0,
        orbitalSpeed = 417.0,
        position = Vector3D(620_000.0, 0.0, 24_500_000.0),
        velocity = Vector3D(0.0, 0.0, 417.0),
        sphereOfInfluenceRadius = 75_000.0,
        terrainType = TerrainType.CRATERED_VACUUM,
        description = "An ultra-reflective frozen ball of nitrogen ice in synchronous orbit around Glacies."
    )

    val allBodies: List<CelestialBody> = listOf(
        PLANET_NOVARIA,
        MOON_LUNARA,
        PLANET_PYROS,
        MOON_ASTRA,
        PLANET_AERIS,
        MOON_BOREAS,
        PLANET_GLACIES,
        MOON_NIX,
        STAR_HELIOS
    )

    /**
     * Determines which celestial body exerts primary gravitational dominance (Sphere of Influence).
     */
    fun determinePrimaryBody(shipPos: Vector3D): CelestialBody {
        // Check moons first (nested SOIs)
        val moons = listOf(MOON_LUNARA, MOON_ASTRA, MOON_BOREAS, MOON_NIX)
        for (moon in moons) {
            if (shipPos.distanceTo(moon.position) < moon.sphereOfInfluenceRadius) {
                return moon
            }
        }

        // Check major planets
        val planets = listOf(PLANET_NOVARIA, PLANET_PYROS, PLANET_AERIS, PLANET_GLACIES)
        for (planet in planets) {
            if (shipPos.distanceTo(planet.position) < planet.sphereOfInfluenceRadius) {
                return planet
            }
        }

        // Check if inside star SOI or deep interplanetary space
        if (shipPos.distanceTo(STAR_HELIOS.position) < STAR_HELIOS.sphereOfInfluenceRadius) {
            return STAR_HELIOS
        }

        return PLANET_NOVARIA
    }

    /**
     * Advances planetary and lunar orbital mechanics smoothly.
     */
    fun updateAllOrbits(gameTimeSec: Double) {
        MOON_LUNARA.updateOrbit(gameTimeSec)
        MOON_ASTRA.updateOrbit(gameTimeSec)
        MOON_BOREAS.updateOrbit(gameTimeSec)
        MOON_NIX.updateOrbit(gameTimeSec)
    }
}
