package com.example.cosmic.ui

import android.annotation.SuppressLint
import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.example.cosmic.renderer.CosmicGLRenderer
import kotlin.math.abs

@SuppressLint("ClickableViewAccessibility")
@Composable
fun CosmicGLView(
    renderer: CosmicGLRenderer,
    modifier: Modifier = Modifier,
    onTouchSteer: ((pitch: Float, yaw: Float) -> Unit)? = null
) {
    AndroidView(
        factory = { context ->
            CosmicTouchGLSurfaceView(context, renderer, onTouchSteer)
        },
        modifier = modifier
    )
}

@SuppressLint("ViewConstructor")
class CosmicTouchGLSurfaceView(
    context: Context,
    private val renderer: CosmicGLRenderer,
    private val onTouchSteer: ((pitch: Float, yaw: Float) -> Unit)?
) : GLSurfaceView(context) {

    private var previousX = 0f
    private var previousY = 0f

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val factor = detector.scaleFactor
                if (abs(factor - 1.0f) > 0.005f) {
                    renderer.camera.onZoom(factor)
                }
                return true
            }
        }
    )

    init {
        setEGLContextClientVersion(2)
        setRenderer(renderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)

        if (event.pointerCount > 1) {
            return true
        }

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                previousX = event.x
                previousY = event.y
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - previousX
                val dy = event.y - previousY

                // Camera orbit drag
                renderer.camera.onDrag(dx, dy)

                previousX = event.x
                previousY = event.y
            }
        }
        return true
    }
}
