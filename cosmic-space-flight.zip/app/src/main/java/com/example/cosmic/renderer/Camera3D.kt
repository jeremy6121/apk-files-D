package com.example.cosmic.renderer

import android.opengl.Matrix
import com.example.cosmic.math.Vector3D
import kotlin.math.*

enum class CameraMode {
    BUILDER,
    FLIGHT_FOLLOW,
    ORBIT_MAP
}

class Camera3D {
    var mode: CameraMode = CameraMode.BUILDER
    var targetPosition: Vector3D = Vector3D.ZERO

    var yawDeg: Float = 45f
    var pitchDeg: Float = 20f
    var distance: Float = 14f

    var minDistance: Float = 4f
    var maxDistance: Float = 60f

    val viewMatrix = FloatArray(16)
    val projectionMatrix = FloatArray(16)
    val viewProjectionMatrix = FloatArray(16)

    var eyeX = 0f
    var eyeY = 0f
    var eyeZ = 0f

    fun setModePreset(newMode: CameraMode) {
        mode = newMode
        when (newMode) {
            CameraMode.BUILDER -> {
                minDistance = 3f
                maxDistance = 35f
                distance = 12f
                pitchDeg = 15f
                yawDeg = 45f
            }
            CameraMode.FLIGHT_FOLLOW -> {
                minDistance = 6f
                maxDistance = 150f
                distance = 18f
                pitchDeg = 20f
                yawDeg = 30f
            }
            CameraMode.ORBIT_MAP -> {
                minDistance = 200f
                maxDistance = 8000f
                distance = 1200f
                pitchDeg = 85f // Top-down orbital map projection
                yawDeg = 0f
            }
        }
    }

    fun onDrag(deltaX: Float, deltaY: Float) {
        val sensitivity = 0.35f
        yawDeg = (yawDeg - deltaX * sensitivity) % 360f
        pitchDeg = (pitchDeg + deltaY * sensitivity).coerceIn(-89f, 89f)
    }

    fun onZoom(scaleFactor: Float) {
        distance = (distance / scaleFactor).coerceIn(minDistance, maxDistance)
    }

    fun updateMatrices(aspectRatio: Float) {
        // Compute eye position relative to target
        val pitchRad = Math.toRadians(pitchDeg.toDouble())
        val yawRad = Math.toRadians(yawDeg.toDouble())

        val cosPitch = cos(pitchRad)
        val relX = (distance * sin(yawRad) * cosPitch).toFloat()
        val relY = (distance * sin(pitchRad)).toFloat()
        val relZ = (distance * cos(yawRad) * cosPitch).toFloat()

        eyeX = targetPosition.x.toFloat() + relX
        eyeY = targetPosition.y.toFloat() + relY
        eyeZ = targetPosition.z.toFloat() + relZ

        val targetX = targetPosition.x.toFloat()
        val targetY = targetPosition.y.toFloat()
        val targetZ = targetPosition.z.toFloat()

        // Up vector: handle near-vertical pitch
        val upY = if (abs(pitchDeg) > 85f) 0f else 1f
        val upZ = if (abs(pitchDeg) > 85f) -1f else 0f

        Matrix.setLookAtM(
            viewMatrix, 0,
            eyeX, eyeY, eyeZ,
            targetX, targetY, targetZ,
            0f, upY, upZ
        )

        val near = if (mode == CameraMode.ORBIT_MAP) 10f else 0.2f
        val far = if (mode == CameraMode.ORBIT_MAP) 20000f else 1000f
        Matrix.perspectiveM(projectionMatrix, 0, 50f, aspectRatio, near, far)

        Matrix.multiplyMM(viewProjectionMatrix, 0, projectionMatrix, 0, viewMatrix, 0)
    }
}
