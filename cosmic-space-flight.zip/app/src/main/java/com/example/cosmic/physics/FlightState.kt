package com.example.cosmic.physics

import com.example.cosmic.math.Vector3D
import com.example.cosmic.model.PartCategory
import com.example.cosmic.model.PlacedPart
import com.example.cosmic.model.RocketDesign
import kotlin.math.*

enum class FlightStatus(val label: String) {
    PRE_LAUNCH("Pre-Launch Pad"),
    COUNTDOWN("Countdown"),
    ASCENT("Atmospheric Ascent"),
    SPACE("Space Flight"),
    ORBIT("Stable Orbit"),
    REENTRY("Atmospheric Re-entry"),
    LANDED("Touchdown Successful"),
    CRASHED("Vehicle Destroyed")
}

enum class SasMode(val title: String) {
    OFF("OFF"),
    STABILITY("SAS"),
    PROGRADE("PROGRADE"),
    RETROGRADE("RETROGRADE")
}

data class DecoupledDebris(
    val parts: List<PlacedPart>,
    var position: Vector3D,
    var velocity: Vector3D,
    var angularVelocity: Vector3D,
    var rotation: Float = 0f
)

data class FlightState(
    var rocket: RocketDesign,
    var position: Vector3D = Vector3D.ZERO, // World coordinates (Novaria center at 0,0,0)
    var velocity: Vector3D = Vector3D.ZERO,
    var attitudeVector: Vector3D = Vector3D.UP, // Unit vector pointing in rocket nose direction
    var pitchAngleDeg: Double = 90.0, // 90 = vertical up from local surface
    var headingAngleDeg: Double = 90.0, // 90 = East (orbital direction)
    var rollAngleDeg: Double = 0.0,
    var angularPitchRate: Double = 0.0,
    var angularYawRate: Double = 0.0,
    var throttle: Float = 0.0f,
    var activeStage: Int = 0,
    var status: FlightStatus = FlightStatus.PRE_LAUNCH,
    var sasMode: SasMode = SasMode.STABILITY,
    var timeWarp: Int = 1,
    var metSeconds: Double = 0.0,
    var gForce: Double = 1.0,
    var reentryHeat: Float = 0.0f,
    var dynamicPressure: Double = 0.0,
    var landingGearDeployed: Boolean = false,
    var parachuteDeployed: Boolean = false,
    var batteryCharge: Float = 100f, // 0 to 100%
    var solarPowerGenerating: Boolean = false,
    var countdownRemaining: Float = 3.0f,
    var primaryBody: CelestialBody = SolarSystem.PLANET_NOVARIA,
    var targetBody: CelestialBody? = null,
    val assignedCrewIds: MutableList<String> = mutableListOf(),
    var isDockingAligned: Boolean = false,
    var dockingTargetName: String? = null,
    var dockingDistanceMeters: Double? = null,
    val debrisList: MutableList<DecoupledDebris> = mutableListOf()
) {
    val altitude: Double
        get() = (position - primaryBody.position).length() - primaryBody.radius

    val radarAltitude: Double
        get() = altitude.coerceAtLeast(0.0)

    val speed: Double
        get() = velocity.length()

    val surfaceVelocity: Vector3D
        get() {
            val rVec = position - primaryBody.position
            val rotVel = Vector3D(
                -primaryBody.rotationSpeedRadPerSec * rVec.z,
                0.0,
                primaryBody.rotationSpeedRadPerSec * rVec.x
            )
            return velocity - rotVel
        }

    val surfaceSpeed: Double
        get() = surfaceVelocity.length()

    val verticalSpeed: Double
        get() {
            val rVec = (position - primaryBody.position).normalized()
            return surfaceVelocity.dot(rVec)
        }

    val horizontalSpeed: Double
        get() {
            val vVert = verticalSpeed
            val vTot = surfaceSpeed
            return sqrt((vTot * vTot - vVert * vVert).coerceAtLeast(0.0))
        }

    val totalFuelPercentage: Float
        get() {
            val activeTanks = rocket.parts.filter { !it.isDecoupled && (it.type.category == PartCategory.FUEL || it.type.fuelCapacity > 0) }
            if (activeTanks.isEmpty()) return 0f
            val maxFuel = activeTanks.sumOf { it.type.fuelCapacity }
            if (maxFuel <= 0) return 0f
            val currentFuel = activeTanks.sumOf { it.fuelRemaining }
            return ((currentFuel / maxFuel) * 100.0).toFloat().coerceIn(0f, 100f)
        }

    val currentStageFuelPercentage: Float
        get() {
            val stageTanks = rocket.parts.filter { !it.isDecoupled && it.stageIndex == activeStage && (it.type.category == PartCategory.FUEL || it.type.fuelCapacity > 0) }
            if (stageTanks.isEmpty()) return totalFuelPercentage
            val maxFuel = stageTanks.sumOf { it.type.fuelCapacity }
            if (maxFuel <= 0) return 0f
            val currentFuel = stageTanks.sumOf { it.fuelRemaining }
            return ((currentFuel / maxFuel) * 100.0).toFloat().coerceIn(0f, 100f)
        }

    val isRecoverable: Boolean
        get() = status == FlightStatus.LANDED && primaryBody == SolarSystem.PLANET_NOVARIA

    /**
     * Calculates credit refund when landing safely and recovering on home planet Novaria.
     * Intact parts refund up to 85% original cost, and remaining fuel refunds up to 75%.
     */
    fun calculateRecoveryRefund(): Int {
        if (!isRecoverable) return 0
        var refund = 0
        val intactParts = rocket.parts.filter { !it.isDecoupled }
        for (part in intactParts) {
            refund += (part.type.cost * 0.85).toInt()
            if (part.type.fuelCapacity > 0 && part.fuelRemaining > 0) {
                val fuelRatio = part.fuelRemaining / part.type.fuelCapacity
                refund += (part.type.cost * 0.15 * fuelRatio).toInt()
            }
        }
        return refund.coerceAtLeast(100)
    }

    val solarPowerGeneratedKw: Double
        get() {
            val solarCount = rocket.parts.count { !it.isDecoupled && it.isDeployed && it.type == com.example.cosmic.model.PartType.SOLAR_PANEL }
            return if (solarPowerGenerating) solarCount * 4.5 else 0.0
        }

    val batteryChargePercent: Float
        get() = batteryCharge
}
