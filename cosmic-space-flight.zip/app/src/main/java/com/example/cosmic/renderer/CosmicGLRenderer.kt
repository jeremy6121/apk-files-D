package com.example.cosmic.renderer

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import com.example.cosmic.math.Vector3D
import com.example.cosmic.model.*
import com.example.cosmic.physics.CelestialBody
import com.example.cosmic.physics.FlightState
import com.example.cosmic.physics.FlightStatus
import com.example.cosmic.physics.OrbitalMath
import com.example.cosmic.physics.SolarSystem
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.Random
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*

class CosmicGLRenderer : GLSurfaceView.Renderer {

    val camera = Camera3D()
    val particles = ParticleSystem(450)

    // Active state references (thread-safe copy or atomic reference)
    var currentRocket: RocketDesign = StockRockets.createCosmos1()
    var selectedPartId: String? = null
    var flightState: FlightState? = null
    var isOrbitMapView: Boolean = false
    var fleetManager: FleetManager? = null

    private var surfaceWidth = 1080
    private var surfaceHeight = 1920
    private var aspectRatio = 1f

    // Shader program handles
    private var meshProgram = 0
    private var planetProgram = 0
    private var particleProgram = 0
    private var lineProgram = 0

    // Mesh uniform and attribute locations
    private var uMVPLoc = 0
    private var uModelLoc = 0
    private var uLightDirLoc = 0
    private var uColorLoc = 0
    private var uAmbientLoc = 0
    private var uFogColorLoc = 0
    private var uFogDensityLoc = 0
    private var aPosLoc = 0
    private var aNormLoc = 0

    // Planet uniform locations
    private var uPlanetMVPLoc = 0
    private var uPlanetModelLoc = 0
    private var uPlanetLightDirLoc = 0
    private var uPlanetCameraPosLoc = 0
    private var uPlanetSurfaceColorLoc = 0
    private var uPlanetAtmosphereColorLoc = 0
    private var uPlanetHasAtmoLoc = 0
    private var aPlanetPosLoc = 0
    private var aPlanetNormLoc = 0

    // Particle locations
    private var uPartMVPLoc = 0
    private var aPartPosLoc = 0
    private var aPartColorLoc = 0
    private var aPartSizeLoc = 0

    // Line locations
    private var uLineMVPLoc = 0
    private var uLineColorLoc = 0
    private var aLinePosLoc = 0

    // Meshes
    private lateinit var cylinderMesh: GLMesh
    private lateinit var coneMesh: GLMesh
    private lateinit var truncatedConeMesh: GLMesh
    private lateinit var boxMesh: GLMesh
    private lateinit var finMesh: GLMesh
    private lateinit var landingLegMesh: GLMesh
    private lateinit var panelMesh: GLMesh
    private lateinit var rcsMesh: GLMesh
    private lateinit var trussMesh: GLMesh
    private lateinit var parachuteCanopyMesh: GLMesh
    private lateinit var sphereMesh: GLMesh
    private lateinit var planetSphereMesh: GLMesh
    private lateinit var aerisRingMesh: GLMesh
    private lateinit var starfieldBuffer: FloatBuffer
    private var starCount = 300

    private val modelMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)
    private val tempMatrix = FloatArray(16)

    // Sun directional light vector
    private val sunLightDir = floatArrayOf(0.8f, 0.4f, 0.5f)

    private var trajectoryPoints: List<Vector3D> = emptyList()
    private var trajectoryFloatBuffer: FloatBuffer? = null

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glEnable(GLES20.GL_CULL_FACE)
        GLES20.glCullFace(GLES20.GL_BACK)

        initShaders()
        initMeshes()
        initStarfield()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        surfaceWidth = width
        surfaceHeight = height
        aspectRatio = width.toFloat() / height.toFloat().coerceAtLeast(1f)
        GLES20.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        val flight = flightState

        if (flight != null) {
            renderFlightScene(flight)
        } else {
            renderBuilderScene()
        }
    }

    private fun initShaders() {
        meshProgram = ShaderPrograms.createProgram(ShaderPrograms.MESH_VERTEX_SHADER, ShaderPrograms.MESH_FRAGMENT_SHADER)
        uMVPLoc = GLES20.glGetUniformLocation(meshProgram, "uMVPMatrix")
        uModelLoc = GLES20.glGetUniformLocation(meshProgram, "uModelMatrix")
        uLightDirLoc = GLES20.glGetUniformLocation(meshProgram, "uLightDir")
        uColorLoc = GLES20.glGetUniformLocation(meshProgram, "uColor")
        uAmbientLoc = GLES20.glGetUniformLocation(meshProgram, "uAmbientColor")
        uFogColorLoc = GLES20.glGetUniformLocation(meshProgram, "uFogColor")
        uFogDensityLoc = GLES20.glGetUniformLocation(meshProgram, "uFogDensity")
        aPosLoc = GLES20.glGetAttribLocation(meshProgram, "aPosition")
        aNormLoc = GLES20.glGetAttribLocation(meshProgram, "aNormal")

        planetProgram = ShaderPrograms.createProgram(ShaderPrograms.PLANET_VERTEX_SHADER, ShaderPrograms.PLANET_FRAGMENT_SHADER)
        uPlanetMVPLoc = GLES20.glGetUniformLocation(planetProgram, "uMVPMatrix")
        uPlanetModelLoc = GLES20.glGetUniformLocation(planetProgram, "uModelMatrix")
        uPlanetLightDirLoc = GLES20.glGetUniformLocation(planetProgram, "uLightDir")
        uPlanetCameraPosLoc = GLES20.glGetUniformLocation(planetProgram, "uCameraPos")
        uPlanetSurfaceColorLoc = GLES20.glGetUniformLocation(planetProgram, "uSurfaceColor")
        uPlanetAtmosphereColorLoc = GLES20.glGetUniformLocation(planetProgram, "uAtmosphereColor")
        uPlanetHasAtmoLoc = GLES20.glGetUniformLocation(planetProgram, "uHasAtmosphere")
        aPlanetPosLoc = GLES20.glGetAttribLocation(planetProgram, "aPosition")
        aPlanetNormLoc = GLES20.glGetAttribLocation(planetProgram, "aNormal")

        particleProgram = ShaderPrograms.createProgram(ShaderPrograms.PARTICLE_VERTEX_SHADER, ShaderPrograms.PARTICLE_FRAGMENT_SHADER)
        uPartMVPLoc = GLES20.glGetUniformLocation(particleProgram, "uMVPMatrix")
        aPartPosLoc = GLES20.glGetAttribLocation(particleProgram, "aPosition")
        aPartColorLoc = GLES20.glGetAttribLocation(particleProgram, "aColor")
        aPartSizeLoc = GLES20.glGetAttribLocation(particleProgram, "aSize")

        lineProgram = ShaderPrograms.createProgram(ShaderPrograms.LINE_VERTEX_SHADER, ShaderPrograms.LINE_FRAGMENT_SHADER)
        uLineMVPLoc = GLES20.glGetUniformLocation(lineProgram, "uMVPMatrix")
        uLineColorLoc = GLES20.glGetUniformLocation(lineProgram, "uLineColor")
        aLinePosLoc = GLES20.glGetAttribLocation(lineProgram, "aPosition")
    }

    private fun initMeshes() {
        cylinderMesh = MeshFactory.createCylinder(0.8f, 1.0f, 18)
        coneMesh = MeshFactory.createCone(0.8f, 0.0f, 1.4f, 18)
        truncatedConeMesh = MeshFactory.createCone(0.8f, 0.45f, 1.2f, 18)
        boxMesh = MeshFactory.createBox(1.0f, 1.0f, 1.0f)
        finMesh = MeshFactory.createFin(1.0f, 1.2f, 0.5f, 0.08f)
        landingLegMesh = MeshFactory.createBox(0.12f, 1.4f, 0.12f)
        panelMesh = MeshFactory.createPanel(1.0f, 1.0f, 0.04f)
        rcsMesh = MeshFactory.createRcsBlock(0.3f)
        trussMesh = MeshFactory.createTruss(1.0f, 1.0f, 1.0f)
        parachuteCanopyMesh = MeshFactory.createParachuteCanopy(2.2f)
        sphereMesh = MeshFactory.createSphere(1.0f, 16, 16)
        planetSphereMesh = MeshFactory.createSphere(1.0f, 32, 32)
        aerisRingMesh = MeshFactory.createPlanetaryRings(1.35f, 2.6f, 48)
    }

    private fun initStarfield() {
        val rand = Random(42)
        starCount = 350
        val stars = FloatArray(starCount * 3)
        val skyRadius = 500f
        for (i in 0 until starCount) {
            val u = rand.nextFloat()
            val v = rand.nextFloat()
            val theta = 2.0 * Math.PI * u
            val phi = acos(2.0 * v - 1.0)
            stars[i * 3] = (skyRadius * sin(phi) * cos(theta)).toFloat()
            stars[i * 3 + 1] = (skyRadius * sin(phi) * sin(theta)).toFloat()
            stars[i * 3 + 2] = (skyRadius * cos(phi)).toFloat()
        }
        starfieldBuffer = ByteBuffer.allocateDirect(stars.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
                put(stars)
                position(0)
            }
    }

    // --- RENDER VEHICLE ASSEMBLY BUILDING (BUILDER) ---
    private fun renderBuilderScene() {
        GLES20.glClearColor(0.08f, 0.10f, 0.14f, 1.0f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        camera.targetPosition = Vector3D(0.0, 1.5, 0.0) // Center on rocket vertical span
        camera.updateMatrices(aspectRatio)

        GLES20.glUseProgram(meshProgram)
        GLES20.glUniform3fv(uLightDirLoc, 1, sunLightDir, 0)
        GLES20.glUniform3f(uAmbientLoc, 0.45f, 0.48f, 0.55f)
        GLES20.glUniform4f(uFogColorLoc, 0.08f, 0.10f, 0.14f, 1f)
        GLES20.glUniform1f(uFogDensityLoc, 0f)

        // Draw Hangar Launch Pedestal Base
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, 0f, -4.5f, 0f)
        Matrix.scaleM(modelMatrix, 0, 8f, 0.4f, 8f)
        Matrix.multiplyMM(mvpMatrix, 0, camera.viewProjectionMatrix, 0, modelMatrix, 0)
        GLES20.glUniformMatrix4fv(uMVPLoc, 1, false, mvpMatrix, 0)
        GLES20.glUniformMatrix4fv(uModelLoc, 1, false, modelMatrix, 0)
        GLES20.glUniform4f(uColorLoc, 0.22f, 0.25f, 0.30f, 1.0f)
        boxMesh.draw(aPosLoc, aNormLoc)

        // Draw Launch Pad Rail Tower
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, 3.2f, 2.0f, 0f)
        Matrix.scaleM(modelMatrix, 0, 0.5f, 13f, 0.5f)
        Matrix.multiplyMM(mvpMatrix, 0, camera.viewProjectionMatrix, 0, modelMatrix, 0)
        GLES20.glUniformMatrix4fv(uMVPLoc, 1, false, mvpMatrix, 0)
        GLES20.glUniformMatrix4fv(uModelLoc, 1, false, modelMatrix, 0)
        GLES20.glUniform4f(uColorLoc, 0.85f, 0.35f, 0.15f, 1.0f)
        boxMesh.draw(aPosLoc, aNormLoc)

        // Draw Rocket Parts
        drawRocketParts(currentRocket, selectedPartId, 1.0f)
    }

    // --- RENDER 3D FLIGHT SIMULATION SCENE ---
    private fun renderFlightScene(flight: FlightState) {
        val primary = flight.primaryBody
        val altitude = flight.altitude

        // Calculate atmospheric background color
        val atmoFraction = (1.0 - (altitude / primary.atmosphereHeight)).coerceIn(0.0, 1.0).toFloat()
        val skyR = 0.02f + 0.20f * atmoFraction
        val skyG = 0.04f + 0.45f * atmoFraction
        val skyB = 0.10f + 0.75f * atmoFraction

        GLES20.glClearColor(skyR, skyG, skyB, 1.0f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        if (isOrbitMapView) {
            camera.mode = CameraMode.ORBIT_MAP
            // Target halfway between planet and rocket
            camera.targetPosition = Vector3D.ZERO
            camera.updateMatrices(aspectRatio)
            renderOrbitMapScene(flight)
            return
        } else {
            camera.mode = CameraMode.FLIGHT_FOLLOW
            camera.targetPosition = flight.position
            camera.updateMatrices(aspectRatio)
        }

        // Render Starfield in space
        if (atmoFraction < 0.85f) {
            renderStarfield(1f - atmoFraction)
        }

        // Render Planet Novaria & Moon Lunara
        renderCelestialBodies(flight)

        // Render Launch Pad if near surface
        if (altitude < 3500.0 && flight.primaryBody == SolarSystem.PLANET_NOVARIA) {
            renderSurfaceLaunchPad(flight)
        }

        // Render Active Rocket
        renderFlightRocket(flight)

        // Render Decoupled Debris Stages
        renderDebris(flight)

        // Particle System update & render (Exhaust & Re-entry Plasma)
        updateAndRenderParticles(flight)
    }

    private fun renderStarfield(alpha: Float) {
        if (alpha <= 0.01f) return
        GLES20.glUseProgram(lineProgram)
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, camera.eyeX, camera.eyeY, camera.eyeZ)
        Matrix.multiplyMM(mvpMatrix, 0, camera.viewProjectionMatrix, 0, modelMatrix, 0)

        GLES20.glUniformMatrix4fv(uLineMVPLoc, 1, false, mvpMatrix, 0)
        GLES20.glUniform4f(uLineColorLoc, 1.0f, 1.0f, 1.0f, alpha)

        starfieldBuffer.position(0)
        GLES20.glVertexAttribPointer(aLinePosLoc, 3, GLES20.GL_FLOAT, false, 0, starfieldBuffer)
        GLES20.glEnableVertexAttribArray(aLinePosLoc)
        GLES20.glDrawArrays(GLES20.GL_POINTS, 0, starCount)
        GLES20.glDisableVertexAttribArray(aLinePosLoc)
    }

    private fun renderCelestialBodies(flight: FlightState) {
        val bodies = SolarSystem.allBodies

        GLES20.glUseProgram(planetProgram)
        GLES20.glUniform3fv(uPlanetLightDirLoc, 1, sunLightDir, 0)
        GLES20.glUniform3f(uPlanetCameraPosLoc, camera.eyeX, camera.eyeY, camera.eyeZ)

        for (body in bodies) {
            val relPos = body.position
            val visualRadius = body.radius.toFloat()

            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.translateM(modelMatrix, 0, relPos.x.toFloat(), relPos.y.toFloat(), relPos.z.toFloat())
            Matrix.scaleM(modelMatrix, 0, visualRadius, visualRadius, visualRadius)
            Matrix.multiplyMM(mvpMatrix, 0, camera.viewProjectionMatrix, 0, modelMatrix, 0)

            GLES20.glUniformMatrix4fv(uPlanetMVPLoc, 1, false, mvpMatrix, 0)
            GLES20.glUniformMatrix4fv(uPlanetModelLoc, 1, false, modelMatrix, 0)

            val hasAtmo = if (body.atmosphereHeight > 0) 1.0f else 0.0f
            GLES20.glUniform1f(uPlanetHasAtmoLoc, hasAtmo)

            val sColor = body.colorRgba
            val aColor = body.atmosphereColorRgba
            GLES20.glUniform4f(uPlanetSurfaceColorLoc, sColor[0], sColor[1], sColor[2], sColor[3])
            GLES20.glUniform4f(uPlanetAtmosphereColorLoc, aColor[0], aColor[1], aColor[2], aColor[3])

            planetSphereMesh.draw(aPlanetPosLoc, aPlanetNormLoc)

            // Render rings around Aeris
            if (body == SolarSystem.PLANET_AERIS) {
                GLES20.glUseProgram(meshProgram)
                Matrix.setIdentityM(modelMatrix, 0)
                Matrix.translateM(modelMatrix, 0, relPos.x.toFloat(), relPos.y.toFloat(), relPos.z.toFloat())
                Matrix.scaleM(modelMatrix, 0, visualRadius, visualRadius, visualRadius)
                Matrix.multiplyMM(mvpMatrix, 0, camera.viewProjectionMatrix, 0, modelMatrix, 0)
                GLES20.glUniformMatrix4fv(uMVPLoc, 1, false, mvpMatrix, 0)
                GLES20.glUniformMatrix4fv(uModelLoc, 1, false, modelMatrix, 0)
                GLES20.glUniform4f(uColorLoc, 0.65f, 0.85f, 0.95f, 0.75f)
                aerisRingMesh.draw(aPosLoc, aNormLoc)
                GLES20.glUseProgram(planetProgram)
            }
        }
    }

    private fun renderSurfaceLaunchPad(flight: FlightState) {
        val planet = SolarSystem.PLANET_NOVARIA
        val padPos = Vector3D(planet.radius, 0.0, 0.0)

        GLES20.glUseProgram(meshProgram)
        GLES20.glUniform3fv(uLightDirLoc, 1, sunLightDir, 0)
        GLES20.glUniform3f(uAmbientLoc, 0.4f, 0.4f, 0.45f)
        GLES20.glUniform1f(uFogDensityLoc, 0f)

        // Launch Platform
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, padPos.x.toFloat(), padPos.y.toFloat(), padPos.z.toFloat())
        Matrix.scaleM(modelMatrix, 0, 4f, 25f, 25f)
        Matrix.multiplyMM(mvpMatrix, 0, camera.viewProjectionMatrix, 0, modelMatrix, 0)
        GLES20.glUniformMatrix4fv(uMVPLoc, 1, false, mvpMatrix, 0)
        GLES20.glUniformMatrix4fv(uModelLoc, 1, false, modelMatrix, 0)
        GLES20.glUniform4f(uColorLoc, 0.35f, 0.38f, 0.42f, 1.0f)
        boxMesh.draw(aPosLoc, aNormLoc)

        // Gantry Tower
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, padPos.x.toFloat() + 15f, padPos.y.toFloat(), padPos.z.toFloat() + 12f)
        Matrix.scaleM(modelMatrix, 0, 30f, 3f, 3f)
        Matrix.multiplyMM(mvpMatrix, 0, camera.viewProjectionMatrix, 0, modelMatrix, 0)
        GLES20.glUniformMatrix4fv(uMVPLoc, 1, false, mvpMatrix, 0)
        GLES20.glUniformMatrix4fv(uModelLoc, 1, false, modelMatrix, 0)
        GLES20.glUniform4f(uColorLoc, 0.90f, 0.35f, 0.15f, 1.0f)
        boxMesh.draw(aPosLoc, aNormLoc)
    }

    private fun renderFlightRocket(flight: FlightState) {
        GLES20.glUseProgram(meshProgram)
        GLES20.glUniform3fv(uLightDirLoc, 1, sunLightDir, 0)
        GLES20.glUniform3f(uAmbientLoc, 0.35f, 0.38f, 0.42f)
        GLES20.glUniform1f(uFogDensityLoc, 0f)

        // Compute Rocket world orientation matrix
        val rocketPos = flight.position
        val attitude = flight.attitudeVector

        // Compute rotation from local up (0,1,0) to attitude vector
        val rotMatrix = FloatArray(16)
        computeRotationMatrix(attitude, rotMatrix)

        for (part in flight.rocket.parts) {
            if (part.isDecoupled) continue

            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.translateM(modelMatrix, 0, rocketPos.x.toFloat(), rocketPos.y.toFloat(), rocketPos.z.toFloat())
            Matrix.multiplyMM(tempMatrix, 0, modelMatrix, 0, rotMatrix, 0)

            // Part local offset
            Matrix.translateM(tempMatrix, 0, part.x, part.y, part.z)
            if (part.rotationYDeg != 0f) {
                Matrix.rotateM(tempMatrix, 0, part.rotationYDeg, 0f, 1f, 0f)
            }

            drawPartMesh(part, tempMatrix, 1.0f)
        }
    }

    private fun renderDebris(flight: FlightState) {
        GLES20.glUseProgram(meshProgram)
        for (debris in flight.debrisList) {
            val rotMatrix = FloatArray(16)
            Matrix.setIdentityM(rotMatrix, 0)
            Matrix.rotateM(rotMatrix, 0, debris.rotation, 1f, 0.5f, 0.2f)

            for (part in debris.parts) {
                Matrix.setIdentityM(modelMatrix, 0)
                Matrix.translateM(modelMatrix, 0, debris.position.x.toFloat(), debris.position.y.toFloat(), debris.position.z.toFloat())
                Matrix.multiplyMM(tempMatrix, 0, modelMatrix, 0, rotMatrix, 0)
                Matrix.translateM(tempMatrix, 0, part.x, part.y, part.z)
                drawPartMesh(part, tempMatrix, 0.85f)
            }
        }
    }

    private fun updateAndRenderParticles(flight: FlightState) {
        val dt = 0.016f

        // Emit engine flame particles if engines are active
        if (flight.throttle > 0.01f && flight.status != FlightStatus.CRASHED) {
            val activeEngines = flight.rocket.parts.filter {
                !it.isDecoupled && it.stageIndex == flight.activeStage && it.type.category == PartCategory.ENGINE
            }
            val hasFuel = flight.rocket.parts.any {
                !it.isDecoupled && it.stageIndex == flight.activeStage && it.type.category == PartCategory.FUEL && it.fuelRemaining > 0.01
            }

            if (activeEngines.isNotEmpty() && hasFuel) {
                for (eng in activeEngines) {
                    val nozzlePos = flight.position + flight.attitudeVector * (eng.y - eng.type.height)
                    val exhaustDir = -flight.attitudeVector
                    particles.emitEngineExhaust(nozzlePos, exhaustDir, flight.throttle, 5)
                }
            }
        }

        // Emit Re-entry Plasma if hypersonic in atmosphere
        if (flight.reentryHeat > 0.05f) {
            particles.emitReentryPlasma(flight.position, flight.velocity.normalized(), flight.reentryHeat)
        }

        // Emit crash explosion if crashed
        if (flight.status == FlightStatus.CRASHED) {
            particles.emitExplosion(flight.position)
        }

        particles.update(dt)

        // Render particles with additive blending
        GLES20.glUseProgram(particleProgram)
        GLES20.glUniformMatrix4fv(uPartMVPLoc, 1, false, camera.viewProjectionMatrix, 0)
        particles.render(aPartPosLoc, aPartColorLoc, aPartSizeLoc)
    }

    // --- RENDER ORBITAL MAP VIEW ---
    private fun renderOrbitMapScene(flight: FlightState) {
        val primary = flight.primaryBody

        // 1. Render all celestial bodies
        GLES20.glUseProgram(planetProgram)
        GLES20.glUniform3fv(uPlanetLightDirLoc, 1, sunLightDir, 0)
        GLES20.glUniform3f(uPlanetCameraPosLoc, camera.eyeX, camera.eyeY, camera.eyeZ)

        for (body in SolarSystem.allBodies) {
            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.translateM(modelMatrix, 0, body.position.x.toFloat(), body.position.y.toFloat(), body.position.z.toFloat())
            val mapRadius = body.radius.toFloat().coerceAtLeast(1200f)
            Matrix.scaleM(modelMatrix, 0, mapRadius, mapRadius, mapRadius)
            Matrix.multiplyMM(mvpMatrix, 0, camera.viewProjectionMatrix, 0, modelMatrix, 0)

            GLES20.glUniformMatrix4fv(uPlanetMVPLoc, 1, false, mvpMatrix, 0)
            GLES20.glUniformMatrix4fv(uPlanetModelLoc, 1, false, modelMatrix, 0)
            GLES20.glUniform1f(uPlanetHasAtmoLoc, if (body.atmosphereHeight > 0) 1f else 0f)

            val sColor = body.colorRgba
            val aColor = body.atmosphereColorRgba
            GLES20.glUniform4f(uPlanetSurfaceColorLoc, sColor[0], sColor[1], sColor[2], sColor[3])
            GLES20.glUniform4f(uPlanetAtmosphereColorLoc, aColor[0], aColor[1], aColor[2], aColor[3])
            planetSphereMesh.draw(aPlanetPosLoc, aPlanetNormLoc)

            if (body == SolarSystem.PLANET_AERIS) {
                GLES20.glUseProgram(meshProgram)
                Matrix.setIdentityM(modelMatrix, 0)
                Matrix.translateM(modelMatrix, 0, body.position.x.toFloat(), body.position.y.toFloat(), body.position.z.toFloat())
                Matrix.scaleM(modelMatrix, 0, mapRadius * 1.5f, mapRadius * 1.5f, mapRadius * 1.5f)
                Matrix.multiplyMM(mvpMatrix, 0, camera.viewProjectionMatrix, 0, modelMatrix, 0)
                GLES20.glUniformMatrix4fv(uMVPLoc, 1, false, mvpMatrix, 0)
                GLES20.glUniformMatrix4fv(uModelLoc, 1, false, modelMatrix, 0)
                GLES20.glUniform4f(uColorLoc, 0.65f, 0.85f, 0.95f, 0.85f)
                aerisRingMesh.draw(aPosLoc, aNormLoc)
                GLES20.glUseProgram(planetProgram)
            }
        }

        // 2. Render orbital path rings for bodies around parents
        renderCelestialOrbitRings()

        // 3. Render Predicted Orbit Trajectory Line for player spacecraft
        renderPredictedTrajectory(flight, primary)

        // 4. Render Target Intercept Line if target body selected
        val target = flight.targetBody
        if (target != null) {
            renderTargetTransferLine(flight, target)
        }

        // 5. Render Orbiting Fleet Vessels & Stations
        renderFleetVessels()

        // 6. Render Rocket Icon on Orbit Map
        GLES20.glUseProgram(meshProgram)
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, flight.position.x.toFloat(), flight.position.y.toFloat(), flight.position.z.toFloat())
        val iconSize = (camera.distance * 0.02f).coerceAtLeast(1200f)
        Matrix.scaleM(modelMatrix, 0, iconSize, iconSize, iconSize)
        Matrix.multiplyMM(mvpMatrix, 0, camera.viewProjectionMatrix, 0, modelMatrix, 0)
        GLES20.glUniformMatrix4fv(uMVPLoc, 1, false, mvpMatrix, 0)
        GLES20.glUniformMatrix4fv(uModelLoc, 1, false, modelMatrix, 0)
        GLES20.glUniform4f(uColorLoc, 1.0f, 0.85f, 0.1f, 1.0f)
        coneMesh.draw(aPosLoc, aNormLoc)
    }

    private fun renderCelestialOrbitRings() {
        GLES20.glUseProgram(lineProgram)
        GLES20.glUniformMatrix4fv(uLineMVPLoc, 1, false, camera.viewProjectionMatrix, 0)
        GLES20.glLineWidth(1.8f)

        for (body in SolarSystem.allBodies) {
            val parent = body.parentBody ?: continue
            val ringPoints = OrbitalMath.sampleBodyOrbitRing(body, 64)
            if (ringPoints.size < 2) continue

            val floats = FloatArray(ringPoints.size * 3)
            for (i in ringPoints.indices) {
                val pt = ringPoints[i]
                floats[i * 3] = pt.x.toFloat()
                floats[i * 3 + 1] = pt.y.toFloat()
                floats[i * 3 + 2] = pt.z.toFloat()
            }

            val buf = ByteBuffer.allocateDirect(floats.size * 4)
                .order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
                    put(floats)
                    position(0)
                }

            // Subtle body orbit track color
            val c = body.colorRgba
            GLES20.glUniform4f(uLineColorLoc, c[0], c[1], c[2], 0.35f)
            GLES20.glVertexAttribPointer(aLinePosLoc, 3, GLES20.GL_FLOAT, false, 0, buf)
            GLES20.glEnableVertexAttribArray(aLinePosLoc)
            GLES20.glDrawArrays(GLES20.GL_LINE_LOOP, 0, ringPoints.size)
            GLES20.glDisableVertexAttribArray(aLinePosLoc)
        }
    }

    private fun renderTargetTransferLine(flight: FlightState, target: CelestialBody) {
        val pts = listOf(flight.position, target.position)
        val floats = floatArrayOf(
            pts[0].x.toFloat(), pts[0].y.toFloat(), pts[0].z.toFloat(),
            pts[1].x.toFloat(), pts[1].y.toFloat(), pts[1].z.toFloat()
        )
        val buf = ByteBuffer.allocateDirect(floats.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
                put(floats)
                position(0)
            }

        GLES20.glUseProgram(lineProgram)
        GLES20.glUniformMatrix4fv(uLineMVPLoc, 1, false, camera.viewProjectionMatrix, 0)
        // Golden dashed intercept guidance line
        GLES20.glUniform4f(uLineColorLoc, 1.0f, 0.84f, 0.0f, 0.7f)
        GLES20.glLineWidth(2.5f)
        GLES20.glVertexAttribPointer(aLinePosLoc, 3, GLES20.GL_FLOAT, false, 0, buf)
        GLES20.glEnableVertexAttribArray(aLinePosLoc)
        GLES20.glDrawArrays(GLES20.GL_LINES, 0, 2)
        GLES20.glDisableVertexAttribArray(aLinePosLoc)
    }

    private fun renderFleetVessels() {
        val vessels = fleetManager?.vessels ?: return
        GLES20.glUseProgram(meshProgram)

        for (v in vessels) {
            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.translateM(modelMatrix, 0, v.position.x.toFloat(), v.position.y.toFloat(), v.position.z.toFloat())
            val size = (camera.distance * 0.015f).coerceAtLeast(1000f)
            Matrix.scaleM(modelMatrix, 0, size, size, size)
            Matrix.multiplyMM(mvpMatrix, 0, camera.viewProjectionMatrix, 0, modelMatrix, 0)
            GLES20.glUniformMatrix4fv(uMVPLoc, 1, false, mvpMatrix, 0)
            GLES20.glUniformMatrix4fv(uModelLoc, 1, false, modelMatrix, 0)

            // Stations are emerald cyan, satellites are teal
            if (v.type == VesselType.SPACE_STATION) {
                GLES20.glUniform4f(uColorLoc, 0.0f, 0.9f, 0.45f, 1.0f)
                boxMesh.draw(aPosLoc, aNormLoc)
            } else {
                GLES20.glUniform4f(uColorLoc, 0.2f, 0.8f, 1.0f, 1.0f)
                coneMesh.draw(aPosLoc, aNormLoc)
            }
        }
    }

    private fun renderPredictedTrajectory(flight: FlightState, primary: CelestialBody) {
        val relPos = flight.position - primary.position
        val points = OrbitalMath.sampleTrajectory(relPos, flight.velocity, primary, 90)
        if (points.size < 2) return

        val floats = FloatArray(points.size * 3)
        for (i in points.indices) {
            val pt = points[i] + primary.position
            floats[i * 3] = pt.x.toFloat()
            floats[i * 3 + 1] = pt.y.toFloat()
            floats[i * 3 + 2] = pt.z.toFloat()
        }

        val buf = ByteBuffer.allocateDirect(floats.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
                put(floats)
                position(0)
            }

        GLES20.glUseProgram(lineProgram)
        GLES20.glUniformMatrix4fv(uLineMVPLoc, 1, false, camera.viewProjectionMatrix, 0)

        // Cyan luminous orbital trajectory
        GLES20.glUniform4f(uLineColorLoc, 0.2f, 0.9f, 1.0f, 0.9f)
        GLES20.glLineWidth(3.0f)

        GLES20.glVertexAttribPointer(aLinePosLoc, 3, GLES20.GL_FLOAT, false, 0, buf)
        GLES20.glEnableVertexAttribArray(aLinePosLoc)
        GLES20.glDrawArrays(GLES20.GL_LINE_STRIP, 0, points.size)
        GLES20.glDisableVertexAttribArray(aLinePosLoc)
    }

    // --- DRAW ROCKET PARTS ---
    private fun drawRocketParts(rocket: RocketDesign, selectedId: String?, alpha: Float) {
        for (part in rocket.parts) {
            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.translateM(modelMatrix, 0, part.x, part.y, part.z)
            if (part.rotationYDeg != 0f) {
                Matrix.rotateM(modelMatrix, 0, part.rotationYDeg, 0f, 1f, 0f)
            }
            val isSelected = part.id == selectedId
            drawPartMesh(part, modelMatrix, alpha, isSelected)
        }
    }

    private fun drawPartMesh(
        part: PlacedPart,
        parentTransform: FloatArray,
        alpha: Float,
        isSelected: Boolean = false
    ) {
        val type = part.type
        val mesh = when (type.shape) {
            MeshShape.CYLINDER -> cylinderMesh
            MeshShape.CONE -> coneMesh
            MeshShape.TRUNCATED_CONE -> truncatedConeMesh
            MeshShape.BOX -> boxMesh
            MeshShape.FIN -> finMesh
            MeshShape.LANDING_LEG -> landingLegMesh
            MeshShape.PANEL -> panelMesh
            MeshShape.RCS_NOZZLE -> rcsMesh
            MeshShape.TRUSS -> trussMesh
            MeshShape.PARACHUTE_CANOPY -> parachuteCanopyMesh
        }

        Matrix.multiplyMM(modelMatrix, 0, parentTransform, 0, modelMatrix, 0)
        val partMatrix = FloatArray(16)
        System.arraycopy(parentTransform, 0, partMatrix, 0, 16)

        // Deployed landing leg outward tilt
        val isLeg = type.shape == MeshShape.LANDING_LEG
        val isLegDeployed = (flightState?.landingGearDeployed == true || part.isDeployed) && isLeg
        if (isLegDeployed) {
            Matrix.rotateM(partMatrix, 0, 25f, 0f, 0f, 1f)
        }

        // Scale by part dimensions
        Matrix.scaleM(partMatrix, 0, type.radius, type.height, type.radius)
        Matrix.multiplyMM(mvpMatrix, 0, camera.viewProjectionMatrix, 0, partMatrix, 0)

        GLES20.glUniformMatrix4fv(uMVPLoc, 1, false, mvpMatrix, 0)
        GLES20.glUniformMatrix4fv(uModelLoc, 1, false, partMatrix, 0)

        // Color selection
        if (isSelected) {
            // Bright pulsing green-cyan selection highlight
            GLES20.glUniform4f(uColorLoc, 0.2f, 1.0f, 0.4f, 1.0f)
        } else {
            val c = type.primaryColorHex
            val r = ((c shr 16) and 0xFF) / 255f
            val g = ((c shr 8) and 0xFF) / 255f
            val b = (c and 0xFF) / 255f
            GLES20.glUniform4f(uColorLoc, r, g, b, alpha)
        }

        mesh.draw(aPosLoc, aNormLoc)

        // If this is a parachute and it's deployed, render the billowing canopy above the craft
        val isChute = type == PartType.PARACHUTE || type == PartType.PARACHUTE_DROGUE
        val isChuteDeployed = (flightState?.parachuteDeployed == true || part.isDeployed) && isChute
        if (isChuteDeployed) {
            val canopyMatrix = FloatArray(16)
            System.arraycopy(parentTransform, 0, canopyMatrix, 0, 16)
            Matrix.translateM(canopyMatrix, 0, 0f, 3.8f, 0f)
            Matrix.scaleM(canopyMatrix, 0, 1.8f, 1.2f, 1.8f)
            Matrix.multiplyMM(mvpMatrix, 0, camera.viewProjectionMatrix, 0, canopyMatrix, 0)

            GLES20.glUniformMatrix4fv(uMVPLoc, 1, false, mvpMatrix, 0)
            GLES20.glUniformMatrix4fv(uModelLoc, 1, false, canopyMatrix, 0)
            // Orange and white high-visibility canopy
            GLES20.glUniform4f(uColorLoc, 1.0f, 0.45f, 0.1f, alpha)
            parachuteCanopyMesh.draw(aPosLoc, aNormLoc)
        }
    }

    private fun computeRotationMatrix(attitude: Vector3D, outMatrix: FloatArray) {
        val up = Vector3D.UP
        val target = attitude.normalized()

        val v = up.cross(target)
        val s = v.length()
        val c = up.dot(target)

        if (s < 1e-4) {
            Matrix.setIdentityM(outMatrix, 0)
            if (c < 0.0) {
                Matrix.rotateM(outMatrix, 0, 180f, 1f, 0f, 0f)
            }
            return
        }

        val axis = v.normalized()
        val angleDeg = Math.toDegrees(atan2(s, c)).toFloat()

        Matrix.setIdentityM(outMatrix, 0)
        Matrix.rotateM(outMatrix, 0, angleDeg, axis.x.toFloat(), axis.y.toFloat(), axis.z.toFloat())
    }
}
