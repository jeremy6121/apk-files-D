package com.example.cosmic.physics

import com.example.cosmic.math.Vector3D
import com.example.cosmic.model.PartCategory
import com.example.cosmic.model.PartType
import com.example.cosmic.model.RocketDesign
import kotlin.math.*

object PhysicsEngine {

    /**
     * Initializes the flight state at the launch pad on the surface of Planet Novaria.
     */
    fun setupLaunchPad(rocket: RocketDesign): FlightState {
        val planet = SolarSystem.PLANET_NOVARIA
        // Place launch pad on the equator: x = planet.radius, y = 0, z = 0
        val padAltitude = 5.0 // slight elevation on pad
        val startPos = Vector3D(planet.radius + padAltitude, 0.0, 0.0)

        // Surface rotational velocity at equator
        val rotSpeed = planet.rotationSpeedRadPerSec * startPos.x
        val startVel = Vector3D(0.0, 0.0, rotSpeed)

        // Attitude points straight up from planet center
        val upVec = startPos.normalized()

        return FlightState(
            rocket = rocket.clone(),
            position = startPos,
            velocity = startVel,
            attitudeVector = upVec,
            pitchAngleDeg = 90.0, // vertical
            headingAngleDeg = 90.0, // East (prograde)
            status = FlightStatus.PRE_LAUNCH,
            primaryBody = planet,
            throttle = 0.0f,
            activeStage = 0,
            batteryCharge = 100f,
            countdownRemaining = 3.0f
        )
    }

    /**
     * Advances the physics simulation by step `dt` seconds (multiplied by time warp).
     */
    fun update(
        state: FlightState,
        dtRaw: Double,
        touchPitchInput: Float,
        touchYawInput: Float
    ) {
        val effectiveDt = (dtRaw * state.timeWarp).coerceIn(0.001, 1.0)
        state.metSeconds += effectiveDt

        // Update celestial orbits (moons around planets)
        SolarSystem.updateAllOrbits(state.metSeconds)

        // Check hierarchical Sphere of Influence (SOI) transitions
        val detectedPrimary = SolarSystem.determinePrimaryBody(state.position)
        if (state.primaryBody != detectedPrimary) {
            state.primaryBody = detectedPrimary
        }

        val primary = state.primaryBody
        val relPos = state.position - primary.position
        val currentDist = relPos.length()
        val altitude = currentDist - primary.radius
        val localUp = if (currentDist > 1e-3) relPos.normalized() else Vector3D.UP

        // PRE-LAUNCH state handling
        if (state.status == FlightStatus.PRE_LAUNCH) {
            // Locked to rotating planet launch pad
            val padPos = primary.position + localUp * (primary.radius + 5.0)
            state.position = padPos
            val rotVel = Vector3D(-primary.rotationSpeedRadPerSec * padPos.z, 0.0, primary.rotationSpeedRadPerSec * padPos.x)
            state.velocity = rotVel
            state.attitudeVector = localUp
            return
        }

        // COUNTDOWN state handling
        if (state.status == FlightStatus.COUNTDOWN) {
            state.countdownRemaining -= effectiveDt.toFloat()
            if (state.countdownRemaining <= 0.0f) {
                state.status = FlightStatus.ASCENT
                state.throttle = 1.0f // Auto ignite to 100% on liftoff
            }
            val padPos = primary.position + localUp * (primary.radius + 5.0)
            state.position = padPos
            val rotVel = Vector3D(-primary.rotationSpeedRadPerSec * padPos.z, 0.0, primary.rotationSpeedRadPerSec * padPos.x)
            state.velocity = rotVel
            state.attitudeVector = localUp
            return
        }

        // LANDED / CRASHED state handling
        if (state.status == FlightStatus.LANDED) {
            // Firmly planted on surface, stationary relative to ground
            val surfPos = primary.position + localUp * (primary.radius + 1.5)
            state.position = surfPos
            val rotVel = Vector3D(-primary.rotationSpeedRadPerSec * surfPos.z, 0.0, primary.rotationSpeedRadPerSec * surfPos.x)
            state.velocity = rotVel
            state.throttle = 0.0f
            return
        }

        if (state.status == FlightStatus.CRASHED) {
            state.throttle = 0.0f
            return
        }

        // --- 1. Compute Electrical Power (Solar & Battery) ---
        val hasSolarPanels = state.rocket.parts.any {
            !it.isDecoupled && (it.type == PartType.SOLAR_PANEL || it.type == PartType.SOLAR_ARRAY_HEAVY)
        }
        val hasBattery = state.rocket.parts.any {
            !it.isDecoupled && (it.type == PartType.BATTERY_PACK || it.type == PartType.BATTERY_BANK_HEAVY)
        }
        // Solar panels generate when in space or upper atmosphere
        state.solarPowerGenerating = hasSolarPanels && (altitude > 10_000.0 || primary.atmosphereHeight <= 0.0)
        if (state.solarPowerGenerating) {
            val chargeRate = if (state.rocket.parts.any { it.type == PartType.SOLAR_ARRAY_HEAVY }) 12f else 6f
            state.batteryCharge = (state.batteryCharge + chargeRate * effectiveDt.toFloat()).coerceAtMost(100f)
        }

        // --- 2. Compute Gravity ---
        val gravityAcc = primary.getGravityAt(state.position)

        // --- 3. Compute Atmospheric Drag & Reentry Heating ---
        val airDensity = primary.getAtmosphericDensity(altitude)
        val surfVel = state.surfaceVelocity
        val airSpeed = surfVel.length()
        var dragAcc = Vector3D.ZERO
        var dynPressure = 0.0

        if (airDensity > 0.0 && airSpeed > 0.1) {
            dynPressure = 0.5 * airDensity * airSpeed * airSpeed
            state.dynamicPressure = dynPressure

            // Total cross-sectional area and drag coefficient
            var effectiveCdA = 0.8
            if (state.parachuteDeployed && altitude < 18_000.0) {
                effectiveCdA += 45.0 // Massive parachute drag
            }

            val dragForceMag = dynPressure * effectiveCdA
            val totalMass = state.rocket.totalMass().coerceAtLeast(100.0)
            val dragAccMag = (dragForceMag / totalMass).coerceAtMost(120.0)
            dragAcc = -surfVel.normalized() * dragAccMag

            // Re-entry heating calculation: proportional to density * speed^3
            val rawHeat = (airDensity * airSpeed * airSpeed * airSpeed / 1.5e8).toFloat()
            val hasThermalProtection = state.rocket.parts.any {
                !it.isDecoupled && (it.type == PartType.HEAT_SHIELD_HEAVY || it.type == PartType.NOSE_CONE_BLUNT)
            }
            val heatReduction = if (hasThermalProtection) 0.45f else 1.0f
            state.reentryHeat = (rawHeat * heatReduction).coerceIn(0.0f, 1.0f)
        } else {
            state.dynamicPressure = 0.0
            state.reentryHeat = 0.0f
        }

        // --- 4. Compute Thrust & Fuel Consumption ---
        var thrustAcc = Vector3D.ZERO
        val activeEngines = state.rocket.parts.filter {
            !it.isDecoupled && it.stageIndex == state.activeStage && it.type.category == PartCategory.ENGINE
        }

        // Active propellant sources: Fuel tanks or self-fueled engines (SRBs)
        val activePropellantSources = state.rocket.parts.filter {
            !it.isDecoupled && it.stageIndex == state.activeStage &&
                (it.type.category == PartCategory.FUEL || it.type.fuelCapacity > 0) &&
                it.fuelRemaining > 0.01
        }

        val hasFuel = activePropellantSources.isNotEmpty()
        var effectiveThrottle = if (hasFuel) state.throttle else 0.0f

        // Ion Thruster electrical check
        val isIonEngine = activeEngines.any { it.type == PartType.ENGINE_ION }
        if (isIonEngine) {
            if (state.batteryCharge <= 0.5f) {
                effectiveThrottle = 0f
            } else {
                state.batteryCharge = (state.batteryCharge - 8f * effectiveThrottle * effectiveDt.toFloat()).coerceAtLeast(0f)
            }
        }

        if (activeEngines.isNotEmpty() && effectiveThrottle > 0.001f && hasFuel) {
            val totalThrustN = activeEngines.sumOf { it.type.thrust } * effectiveThrottle
            val avgIsp = activeEngines.map { it.type.isp }.average()
            val totalMass = state.rocket.totalMass().coerceAtLeast(100.0)
            val thrustAccMag = totalThrustN / totalMass
            thrustAcc = state.attitudeVector * thrustAccMag

            // Burn fuel
            val fuelBurnRateKgPerSec = totalThrustN / (avgIsp * 9.80665)
            val fuelToBurn = fuelBurnRateKgPerSec * effectiveDt
            val fuelPerTank = fuelToBurn / activePropellantSources.size.coerceAtLeast(1)

            for (tank in activePropellantSources) {
                tank.fuelRemaining = (tank.fuelRemaining - fuelPerTank).coerceAtLeast(0.0)
            }
        }

        // --- 5. Total Acceleration and Numerical Integration ---
        val totalAcc = gravityAcc + dragAcc + thrustAcc
        state.velocity = state.velocity + totalAcc * effectiveDt
        state.position = state.position + state.velocity * effectiveDt

        // G-force calculation
        val nonGravAcc = (dragAcc + thrustAcc).length()
        state.gForce = (nonGravAcc / 9.80665) + 1.0

        // --- 6. Attitude Control & Autopilot (SAS) ---
        handleAttitude(state, localUp, effectiveDt, touchPitchInput, touchYawInput)

        // --- 7. Collision & Landing Detection ---
        val newRelPos = state.position - primary.position
        val newAltitude = newRelPos.length() - primary.radius

        if (newAltitude <= 0.0) {
            // Touchdown event!
            val vertSpeed = state.verticalSpeed
            val horizSpeed = state.horizontalSpeed
            val localNoseDotUp = state.attitudeVector.dot(localUp)

            // Safe landing criteria:
            // If landing legs are installed and deployed, allow up to 10 m/s vertical, 6 m/s horizontal.
            // Without landing legs, require strict < 5.5 m/s vertical.
            val hasHeavyLegs = state.rocket.parts.any { !it.isDecoupled && it.type == PartType.LANDING_LEGS_HEAVY }
            val maxVert = if (hasHeavyLegs) 12.0 else if (state.landingGearDeployed) 10.0 else 5.5
            val maxHoriz = if (hasHeavyLegs) 8.0 else if (state.landingGearDeployed) 6.0 else 3.0

            if (abs(vertSpeed) < maxVert && horizSpeed < maxHoriz && localNoseDotUp > 0.65) {
                state.status = FlightStatus.LANDED
                state.position = primary.position + localUp * (primary.radius + 1.5)
                state.velocity = Vector3D.ZERO
                state.throttle = 0f
            } else {
                state.status = FlightStatus.CRASHED
                state.position = primary.position + localUp * primary.radius
                state.velocity = Vector3D.ZERO
                state.throttle = 0f
            }
            return
        }

        // Status update for flight phases
        if (state.status == FlightStatus.ASCENT || state.status == FlightStatus.SPACE || state.status == FlightStatus.REENTRY || state.status == FlightStatus.ORBIT) {
            if (altitude > primary.atmosphereHeight) {
                val orbitInfo = OrbitalMath.computeOrbit(newRelPos, state.velocity, primary)
                state.status = if (orbitInfo.isStableOrbit) FlightStatus.ORBIT else FlightStatus.SPACE
            } else if (state.reentryHeat > 0.2f && state.verticalSpeed < -50.0) {
                state.status = FlightStatus.REENTRY
            } else {
                state.status = FlightStatus.ASCENT
            }
        }

        // --- 8. Update Decoupled Debris Physics ---
        updateDebris(state, effectiveDt, primary)
    }

    private fun handleAttitude(
        state: FlightState,
        localUp: Vector3D,
        dt: Double,
        touchPitch: Float,
        touchYaw: Float
    ) {
        // Manual steering input
        val turnRateDegPerSec = 40.0 // Responsive steering
        var deltaPitch = -touchPitch * turnRateDegPerSec * dt
        var deltaHeading = touchYaw * turnRateDegPerSec * dt

        // SAS Autopilot
        if (abs(touchPitch) < 0.05f && abs(touchYaw) < 0.05f) {
            when (state.sasMode) {
                SasMode.PROGRADE -> {
                    val targetDir = state.velocity.normalized()
                    alignTowards(state, targetDir, dt, 45.0)
                    return
                }
                SasMode.RETROGRADE -> {
                    val targetDir = -state.velocity.normalized()
                    alignTowards(state, targetDir, dt, 45.0)
                    return
                }
                SasMode.STABILITY -> {
                    deltaPitch = 0.0
                    deltaHeading = 0.0
                }
                SasMode.OFF -> {}
            }
        }

        state.pitchAngleDeg = (state.pitchAngleDeg + deltaPitch).coerceIn(-90.0, 90.0)
        state.headingAngleDeg = (state.headingAngleDeg + deltaHeading) % 360.0

        // Compute 3D attitude unit vector from local surface orientation
        val pitchRad = Math.toRadians(state.pitchAngleDeg)
        val headingRad = Math.toRadians(state.headingAngleDeg)

        // Local East and North tangent vectors
        val north = Vector3D.UP
        val east = localUp.cross(north).normalized()
        val actualNorth = east.cross(localUp).normalized()

        val horizontalDir = (east * sin(headingRad) + actualNorth * cos(headingRad)).normalized()
        state.attitudeVector = (localUp * sin(pitchRad) + horizontalDir * cos(pitchRad)).normalized()
    }

    private fun alignTowards(state: FlightState, targetDir: Vector3D, dt: Double, maxDegPerSec: Double) {
        if (targetDir.lengthSquared() < 1e-4) return
        val current = state.attitudeVector
        val dot = current.dot(targetDir).coerceIn(-1.0, 1.0)
        val angleRad = acos(dot)
        if (angleRad < 0.01) {
            state.attitudeVector = targetDir
            return
        }

        val maxStepRad = Math.toRadians(maxDegPerSec) * dt
        val stepRad = min(angleRad, maxStepRad)
        val s = stepRad / angleRad
        val newAttitude = (current * (1.0 - s) + targetDir * s).normalized()
        state.attitudeVector = newAttitude

        // Sync pitch and heading degrees
        val localUp = state.position.normalized()
        val sinPitch = state.attitudeVector.dot(localUp).coerceIn(-1.0, 1.0)
        state.pitchAngleDeg = Math.toDegrees(asin(sinPitch))
    }

    /**
     * Executes staging sequence: detaches spent stage and activates next stage engines.
     */
    fun executeStage(state: FlightState): Boolean {
        val currentStage = state.activeStage
        val partsToDecouple = state.rocket.parts.filter {
            !it.isDecoupled && it.stageIndex == currentStage
        }

        if (partsToDecouple.isNotEmpty()) {
            for (p in partsToDecouple) {
                p.isDecoupled = true
            }

            // Spawn detached debris into physics simulation
            val debrisPos = state.position - state.attitudeVector * 4.0
            val pushVel = -state.attitudeVector * 4.5 // separation push
            state.debrisList.add(
                DecoupledDebris(
                    parts = partsToDecouple.map { it.copyPlacedPart() },
                    position = debrisPos,
                    velocity = state.velocity + pushVel,
                    angularVelocity = Vector3D(0.4, 0.2, 0.1)
                )
            )
        }

        // Advance to next stage
        state.activeStage += 1

        // Deploy utility items assigned to this stage (e.g. parachutes, solar panels, legs)
        val newStageParts = state.rocket.parts.filter { !it.isDecoupled && it.stageIndex == state.activeStage }
        for (part in newStageParts) {
            if (part.type == PartType.PARACHUTE || part.type == PartType.PARACHUTE_DROGUE) {
                state.parachuteDeployed = true
                part.isDeployed = true
            }
            if (part.type == PartType.LANDING_LEGS || part.type == PartType.LANDING_LEGS_HEAVY) {
                state.landingGearDeployed = true
                part.isDeployed = true
            }
            if (part.type == PartType.SOLAR_PANEL || part.type == PartType.SOLAR_ARRAY_HEAVY) {
                part.isDeployed = true
            }
        }

        // Check if there are active engines in the new stage
        val newEngines = state.rocket.parts.filter {
            !it.isDecoupled && it.stageIndex == state.activeStage && it.type.category == PartCategory.ENGINE
        }

        return newEngines.isNotEmpty()
    }

    private fun updateDebris(state: FlightState, dt: Double, primary: CelestialBody) {
        val it = state.debrisList.iterator()
        while (it.hasNext()) {
            val debris = it.next()
            val grav = primary.getGravityAt(debris.position)
            debris.velocity = debris.velocity + grav * dt
            debris.position = debris.position + debris.velocity * dt
            debris.rotation += (debris.angularVelocity.length() * 40.0 * dt).toFloat()

            // Remove debris if it hits surface or wanders too far
            val alt = (debris.position - primary.position).length() - primary.radius
            if (alt <= 0.0 || (debris.position - state.position).length() > 500_000.0) {
                it.remove()
            }
        }
    }
}
