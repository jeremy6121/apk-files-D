package com.example.cosmic.renderer

import android.opengl.GLES20
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import kotlin.math.*

class GLMesh(
    val vertexBuffer: FloatBuffer,
    val normalBuffer: FloatBuffer?,
    val indexBuffer: ShortBuffer,
    val indexCount: Int
) {
    fun draw(posHandle: Int, normalHandle: Int = -1) {
        vertexBuffer.position(0)
        GLES20.glVertexAttribPointer(posHandle, 3, GLES20.GL_FLOAT, false, 0, vertexBuffer)
        GLES20.glEnableVertexAttribArray(posHandle)

        if (normalHandle >= 0 && normalBuffer != null) {
            normalBuffer.position(0)
            GLES20.glVertexAttribPointer(normalHandle, 3, GLES20.GL_FLOAT, false, 0, normalBuffer)
            GLES20.glEnableVertexAttribArray(normalHandle)
        }

        indexBuffer.position(0)
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, indexCount, GLES20.GL_UNSIGNED_SHORT, indexBuffer)

        GLES20.glDisableVertexAttribArray(posHandle)
        if (normalHandle >= 0) {
            GLES20.glDisableVertexAttribArray(normalHandle)
        }
    }
}

object MeshFactory {

    private fun createFloatBuffer(floats: FloatArray): FloatBuffer {
        return ByteBuffer.allocateDirect(floats.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .apply {
                put(floats)
                position(0)
            }
    }

    private fun createShortBuffer(shorts: ShortArray): ShortBuffer {
        return ByteBuffer.allocateDirect(shorts.size * 2)
            .order(ByteOrder.nativeOrder())
            .asShortBuffer()
            .apply {
                put(shorts)
                position(0)
            }
    }

    /**
     * Generates a smooth low-poly Cylinder centered at origin along Y axis.
     */
    fun createCylinder(radius: Float, height: Float, segments: Int = 16): GLMesh {
        val halfH = height / 2f
        val vertices = ArrayList<Float>()
        val normals = ArrayList<Float>()
        val indices = ArrayList<Short>()

        val step = (2.0 * Math.PI / segments).toFloat()

        // Side vertices
        for (i in 0..segments) {
            val angle = i * step
            val nx = cos(angle)
            val nz = sin(angle)
            val x = radius * nx
            val z = radius * nz

            // Top rim
            vertices.add(x); vertices.add(halfH); vertices.add(z)
            normals.add(nx); normals.add(0f); normals.add(nz)

            // Bottom rim
            vertices.add(x); vertices.add(-halfH); vertices.add(z)
            normals.add(nx); normals.add(0f); normals.add(nz)
        }

        // Side indices
        for (i in 0 until segments) {
            val top1 = (i * 2).toShort()
            val bot1 = (i * 2 + 1).toShort()
            val top2 = ((i + 1) * 2).toShort()
            val bot2 = ((i + 1) * 2 + 1).toShort()

            indices.add(top1); indices.add(bot1); indices.add(top2)
            indices.add(top2); indices.add(bot1); indices.add(bot2)
        }

        // Top Cap center
        val topCenterIndex = (vertices.size / 3).toShort()
        vertices.add(0f); vertices.add(halfH); vertices.add(0f)
        normals.add(0f); normals.add(1f); normals.add(0f)

        // Top cap rim vertices
        val topRimStart = (vertices.size / 3).toShort()
        for (i in 0..segments) {
            val angle = i * step
            vertices.add(radius * cos(angle)); vertices.add(halfH); vertices.add(radius * sin(angle))
            normals.add(0f); normals.add(1f); normals.add(0f)
        }
        for (i in 0 until segments) {
            indices.add(topCenterIndex)
            indices.add((topRimStart + i).toShort())
            indices.add((topRimStart + i + 1).toShort())
        }

        // Bottom Cap center
        val botCenterIndex = (vertices.size / 3).toShort()
        vertices.add(0f); vertices.add(-halfH); vertices.add(0f)
        normals.add(0f); normals.add(-1f); normals.add(0f)

        // Bottom cap rim vertices
        val botRimStart = (vertices.size / 3).toShort()
        for (i in 0..segments) {
            val angle = i * step
            vertices.add(radius * cos(angle)); vertices.add(-halfH); vertices.add(radius * sin(angle))
            normals.add(0f); normals.add(-1f); normals.add(0f)
        }
        for (i in 0 until segments) {
            indices.add(botCenterIndex)
            indices.add((botRimStart + i + 1).toShort())
            indices.add((botRimStart + i).toShort())
        }

        return GLMesh(
            createFloatBuffer(vertices.toFloatArray()),
            createFloatBuffer(normals.toFloatArray()),
            createShortBuffer(indices.toShortArray()),
            indices.size
        )
    }

    /**
     * Generates a Cone or Truncated Cone (for engine nozzles, nose cones, capsules).
     */
    fun createCone(
        bottomRadius: Float,
        topRadius: Float,
        height: Float,
        segments: Int = 16
    ): GLMesh {
        val halfH = height / 2f
        val vertices = ArrayList<Float>()
        val normals = ArrayList<Float>()
        val indices = ArrayList<Short>()

        val step = (2.0 * Math.PI / segments).toFloat()
        val slope = (bottomRadius - topRadius) / height

        for (i in 0..segments) {
            val angle = i * step
            val cosA = cos(angle)
            val sinA = sin(angle)

            val nx = cosA
            val ny = slope
            val nz = sinA
            val nLen = sqrt(nx * nx + ny * ny + nz * nz)

            // Top
            vertices.add(topRadius * cosA); vertices.add(halfH); vertices.add(topRadius * sinA)
            normals.add(nx / nLen); normals.add(ny / nLen); normals.add(nz / nLen)

            // Bottom
            vertices.add(bottomRadius * cosA); vertices.add(-halfH); vertices.add(bottomRadius * sinA)
            normals.add(nx / nLen); normals.add(ny / nLen); normals.add(nz / nLen)
        }

        for (i in 0 until segments) {
            val top1 = (i * 2).toShort()
            val bot1 = (i * 2 + 1).toShort()
            val top2 = ((i + 1) * 2).toShort()
            val bot2 = ((i + 1) * 2 + 1).toShort()

            indices.add(top1); indices.add(bot1); indices.add(top2)
            indices.add(top2); indices.add(bot1); indices.add(bot2)
        }

        // If top radius > 0, add top cap
        if (topRadius > 0.001f) {
            val topCenter = (vertices.size / 3).toShort()
            vertices.add(0f); vertices.add(halfH); vertices.add(0f)
            normals.add(0f); normals.add(1f); normals.add(0f)

            val rimStart = (vertices.size / 3).toShort()
            for (i in 0..segments) {
                val angle = i * step
                vertices.add(topRadius * cos(angle)); vertices.add(halfH); vertices.add(topRadius * sin(angle))
                normals.add(0f); normals.add(1f); normals.add(0f)
            }
            for (i in 0 until segments) {
                indices.add(topCenter)
                indices.add((rimStart + i).toShort())
                indices.add((rimStart + i + 1).toShort())
            }
        }

        // Bottom cap
        if (bottomRadius > 0.001f) {
            val botCenter = (vertices.size / 3).toShort()
            vertices.add(0f); vertices.add(-halfH); vertices.add(0f)
            normals.add(0f); normals.add(-1f); normals.add(0f)

            val rimStart = (vertices.size / 3).toShort()
            for (i in 0..segments) {
                val angle = i * step
                vertices.add(bottomRadius * cos(angle)); vertices.add(-halfH); vertices.add(bottomRadius * sin(angle))
                normals.add(0f); normals.add(-1f); normals.add(0f)
            }
            for (i in 0 until segments) {
                indices.add(botCenter)
                indices.add((rimStart + i + 1).toShort())
                indices.add((rimStart + i).toShort())
            }
        }

        return GLMesh(
            createFloatBuffer(vertices.toFloatArray()),
            createFloatBuffer(normals.toFloatArray()),
            createShortBuffer(indices.toShortArray()),
            indices.size
        )
    }

    /**
     * Generates a 3D Box (used for launch pad structures, decoupler rings, landing gear legs).
     */
    fun createBox(width: Float, height: Float, depth: Float): GLMesh {
        val hw = width / 2f
        val hh = height / 2f
        val hd = depth / 2f

        val vertices = floatArrayOf(
            // Front
            -hw, -hh,  hd,   hw, -hh,  hd,   hw,  hh,  hd,  -hw,  hh,  hd,
            // Back
             hw, -hh, -hd,  -hw, -hh, -hd,  -hw,  hh, -hd,   hw,  hh, -hd,
            // Top
            -hw,  hh,  hd,   hw,  hh,  hd,   hw,  hh, -hd,  -hw,  hh, -hd,
            // Bottom
            -hw, -hh, -hd,   hw, -hh, -hd,   hw, -hh,  hd,  -hw, -hh,  hd,
            // Right
             hw, -hh,  hd,   hw, -hh, -hd,   hw,  hh, -hd,   hw,  hh,  hd,
            // Left
            -hw, -hh, -hd,  -hw, -hh,  hd,  -hw,  hh,  hd,  -hw,  hh, -hd
        )

        val normals = floatArrayOf(
            // Front
            0f, 0f, 1f,   0f, 0f, 1f,   0f, 0f, 1f,   0f, 0f, 1f,
            // Back
            0f, 0f, -1f,  0f, 0f, -1f,  0f, 0f, -1f,  0f, 0f, -1f,
            // Top
            0f, 1f, 0f,   0f, 1f, 0f,   0f, 1f, 0f,   0f, 1f, 0f,
            // Bottom
            0f, -1f, 0f,  0f, -1f, 0f,  0f, -1f, 0f,  0f, -1f, 0f,
            // Right
            1f, 0f, 0f,   1f, 0f, 0f,   1f, 0f, 0f,   1f, 0f, 0f,
            // Left
            -1f, 0f, 0f, -1f, 0f, 0f,  -1f, 0f, 0f,  -1f, 0f, 0f
        )

        val indices = shortArrayOf(
            0, 1, 2,  0, 2, 3,
            4, 5, 6,  4, 6, 7,
            8, 9, 10,  8, 10, 11,
            12, 13, 14,  12, 14, 15,
            16, 17, 18,  16, 18, 19,
            20, 21, 22,  20, 22, 23
        )

        return GLMesh(
            createFloatBuffer(vertices),
            createFloatBuffer(normals),
            createShortBuffer(indices),
            indices.size
        )
    }

    /**
     * Generates a 3D Aerodynamic Fin (trapezoidal airfoil).
     */
    fun createFin(span: Float, rootChord: Float, tipChord: Float, thickness: Float): GLMesh {
        val ht = thickness / 2f
        val vertices = floatArrayOf(
            // Root leading edge, trailing edge
            0f, rootChord / 2f, -ht,
            0f, -rootChord / 2f, -ht,
            span, -tipChord / 2f, -ht,
            span, tipChord / 2f, -ht,

            0f, rootChord / 2f, ht,
            0f, -rootChord / 2f, ht,
            span, -tipChord / 2f, ht,
            span, tipChord / 2f, ht
        )

        val normals = floatArrayOf(
            0f, 0f, -1f,  0f, 0f, -1f,  0f, 0f, -1f,  0f, 0f, -1f,
            0f, 0f, 1f,   0f, 0f, 1f,   0f, 0f, 1f,   0f, 0f, 1f
        )

        val indices = shortArrayOf(
            0, 1, 2,  0, 2, 3, // back face
            4, 6, 5,  4, 7, 6, // front face
            0, 3, 7,  0, 7, 4, // top edge
            1, 5, 6,  1, 6, 2, // bottom edge
            3, 2, 6,  3, 6, 7  // outer edge
        )

        return GLMesh(
            createFloatBuffer(vertices),
            createFloatBuffer(normals),
            createShortBuffer(indices),
            indices.size
        )
    }

    /**
     * Generates a UV Sphere (used for Planet Novaria and Moon Lunara).
     */
    fun createSphere(radius: Float, rings: Int = 24, sectors: Int = 24): GLMesh {
        val vertices = ArrayList<Float>()
        val normals = ArrayList<Float>()
        val indices = ArrayList<Short>()

        val R = 1f / rings
        val S = 1f / sectors

        for (r in 0..rings) {
            val v = r * R
            val phi = v * Math.PI.toFloat()
            val sinPhi = sin(phi)
            val cosPhi = cos(phi)

            for (s in 0..sectors) {
                val u = s * S
                val theta = u * (2.0 * Math.PI).toFloat()
                val sinTheta = sin(theta)
                val cosTheta = cos(theta)

                val x = cosTheta * sinPhi
                val y = cosPhi
                val z = sinTheta * sinPhi

                vertices.add(x * radius)
                vertices.add(y * radius)
                vertices.add(z * radius)

                normals.add(x)
                normals.add(y)
                normals.add(z)
            }
        }

        for (r in 0 until rings) {
            for (s in 0 until sectors) {
                val first = (r * (sectors + 1) + s).toShort()
                val second = ((r + 1) * (sectors + 1) + s).toShort()

                indices.add(first)
                indices.add(second)
                indices.add((first + 1).toShort())

                indices.add(second)
                indices.add((second + 1).toShort())
                indices.add((first + 1).toShort())
            }
        }

        return GLMesh(
            createFloatBuffer(vertices.toFloatArray()),
            createFloatBuffer(normals.toFloatArray()),
            createShortBuffer(indices.toShortArray()),
            indices.size
        )
    }

    /**
     * Generates a flat rectangular panel (used for deployable solar panels).
     */
    fun createPanel(width: Float, height: Float, thickness: Float = 0.04f): GLMesh {
        return createBox(width, height, thickness)
    }

    /**
     * Generates a 4-way RCS thruster block (central cube with small projecting nozzles).
     */
    fun createRcsBlock(size: Float = 0.25f): GLMesh {
        return createBox(size, size, size)
    }

    /**
     * Generates an open structural truss section.
     */
    fun createTruss(width: Float, height: Float, depth: Float): GLMesh {
        return createBox(width, height, depth)
    }

    /**
     * Generates a hemispherical Parachute canopy dome.
     */
    fun createParachuteCanopy(radius: Float = 1.8f, rings: Int = 12, sectors: Int = 16): GLMesh {
        val vertices = ArrayList<Float>()
        val normals = ArrayList<Float>()
        val indices = ArrayList<Short>()

        val R = 1f / rings
        val S = 1f / sectors

        // Upper hemisphere (0 to PI/2)
        for (r in 0..rings) {
            val v = r * R * 0.5f
            val phi = v * Math.PI.toFloat()
            val sinPhi = sin(phi)
            val cosPhi = cos(phi)

            for (s in 0..sectors) {
                val u = s * S
                val theta = u * (2.0 * Math.PI).toFloat()
                val sinTheta = sin(theta)
                val cosTheta = cos(theta)

                val x = cosTheta * sinPhi
                val y = cosPhi
                val z = sinTheta * sinPhi

                vertices.add(x * radius)
                vertices.add(y * radius)
                vertices.add(z * radius)

                normals.add(x)
                normals.add(y)
                normals.add(z)
            }
        }

        for (r in 0 until rings) {
            for (s in 0 until sectors) {
                val first = (r * (sectors + 1) + s).toShort()
                val second = ((r + 1) * (sectors + 1) + s).toShort()

                indices.add(first)
                indices.add(second)
                indices.add((first + 1).toShort())

                indices.add(second)
                indices.add((second + 1).toShort())
                indices.add((first + 1).toShort())
            }
        }

        return GLMesh(
            createFloatBuffer(vertices.toFloatArray()),
            createFloatBuffer(normals.toFloatArray()),
            createShortBuffer(indices.toShortArray()),
            indices.size
        )
    }

    /**
     * Generates a flat circular disc ring for ringed gas giants like Aeris.
     */
    fun createPlanetaryRings(innerRadius: Float = 1.35f, outerRadius: Float = 2.4f, segments: Int = 36): GLMesh {
        val vertices = ArrayList<Float>()
        val normals = ArrayList<Float>()
        val indices = ArrayList<Short>()

        val step = (2.0 * Math.PI / segments).toFloat()

        for (i in 0..segments) {
            val angle = i * step
            val cosA = cos(angle)
            val sinA = sin(angle)

            // Inner edge
            vertices.add(innerRadius * cosA)
            vertices.add(0f)
            vertices.add(innerRadius * sinA)
            normals.add(0f); normals.add(1f); normals.add(0f)

            // Outer edge
            vertices.add(outerRadius * cosA)
            vertices.add(0f)
            vertices.add(outerRadius * sinA)
            normals.add(0f); normals.add(1f); normals.add(0f)
        }

        for (i in 0 until segments) {
            val in1 = (i * 2).toShort()
            val out1 = (i * 2 + 1).toShort()
            val in2 = ((i + 1) * 2).toShort()
            val out2 = ((i + 1) * 2 + 1).toShort()

            indices.add(in1)
            indices.add(out1)
            indices.add(in2)

            indices.add(in2)
            indices.add(out1)
            indices.add(out2)
        }

        return GLMesh(
            createFloatBuffer(vertices.toFloatArray()),
            createFloatBuffer(normals.toFloatArray()),
            createShortBuffer(indices.toShortArray()),
            indices.size
        )
    }
}
