package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.cosmic.math.Vector3D
import com.example.cosmic.model.*
import com.example.cosmic.physics.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Cosmic Space Flight", appName)
    }

    @Test
    fun `test vector math calculations`() {
        val v1 = Vector3D(3.0, 4.0, 0.0)
        assertEquals(5.0, v1.length(), 1e-6)

        val normalized = v1.normalized()
        assertEquals(1.0, normalized.length(), 1e-6)

        val cross = Vector3D(1.0, 0.0, 0.0).cross(Vector3D(0.0, 1.0, 0.0))
        assertEquals(Vector3D(0.0, 0.0, 1.0), cross)
    }

    @Test
    fun `test stock rockets have positive delta-v and twr`() {
        val cosmos1 = StockRockets.createCosmos1()
        assertTrue(cosmos1.totalMass() > 1000.0)
        assertTrue(cosmos1.twr(0) > 1.2)
        assertTrue(cosmos1.totalEstimatedDeltaV() > 2000.0)

        val lunarExplorer = StockRockets.createLunarExplorer()
        assertTrue(lunarExplorer.getStagesCount() >= 3)
        assertTrue(lunarExplorer.totalEstimatedDeltaV() > 4000.0)
    }

    @Test
    fun `test launch pad physics setup`() {
        val rocket = StockRockets.createCosmos1()
        val flight = PhysicsEngine.setupLaunchPad(rocket)
        assertEquals(SolarSystem.PLANET_NOVARIA, flight.primaryBody)
        assertEquals(5.0, flight.altitude, 1.0)
        assertEquals(0.0, flight.surfaceSpeed, 1e-2)
        assertEquals(100f, flight.batteryCharge, 0.1f)
    }

    @Test
    fun `test circular orbit speed calculation`() {
        val planet = SolarSystem.PLANET_NOVARIA
        val orbitAlt = 80_000.0
        val vCirc = OrbitalMath.circularOrbitSpeed(planet, orbitAlt)
        assertTrue(vCirc > 1500.0 && vCirc < 3000.0)
    }

    @Test
    fun `test v2 modular part definitions`() {
        val legs = PartType.LANDING_LEGS
        assertEquals(PartCategory.UTILITY, legs.category)
        assertTrue(legs.dryMass > 0)

        val chute = PartType.PARACHUTE
        assertEquals(PartCategory.UTILITY, chute.category)

        val solar = PartType.SOLAR_PANEL
        assertEquals(PartCategory.POWER_RCS, solar.category)

        val battery = PartType.BATTERY_PACK
        assertEquals(PartCategory.POWER_RCS, battery.category)

        val truss = PartType.STRUCTURAL_TRUSS
        assertEquals(PartCategory.STRUCTURAL, truss.category)
    }

    @Test
    fun `test progression system unlock and research`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val progression = ProgressionSystem(context)

        // Tier 1 should be unlocked by default
        assertTrue(progression.isPartUnlocked(PartType.ENGINE_SPARK))

        // Unlock a locked part with credits
        progression.addCredits(5000)
        val success = progression.unlockPart(PartType.SOLAR_PANEL)
        assertTrue(success)
        assertTrue(progression.isPartUnlocked(PartType.SOLAR_PANEL))
    }

    @Test
    fun `test orbital math trajectory sampling`() {
        val planet = SolarSystem.PLANET_NOVARIA
        val r = planet.radius + 100_000.0
        val pos = Vector3D(r, 0.0, 0.0)
        val vCirc = OrbitalMath.circularOrbitSpeed(planet, 100_000.0)
        val vel = Vector3D(0.0, vCirc, 0.0)

        val orbit = OrbitalMath.computeOrbit(pos, vel, planet)
        assertTrue(orbit.isStableOrbit)
        assertTrue(orbit.eccentricity < 0.05)
        assertEquals(100_000.0, orbit.periapsisAltitude, 2000.0)
        assertEquals(100_000.0, orbit.apoapsisAltitude, 2000.0)

        val trajectory = OrbitalMath.sampleTrajectory(pos, vel, planet, numPoints = 30)
        assertEquals(30, trajectory.size)
    }
}
