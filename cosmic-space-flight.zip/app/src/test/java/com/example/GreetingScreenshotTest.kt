package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.cosmic.model.Mission
import com.example.cosmic.ui.MissionCard
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun mission_card_screenshot() {
        val testMission = Mission(
            id = "test_suborbital",
            title = "Suborbital Leap",
            description = "Ascend to an altitude exceeding 15,000 meters.",
            rewardCredits = 100,
            targetBadge = "15km",
            isCompleted = true
        )

        composeTestRule.setContent {
            MyApplicationTheme {
                MissionCard(mission = testMission)
            }
        }

        composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/mission_card.png")
    }
}
